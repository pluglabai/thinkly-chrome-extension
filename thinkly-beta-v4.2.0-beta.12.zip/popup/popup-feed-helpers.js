'use strict';

export const REVIEW_FILTERS = {
  ALL: 'all',
  TO_REVIEW: 'to-review',
  REVIEWED: 'reviewed'
};

export function isSyncedClip(clip = {}) {
  return clip.syncStatus === 'sent' || clip.syncStatus === 'synced';
}

export function getClipSyncStats(clips = []) {
  const synced = clips.filter(isSyncedClip).length;
  return {
    total: clips.length,
    local: clips.length - synced,
    synced
  };
}

export function isClipReviewed(clip = {}, reviewState = {}) {
  return reviewState[clip.id]?.status === 'reviewed';
}

export function getReviewCounts(clips = [], reviewState = {}) {
  const reviewed = clips.filter((clip) => isClipReviewed(clip, reviewState)).length;
  return {
    all: clips.length,
    toReview: clips.length - reviewed,
    reviewed
  };
}

function searchableValue(value) {
  if (Array.isArray(value)) return value.join(' ');
  if (value && typeof value === 'object') {
    return Object.values(value).map(searchableValue).join(' ');
  }
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return '';
}

export function clipMatchesSearch(clip = {}, query = '') {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) return true;

  const source = clip.source || {};
  const haystack = [
    clip.title,
    clip.text,
    clip.url,
    clip.threadUrl,
    clip.pageTitle,
    clip.conversationUrl,
    searchableValue(clip.tags),
    searchableValue(clip.sourceMetadata),
    source.siteName,
    source.platform,
    source.model,
    source.url,
    source.conversationUrl
  ]
    .map(searchableValue)
    .join(' ')
    .toLowerCase();

  return haystack.includes(normalizedQuery);
}

export function filterClips(clips = [], options = {}) {
  const {
    query = '',
    reviewFilter = REVIEW_FILTERS.ALL,
    reviewState = {}
  } = options;

  return clips.filter((clip) => {
    if (!clipMatchesSearch(clip, query)) return false;

    if (reviewFilter === REVIEW_FILTERS.TO_REVIEW) {
      return !isClipReviewed(clip, reviewState);
    }

    if (reviewFilter === REVIEW_FILTERS.REVIEWED) {
      return isClipReviewed(clip, reviewState);
    }

    return true;
  });
}
