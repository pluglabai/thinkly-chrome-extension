'use strict';

import {
  getSelectedText,
  isValidSelection,
  getSelectionCoordinates
} from './selector.js';
import ClipManager from '../shared/ClipManager.js';
import CategoryManager from '../shared/CategoryManager.js';
import { SyncManager } from '../shared/sync/index.js';
import { generateId, detectPlatform, extractConversationId, escapeHTML } from '../shared/utils.js';
import { QUICK_SAVE_DEFAULTS, CLIP_ICONS, VALIDATION_RULES } from '../shared/constants.js';
import {
  getCaptureV2Settings,
  isCaptureV2Ready
} from '../shared/capture-v2-settings.js';
import {
  buildAutoCaptureClipId,
  buildAutoCaptureContentFingerprint,
  shouldDeferAutoCapture,
  resolveAutoCaptureAction,
  buildAutoCapturedClip
} from './capture-v2.js';

// Initialize managers
const clipManager = new ClipManager();
const categoryManager = new CategoryManager();
const syncManager = new SyncManager();

// UI State
const UI_STAGES = {
  NONE: 'none',
  MINI_TOOLBAR: 'mini_toolbar',
  SAVE_PANEL: 'save_panel'
};

let currentStage = UI_STAGES.NONE;
let miniToolbar = null;
let savePanel = null;
let toast = null;
let currentSelection = null;
let captureV2Settings = null;
let statusPill = null;
let latestObservedAutoCaptureFingerprint = null;
let latestObservedAutoCaptureAt = 0;
let savedAutoCaptureFingerprints = new Map();
let latestAutoCaptureDraftAt = new Map();
let activeAutoCaptureRequests = 0;
let autoCaptureScheduled = false;
let autoCaptureCount = 0;
let pageBridgeInjected = false;
let autoCaptureObserver = null;
let latestNetworkActivityAt = 0;
const AUTO_CAPTURE_SCAN_DELAY_MS = 600;
const AUTO_CAPTURE_DOM_CHANGE_DELAY_MS = 1200;
const AUTO_CAPTURE_QUIET_WINDOW_MS = 2000;
const AUTO_CAPTURE_DRAFT_INTERVAL_MS = 10000;
const AUTO_CAPTURE_STALE_NETWORK_MS = 15000;

/**
 * Initialize content script
 */
async function init() {
  console.log('[Thinkly] Content script loaded');

  // Connect SyncManager to ClipManager and CategoryManager
  clipManager.setSyncManager(syncManager);
  categoryManager.setSyncManager(syncManager);

  // Ensure default categories exist
  await categoryManager.initializeDefaultCategories();

  captureV2Settings = await getCaptureV2Settings(chrome.storage.local);

  // Listen for text selection
  document.addEventListener('mouseup', handleSelection);

  // Listen for keyboard shortcut (Cmd+Shift+S / Ctrl+Shift+S)
  document.addEventListener('keydown', handleKeyboardShortcut);

  // Listen for clicks to hide popup (outside click)
  document.addEventListener('click', handleDocumentClick);

  // Listen for ESC key to close
  document.addEventListener('keydown', handleEscKey);

  initCaptureV2();
}

/**
 * Handle text selection event
 * @param {MouseEvent} event - Mouse event
 */
function handleSelection(event) {
  // Skip if inside Tiptap editor (suppress popup in WYSIWYG areas)
  if (event.target.closest && event.target.closest('[data-thinkly-editor="true"]')) return;

  // Skip if clicking inside our UI elements
  if (miniToolbar && miniToolbar.contains(event.target)) return;
  if (savePanel && savePanel.contains(event.target)) return;

  const selectedText = getSelectedText();

  if (!isValidSelection(selectedText)) {
    hideAllUI();
    if (selectedText && selectedText.trim().length > VALIDATION_RULES.CLIP_TEXT_MAX) {
      showToast(`Selection too long (max ${VALIDATION_RULES.CLIP_TEXT_MAX.toLocaleString()} characters)`, true);
    }
    return;
  }

  currentSelection = {
    text: selectedText,
    url: window.location.href,
    platform: detectPlatform(window.location.href),
    conversationId: extractConversationId(window.location.href)
  };

  showMiniToolbar();
}

/**
 * Handle keyboard shortcut (Cmd+Shift+S / Ctrl+Shift+S)
 * @param {KeyboardEvent} event - Keyboard event
 */
function handleKeyboardShortcut(event) {
  const isMac = navigator.platform.toLowerCase().includes('mac');
  const modifierKey = isMac ? event.metaKey : event.ctrlKey;

  if (modifierKey && event.shiftKey && event.key === 'S') {
    event.preventDefault();

    const selectedText = getSelectedText();

    if (isValidSelection(selectedText)) {
      currentSelection = {
        text: selectedText,
        url: window.location.href,
        platform: detectPlatform(window.location.href),
        conversationId: extractConversationId(window.location.href)
      };

      showMiniToolbar();
    }
  }
}

/**
 * Handle ESC key to close UI
 * @param {KeyboardEvent} event - Keyboard event
 */
function handleEscKey(event) {
  if (event.key === 'Escape') {
    hideAllUI();
  }
}

/**
 * Handle document click (hide popup when clicking outside)
 * @param {MouseEvent} event - Click event
 */
function handleDocumentClick(event) {
  // Skip if clicking inside our UI elements
  if (miniToolbar && miniToolbar.contains(event.target)) return;
  if (savePanel && savePanel.contains(event.target)) return;
  if (toast && toast.contains(event.target)) return;

  // Only hide if we have UI showing and click is outside
  if (currentStage !== UI_STAGES.NONE) {
    // Small delay to allow selection events to process first
    setTimeout(() => {
      // Double check we're not clicking inside popup elements
      if (miniToolbar && miniToolbar.contains(event.target)) return;
      if (savePanel && savePanel.contains(event.target)) return;
    }, 0);
  }
}

// ============================================
// Stage 1: MiniToolbar
// ============================================

/**
 * Show the MiniToolbar (Stage 1)
 */
function showMiniToolbar() {
  if (!currentSelection || !currentSelection.text) {
    console.error('[Thinkly] Cannot show toolbar: no selection');
    return;
  }

  // Remove existing UI elements only (keep currentSelection)
  removeUIElements();

  // Get selection coordinates
  let coords = getSelectionCoordinates();
  if (!coords) {
    coords = {
      x: window.innerWidth / 2 - 120,
      y: window.scrollY + 100,
      height: 0
    };
  }

  // Create MiniToolbar
  miniToolbar = createMiniToolbar();
  positionElement(miniToolbar, coords, 240, 44);
  document.body.appendChild(miniToolbar);

  currentStage = UI_STAGES.MINI_TOOLBAR;
}

/**
 * Create MiniToolbar element
 * @returns {HTMLElement} MiniToolbar element
 */
function createMiniToolbar() {
  const toolbar = document.createElement('div');
  toolbar.className = 'thinkly-mini-toolbar';
  toolbar.innerHTML = `
    <button class="thinkly-toolbar-btn thinkly-quick-save-btn" data-action="quick-save">
      <span class="thinkly-btn-icon">⚡</span>
      <span class="thinkly-btn-text">Quick Save</span>
    </button>
    <div class="thinkly-toolbar-divider"></div>
    <button class="thinkly-toolbar-btn thinkly-close-toolbar-btn" data-action="close">
      <span class="thinkly-btn-icon">✕</span>
    </button>
  `;

  // Event listeners
  toolbar.addEventListener('click', handleToolbarClick);
  toolbar.addEventListener('click', (e) => e.stopPropagation());

  return toolbar;
}

/**
 * Handle MiniToolbar button clicks
 * @param {MouseEvent} event - Click event
 */
async function handleToolbarClick(event) {
  const btn = event.target.closest('[data-action]');
  if (!btn) return;

  const action = btn.dataset.action;

  switch (action) {
    case 'quick-save':
      await handleQuickSave();
      break;
    case 'close':
      hideAllUI();
      break;
  }
}

// ============================================
// Stage 2: SavePanel
// ============================================

/**
 * Show the SavePanel (Stage 2)
 */
async function showSavePanel() {
  if (!currentSelection || !currentSelection.text) {
    console.error('[Thinkly] Cannot show save panel: no selection');
    return;
  }

  // Remove MiniToolbar
  if (miniToolbar && miniToolbar.parentNode) {
    miniToolbar.parentNode.removeChild(miniToolbar);
    miniToolbar = null;
  }

  // Get selection coordinates
  let coords = getSelectionCoordinates();
  if (!coords) {
    coords = {
      x: window.innerWidth / 2 - 160,
      y: window.scrollY + 100,
      height: 0
    };
  }

  // Create SavePanel
  savePanel = createSavePanel();
  positionElement(savePanel, coords, 320, 300);
  document.body.appendChild(savePanel);

  currentStage = UI_STAGES.SAVE_PANEL;

  // Focus title input
  setTimeout(() => {
    const titleInput = savePanel.querySelector('.thinkly-title-input');
    if (titleInput) {
      titleInput.focus();
      titleInput.select();
    }
  }, 100);
}

/**
 * Create SavePanel element
 * @returns {HTMLElement} SavePanel element
 */
function createSavePanel() {
  const titleValue = escapeHTML(currentSelection.text.substring(0, 60));
  const platformDisplay = currentSelection.platform === 'chatgpt' ? 'ChatGPT' :
                          currentSelection.platform === 'claude' ? 'Claude' : 'Web';

  const panel = document.createElement('div');
  panel.className = 'thinkly-save-panel';
  panel.innerHTML = `
    <div class="thinkly-panel-content">
      <div class="thinkly-panel-header">
        <span class="thinkly-panel-icon">💡</span>
        <span class="thinkly-panel-title">Save Clip</span>
        <button class="thinkly-panel-close-btn" data-action="close">×</button>
      </div>

      <div class="thinkly-panel-body">
        <input
          type="text"
          class="thinkly-title-input"
          placeholder="Clip title..."
          value="${titleValue}"
        />

        <div class="thinkly-icon-picker">
          ${CLIP_ICONS.map((icon, index) =>
            `<button class="thinkly-icon-btn ${index === 0 ? 'selected' : ''}" data-icon="${icon}">${icon}</button>`
          ).join('')}
        </div>
      </div>

      <div class="thinkly-panel-footer">
        <button class="thinkly-cancel-btn" data-action="cancel">Cancel</button>
        <button class="thinkly-save-btn" data-action="save">Save Clip</button>
      </div>

      <div class="thinkly-panel-platform">${platformDisplay}</div>
    </div>
  `;

  // Event listeners
  panel.addEventListener('click', handlePanelClick);
  panel.addEventListener('click', (e) => e.stopPropagation());

  return panel;
}

/**
 * Handle SavePanel button clicks
 * @param {MouseEvent} event - Click event
 */
async function handlePanelClick(event) {
  const action = event.target.dataset.action;
  const icon = event.target.dataset.icon;

  if (action === 'close') {
    hideAllUI();
    return;
  }

  if (action === 'cancel') {
    // Return to Stage 1
    showMiniToolbar();
    return;
  }

  if (action === 'save') {
    await handleSave();
    return;
  }

  if (icon) {
    // Update selected icon
    const iconButtons = savePanel.querySelectorAll('.thinkly-icon-btn');
    iconButtons.forEach(btn => btn.classList.remove('selected'));
    event.target.classList.add('selected');
  }
}

// ============================================
// Save Operations
// ============================================

/**
 * Handle Quick Save (Stage 1)
 */
async function handleQuickSave() {
  if (!currentSelection || !currentSelection.text) {
    console.error('[Thinkly] Cannot quick save: no selection');
    return;
  }

  let clip;
  try {
    clip = {
      id: generateId('clip'),
      text: currentSelection.text,
      title: currentSelection.text.substring(0, 60),
      url: currentSelection.url,
      icon: QUICK_SAVE_DEFAULTS.ICON,
      categoryId: null,
      source: {
        platform: currentSelection.platform,
        siteName: extractSiteName(currentSelection.url),
        model: detectModel(currentSelection.platform),
        conversationUrl: currentSelection.url,
        conversationId: currentSelection.conversationId
      },
      createdAt: Date.now()
    };

    console.log('[Thinkly] Attempting to save clip:', clip);
    await clipManager.addClip(clip);

    hideAllUI();
    showToast('Saved to Thinkly');

  } catch (error) {
    console.error('[Thinkly] Error quick saving clip:', error);
    console.error('[Thinkly] Clip data was:', clip);

    // Handle extension context invalidation
    showToast(formatSaveErrorMessage(error), true);
  }
}

/**
 * Handle Save from SavePanel (Stage 2)
 */
async function handleSave() {
  if (!currentSelection || !currentSelection.text || !savePanel) {
    console.error('[Thinkly] Cannot save: invalid state');
    return;
  }

  let clip;
  try {
    const titleInput = savePanel.querySelector('.thinkly-title-input');
    const selectedIconBtn = savePanel.querySelector('.thinkly-icon-btn.selected');

    const title = titleInput.value.trim() || currentSelection.text.substring(0, 60);
    const icon = selectedIconBtn ? selectedIconBtn.dataset.icon : QUICK_SAVE_DEFAULTS.ICON;

    clip = {
      id: generateId('clip'),
      text: currentSelection.text,
      title,
      url: currentSelection.url,
      icon,
      categoryId: null,
      source: {
        platform: currentSelection.platform,
        siteName: extractSiteName(currentSelection.url),
        model: detectModel(currentSelection.platform),
        conversationUrl: currentSelection.url,
        conversationId: currentSelection.conversationId
      },
      createdAt: Date.now()
    };

    console.log('[Thinkly] Attempting to save clip:', clip);
    await clipManager.addClip(clip);

    hideAllUI();
    showToast('Saved to Thinkly');

  } catch (error) {
    console.error('[Thinkly] Error saving clip:', error);
    console.error('[Thinkly] Clip data was:', clip);

    // Handle extension context invalidation
    showToast(formatSaveErrorMessage(error), true);
  }
}

function formatSaveErrorMessage(error) {
  const message = error?.message || '';

  if (
    error?.isContextInvalidated ||
    message.includes('Extension was updated') ||
    message.includes('Cannot read properties') ||
    message.includes('refresh')
  ) {
    return 'Please refresh the page (Cmd+R), then save again.';
  }

  if (message.includes('not exceed')) {
    return 'Text too long (max 100,000 characters)';
  }

  if (message.includes('Storage quota exceeded') || message.includes('quota exceeded')) {
    return 'Local storage is full. Export or delete saved ideas.';
  }

  return `Save failed: ${message || 'Please try again.'}`;
}

// ============================================
// Toast Notifications
// ============================================

/**
 * Show toast notification
 * @param {string} message - Toast message
 * @param {boolean} isError - Whether this is an error toast
 */
function showToast(message, isError = false) {
  // Remove existing toast
  if (toast && toast.parentNode) {
    toast.parentNode.removeChild(toast);
    toast = null;
  }

  toast = document.createElement('div');
  toast.className = `thinkly-toast ${isError ? 'thinkly-toast-error' : 'thinkly-toast-success'}`;
  toast.innerHTML = `
    <span class="thinkly-toast-icon">${isError ? '✗' : '✓'}</span>
    <span class="thinkly-toast-message">${escapeHTML(message)}</span>
  `;

  document.body.appendChild(toast);

  // Auto-dismiss after 2 seconds
  setTimeout(() => {
    if (toast) {
      toast.classList.add('thinkly-toast-fade-out');
      setTimeout(() => {
        if (toast && toast.parentNode) {
          toast.parentNode.removeChild(toast);
          toast = null;
        }
      }, 200);
    }
  }, 2000);
}

// ============================================
// Capture V2
// ============================================

function supportsAutoCapture() {
  const platform = detectPlatform(window.location.href);
  return ['chatgpt', 'claude', 'gemini'].includes(platform);
}

function initCaptureV2() {
  if (!supportsAutoCapture()) {
    return;
  }

  if (!isCaptureV2Ready(captureV2Settings)) {
    return;
  }

  const platform = detectPlatform(window.location.href);
  if (captureV2Settings?.globalEnabled === false || captureV2Settings?.platforms?.[platform] === false) {
    return;
  }

  ensureStatusPill();
  injectPageBridge();
  startAutoCaptureObserver();
  window.addEventListener('message', handleBridgeMessage);
  window.addEventListener('focus', scheduleAutoCaptureScan);
  setTimeout(scheduleAutoCaptureScan, 1200);
}

function startAutoCaptureObserver() {
  if (autoCaptureObserver || typeof MutationObserver === 'undefined' || !document.body) {
    return;
  }

  autoCaptureObserver = new MutationObserver((mutations) => {
    const hasMeaningfulChange = mutations.some((mutation) => {
      if (mutation.type === 'characterData') {
        return true;
      }

      return Array.from(mutation.addedNodes).some((node) => {
        if (node.nodeType === Node.TEXT_NODE) {
          return node.textContent?.trim().length > 0;
        }

        if (node.nodeType !== Node.ELEMENT_NODE) {
          return false;
        }

        return !node.closest?.('.thinkly-status-pill, .thinkly-mini-toolbar, .thinkly-save-panel');
      });
    });

    if (hasMeaningfulChange) {
      scheduleAutoCaptureScan(AUTO_CAPTURE_DOM_CHANGE_DELAY_MS);
    }
  });

  autoCaptureObserver.observe(document.body, {
    childList: true,
    subtree: true,
    characterData: true,
  });
}

function injectPageBridge() {
  if (pageBridgeInjected) {
    return;
  }

  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('dist/page-bridge.js');
  script.dataset.thinklyBridge = 'true';
  script.onload = () => {
    pageBridgeInjected = true;
    script.remove();
  };
  (document.head || document.documentElement).appendChild(script);
}

function handleBridgeMessage(event) {
  if (event.source !== window) return;
  if (event.origin !== window.location.origin) return;

  const data = event.data;
  if (!data || data.source !== 'thinkly-page-bridge') return;

  if (data.type === 'network:fetch:start' || data.type === 'network:xhr:start') {
    activeAutoCaptureRequests += 1;
    latestNetworkActivityAt = Date.now();
    setStatusPillState('saving');
    return;
  }

  if (
    data.type === 'network:fetch:complete'
    || data.type === 'network:fetch:error'
    || data.type === 'network:xhr:complete'
  ) {
    activeAutoCaptureRequests = Math.max(0, activeAutoCaptureRequests - 1);
    latestNetworkActivityAt = Date.now();
    setStatusPillState('saving');
    scheduleAutoCaptureScan();
  }
}

function scheduleAutoCaptureScan(delayMs = AUTO_CAPTURE_SCAN_DELAY_MS) {
  if (autoCaptureScheduled) {
    return;
  }

  autoCaptureScheduled = true;
  setTimeout(async () => {
    autoCaptureScheduled = false;
    await captureLatestVisibleExchange();
  }, delayMs);
}

async function captureLatestVisibleExchange({ force = false } = {}) {
  const exchange = readLatestVisibleExchange();
  if (!exchange) {
    setStatusPillState('idle');
    return;
  }

  const clipId = buildAutoCaptureClipId(exchange);
  const currentFingerprint = buildAutoCaptureContentFingerprint(exchange);
  const now = Date.now();
  if (currentFingerprint !== latestObservedAutoCaptureFingerprint) {
    latestObservedAutoCaptureFingerprint = currentFingerprint;
    latestObservedAutoCaptureAt = now;
  }

  if (!latestAutoCaptureDraftAt.has(clipId)) {
    latestAutoCaptureDraftAt.set(clipId, now);
  }

  const activeRequestCount = getEffectiveActiveRequestCount(now);
  const isGenerating = isPageGeneratingResponse();
  const action = force
    ? activeRequestCount > 0 || isGenerating ? 'draft' : 'final'
    : resolveAutoCaptureAction({
      activeRequestCount,
      isGenerating,
      previousFingerprint: latestObservedAutoCaptureFingerprint,
      currentFingerprint,
      elapsedMs: now - latestObservedAutoCaptureAt,
      quietWindowMs: AUTO_CAPTURE_QUIET_WINDOW_MS,
      elapsedSinceDraftMs: now - latestAutoCaptureDraftAt.get(clipId),
      draftIntervalMs: AUTO_CAPTURE_DRAFT_INTERVAL_MS,
    });

  if (action === 'wait') {
    if (!force && shouldDeferAutoCapture({
      activeRequestCount,
      isGenerating,
      previousFingerprint: latestObservedAutoCaptureFingerprint,
      currentFingerprint,
      elapsedMs: now - latestObservedAutoCaptureAt,
      quietWindowMs: AUTO_CAPTURE_QUIET_WINDOW_MS,
    })) {
      setStatusPillState('saving');
      scheduleAutoCaptureScan(AUTO_CAPTURE_QUIET_WINDOW_MS);
      return;
    }

    setStatusPillState('saving');
    scheduleAutoCaptureScan(AUTO_CAPTURE_QUIET_WINDOW_MS);
    return;
  }

  if (action === 'draft') {
    await saveAutoCaptureSnapshot(exchange, clipId, currentFingerprint, {
      captureStatus: 'draft',
      sync: false,
    });
    latestAutoCaptureDraftAt.set(clipId, now);
    setStatusPillState('saving');
    scheduleAutoCaptureScan(AUTO_CAPTURE_QUIET_WINDOW_MS);
    return;
  }

  if (savedAutoCaptureFingerprints.get(clipId) === currentFingerprint) {
    setStatusPillState('saved');
    return;
  }

  await saveAutoCaptureSnapshot(exchange, clipId, currentFingerprint, {
    captureStatus: 'final',
    sync: true,
  });
}

async function saveAutoCaptureSnapshot(exchange, clipId, currentFingerprint, {
  captureStatus = 'final',
  sync = true,
} = {}) {
  const existingClip = await clipManager.getClip(clipId);
  const clipPayload = buildAutoCapturedClip(exchange, clipId, undefined, {
    captureStatus,
  });

  try {
    if (existingClip) {
      await clipManager.updateClip(clipId, clipPayload, {
        validate: false,
        sync
      });
    } else {
      await clipManager.addClip(clipPayload, {
        sync
      });
      autoCaptureCount += 1;
    }

    if (captureStatus === 'final') {
      savedAutoCaptureFingerprints.set(clipId, currentFingerprint);
      updateStatusPillCount();
      setStatusPillState('saved');
      return;
    }

    updateStatusPillCount();
  } catch (error) {
    console.error('[Thinkly] Auto capture failed:', error);
    setStatusPillState('error');
  }
}

function getEffectiveActiveRequestCount(now = Date.now()) {
  if (activeAutoCaptureRequests <= 0) {
    return 0;
  }

  if (latestNetworkActivityAt > 0 && now - latestNetworkActivityAt > AUTO_CAPTURE_STALE_NETWORK_MS) {
    console.warn('[Thinkly] Resetting stale auto-capture network activity');
    activeAutoCaptureRequests = 0;
    return 0;
  }

  return activeAutoCaptureRequests;
}

function isPageGeneratingResponse() {
  if (document.querySelector('[aria-busy="true"]')) {
    return true;
  }

  return Array.from(document.querySelectorAll('button, [role="button"]')).some((node) => {
    const text = [
      node.getAttribute('aria-label'),
      node.getAttribute('title'),
      node.textContent
    ].filter(Boolean).join(' ').toLowerCase();

    return (
      text.includes('stop generating')
      || text.includes('stop streaming')
      || text.includes('stop response')
      || text.includes('cancel response')
    );
  });
}

function readLatestVisibleExchange() {
  const platform = detectPlatform(window.location.href);
  const blocks = getMessageBlocksForPlatform(platform);
  if (blocks.length === 0) {
    return null;
  }

  const assistantBlock = [...blocks].reverse().find((block) => block.role === 'assistant' && block.text);
  if (!assistantBlock) {
    return null;
  }

  const assistantIndex = blocks.indexOf(assistantBlock);
  const userBlock = [...blocks.slice(0, assistantIndex)].reverse().find((block) => block.role === 'user' && block.text);

  return {
    platform,
    title: userBlock?.text || assistantBlock.text,
    userText: userBlock?.text || '',
    assistantText: assistantBlock.text,
    turnIndex: assistantIndex,
    conversationUrl: window.location.href,
    conversationId: extractConversationId(window.location.href),
    pageTitle: document.title,
    threadUrl: window.location.href
  };
}

function getMessageBlocksForPlatform(platform) {
  if (platform === 'chatgpt') {
    return Array.from(document.querySelectorAll('[data-message-author-role]')).map((node) => ({
      role: node.getAttribute('data-message-author-role') === 'assistant' ? 'assistant' : 'user',
      text: (node.innerText || '').trim()
    })).filter((block) => block.text);
  }

  const genericRoleBlocks = Array.from(
    document.querySelectorAll('[data-testid*="message"], [data-testid*="turn"], main article, main section')
  ).map((node) => {
    const text = (node.innerText || '').trim();
    const testId = node.getAttribute('data-testid') || '';
    const role = /user|human/i.test(testId) ? 'user' : /assistant|model|response/i.test(testId) ? 'assistant' : null;
    return {
      role,
      text
    };
  }).filter((block) => block.text.length > 20);

  if (genericRoleBlocks.some((block) => block.role)) {
    return genericRoleBlocks.filter((block) => block.role);
  }

  const paragraphs = Array.from(document.querySelectorAll('main div, main article, main p'))
    .map((node) => (node.innerText || '').trim())
    .filter((text, index, arr) => text.length > 20 && arr.indexOf(text) === index)
    .slice(-6);

  const blocks = [];
  for (let index = 0; index < paragraphs.length; index += 1) {
    blocks.push({
      role: index % 2 === 0 ? 'user' : 'assistant',
      text: paragraphs[index]
    });
  }
  return blocks;
}

function ensureStatusPill() {
  if (statusPill) {
    return;
  }

  statusPill = document.createElement('div');
  statusPill.className = 'thinkly-status-pill';
  statusPill.innerHTML = `
    <button class="thinkly-status-pill-main" type="button">
      <span class="thinkly-status-pill-dot"></span>
      <span class="thinkly-status-pill-label">On</span>
      <span class="thinkly-status-pill-count">0 captured</span>
    </button>
    <div class="thinkly-status-pill-menu">
      <button type="button" data-action="pause">Pause capture</button>
      <button type="button" data-action="save-turn">Save this turn</button>
      <button type="button" data-action="dashboard">Open dashboard</button>
    </div>
  `;

  statusPill.querySelector('.thinkly-status-pill-main')?.addEventListener('click', () => {
    statusPill.classList.toggle('expanded');
  });
  statusPill.querySelector('[data-action="pause"]')?.addEventListener('click', toggleAutoCapturePause);
  statusPill.querySelector('[data-action="save-turn"]')?.addEventListener('click', () => {
    setStatusPillState('saving');
    captureLatestVisibleExchange({ force: true });
  });
  statusPill.querySelector('[data-action="dashboard"]')?.addEventListener('click', () => {
    window.open(chrome.runtime.getURL('popup/popup-new.html'), '_blank');
  });

  document.body.appendChild(statusPill);
  updateStatusPillCount();
}

async function toggleAutoCapturePause() {
  captureV2Settings = {
    ...captureV2Settings,
    globalEnabled: !captureV2Settings.globalEnabled
  };

  const result = await chrome.storage.local.get(['settings']);
  const settings = result?.settings || {};
  await chrome.storage.local.set({
    settings: {
      ...settings,
      captureV2: captureV2Settings
    }
  });

  setStatusPillState(captureV2Settings.globalEnabled === false ? 'paused' : 'idle');
  statusPill.classList.remove('expanded');
}

function updateStatusPillCount() {
  if (!statusPill) return;
  const count = statusPill.querySelector('.thinkly-status-pill-count');
  if (count) {
    count.textContent = `${autoCaptureCount} captured`;
  }
}

function setStatusPillState(state) {
  if (!statusPill) return;

  const label = statusPill.querySelector('.thinkly-status-pill-label');
  const dot = statusPill.querySelector('.thinkly-status-pill-dot');
  if (!label || !dot) return;

  statusPill.dataset.state = state;

  if (state === 'saving') {
    label.textContent = 'Saving';
  } else if (state === 'saved') {
    label.textContent = 'Saved';
  } else if (state === 'paused') {
    label.textContent = 'Paused';
  } else if (state === 'error') {
    label.textContent = 'Error';
  } else {
    label.textContent = 'On';
  }
}

// ============================================
// Utility Functions
// ============================================

/**
 * Detect AI model from platform
 * @param {string} platform - Platform name
 * @returns {string} Model name
 */
function detectModel(platform) {
  if (platform === 'chatgpt') {
    return 'gpt-4';
  } else if (platform === 'claude') {
    return 'claude-3-opus';
  } else if (platform === 'gemini') {
    return 'gemini-2.5-pro';
  }
  return 'unknown';
}

/**
 * Position element near selection
 * @param {HTMLElement} element - Element to position
 * @param {Object} coords - Selection coordinates
 * @param {number} width - Element width
 * @param {number} height - Element height
 */
function positionElement(element, coords, width, height) {
  const margin = 10;

  let left = coords.x;
  let top = coords.y + coords.height + margin;

  // Prevent going off-screen (right edge)
  if (left + width > window.innerWidth + window.scrollX) {
    left = window.innerWidth + window.scrollX - width - margin;
  }

  // Prevent going off-screen (left edge)
  if (left < window.scrollX + margin) {
    left = window.scrollX + margin;
  }

  // Prevent going off-screen (bottom edge)
  if (top + height > window.innerHeight + window.scrollY) {
    top = coords.y - height - margin;
  }

  element.style.left = `${left}px`;
  element.style.top = `${top}px`;
}

/**
 * Remove UI elements only (keep currentSelection for stage transitions)
 */
function removeUIElements() {
  if (miniToolbar && miniToolbar.parentNode) {
    miniToolbar.parentNode.removeChild(miniToolbar);
    miniToolbar = null;
  }

  if (savePanel && savePanel.parentNode) {
    savePanel.parentNode.removeChild(savePanel);
    savePanel = null;
  }
}

/**
 * Hide all UI elements and reset state
 */
function hideAllUI() {
  removeUIElements();
  currentSelection = null;
  currentStage = UI_STAGES.NONE;
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
