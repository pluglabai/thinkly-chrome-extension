'use strict';

import { extractSiteName } from '../shared/utils.js';

function hashCaptureKey(rawKey) {
  let hash = 2166136261;
  for (let index = 0; index < rawKey.length; index += 1) {
    hash ^= rawKey.charCodeAt(index);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }

  return Math.abs(hash >>> 0).toString(36);
}

export function buildAutoCaptureClipId(exchange) {
  const rawKey = [
    exchange.platform,
    exchange.conversationId || exchange.threadUrl,
    String(exchange.turnIndex ?? 'unknown'),
    exchange.userText || '',
  ].join('::');

  return `clip_auto_${hashCaptureKey(rawKey)}`;
}

export function buildAutoCaptureContentFingerprint(exchange) {
  const rawKey = [
    buildAutoCaptureClipId(exchange),
    exchange.userText || '',
    exchange.assistantText || '',
  ].join('::');

  return hashCaptureKey(rawKey);
}

export function shouldDeferAutoCapture({
  activeRequestCount = 0,
  isGenerating = false,
  previousFingerprint = null,
  currentFingerprint = null,
  elapsedMs = 0,
  quietWindowMs = 2000,
} = {}) {
  if (activeRequestCount > 0 || isGenerating) {
    return true;
  }

  if (!currentFingerprint) {
    return true;
  }

  if (previousFingerprint !== currentFingerprint) {
    return true;
  }

  return elapsedMs < quietWindowMs;
}

export function resolveAutoCaptureAction({
  activeRequestCount = 0,
  isGenerating = false,
  previousFingerprint = null,
  currentFingerprint = null,
  elapsedMs = 0,
  quietWindowMs = 2000,
  elapsedSinceDraftMs = 0,
  draftIntervalMs = 10000,
} = {}) {
  if (!currentFingerprint) {
    return 'wait';
  }

  if (activeRequestCount > 0 || isGenerating || previousFingerprint !== currentFingerprint) {
    return elapsedSinceDraftMs >= draftIntervalMs ? 'draft' : 'wait';
  }

  return elapsedMs >= quietWindowMs ? 'final' : 'wait';
}

export function buildAutoCapturedClip(exchange, clipId, model, options = {}) {
  const captureStatus = options.captureStatus || 'final';
  const titleSource = exchange.userText || exchange.assistantText;
  return {
    id: clipId,
    text: exchange.userText
      ? `${exchange.userText}\n\n${exchange.assistantText}`
      : exchange.assistantText,
    title: titleSource.substring(0, 60),
    url: exchange.threadUrl,
    icon: '🔖',
    categoryId: null,
    contentFormat: 'markdown',
    renderMarkdown: exchange.assistantText,
    clipMode: exchange.userText ? 'exchange' : 'user_only',
    blockType: 'exchange',
    pageTitle: exchange.pageTitle,
    threadUrl: exchange.threadUrl,
    sourceMetadata: {
      captureStatus,
      isStreaming: captureStatus === 'draft',
      pairedUserMissing: !exchange.userText,
      turnIndex: exchange.turnIndex ?? null,
    },
    source: {
      platform: exchange.platform,
      siteName: extractSiteName(exchange.threadUrl),
      model,
      conversationUrl: exchange.conversationUrl,
      conversationId: exchange.conversationId,
      assistantMsgIds: [],
      userMessageId: null,
    },
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}
