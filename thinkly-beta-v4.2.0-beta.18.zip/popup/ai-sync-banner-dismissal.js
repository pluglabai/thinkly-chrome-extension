'use strict';

export const AI_SYNC_BANNER_DISMISSED_AT_KEY = 'aiSyncBannerDismissedAt';
export const AI_SYNC_BANNER_DISMISS_MS = 24 * 60 * 60 * 1000;

export async function shouldShowAiSyncBanner(storageArea, options = {}) {
  const {
    isAuthenticated = false,
    now = Date.now()
  } = options;

  if (isAuthenticated) {
    return false;
  }

  const data = await storageArea.get(AI_SYNC_BANNER_DISMISSED_AT_KEY);
  const dismissedAt = Number(data?.[AI_SYNC_BANNER_DISMISSED_AT_KEY]);

  if (!Number.isFinite(dismissedAt) || dismissedAt <= 0) {
    return true;
  }

  return now - dismissedAt >= AI_SYNC_BANNER_DISMISS_MS;
}

export async function dismissAiSyncBanner(storageArea, options = {}) {
  const dismissedAt = options.dismissedAt ?? Date.now();
  await storageArea.set({
    [AI_SYNC_BANNER_DISMISSED_AT_KEY]: dismissedAt
  });
  return dismissedAt;
}
