'use strict';

export const CLIP_REVIEW_STATE_KEY = 'clipReviewState';

function nowTimestamp(now = Date.now) {
  return now();
}

export async function readClipReviewState(storage) {
  const result = await storage.get([CLIP_REVIEW_STATE_KEY]);
  const value = result?.[CLIP_REVIEW_STATE_KEY];
  return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
}

export async function writeClipReviewState(storage, reviewState) {
  await storage.set({ [CLIP_REVIEW_STATE_KEY]: reviewState });
  return reviewState;
}

export async function markClipReviewed(storage, clipIds, options = {}) {
  const ids = Array.isArray(clipIds) ? clipIds : [clipIds];
  const reviewState = await readClipReviewState(storage);
  const reviewedAt = options.reviewedAt || nowTimestamp(options.now);

  for (const id of ids.filter(Boolean)) {
    reviewState[id] = {
      status: 'reviewed',
      reviewedAt,
      updatedAt: reviewedAt
    };
  }

  return writeClipReviewState(storage, reviewState);
}

export async function markClipToReview(storage, clipIds) {
  const ids = Array.isArray(clipIds) ? clipIds : [clipIds];
  const reviewState = await readClipReviewState(storage);
  const updatedAt = nowTimestamp();

  for (const id of ids.filter(Boolean)) {
    reviewState[id] = {
      status: 'needs_review',
      updatedAt
    };
  }

  return writeClipReviewState(storage, reviewState);
}

export async function removeClipReviewState(storage, clipIds) {
  const ids = Array.isArray(clipIds) ? clipIds : [clipIds];
  const reviewState = await readClipReviewState(storage);

  for (const id of ids.filter(Boolean)) {
    delete reviewState[id];
  }

  return writeClipReviewState(storage, reviewState);
}
