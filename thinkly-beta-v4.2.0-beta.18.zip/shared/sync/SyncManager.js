'use strict';

import StorageManager from '../StorageManager.js';
import AuthManager from './AuthManager.js';
import ApiClient from './ApiClient.js';
import SyncQueue from './SyncQueue.js';
import ConflictResolver from './ConflictResolver.js';
import {
  serializeSyncCategory,
  serializeSyncClip,
  toSyncPushPayload
} from './sync-payload.js';
import { isClipReviewed, normalizeRemoteClip } from '../clip-state.js';
import { STORAGE_KEYS, DEFAULT_CATEGORIES } from '../constants.js';

/**
 * SyncManager - Orchestrates sync between local storage and server
 * Implements offline-first with background sync
 * @class
 */
export default class SyncManager {
  static SYNC_STATE_KEY = 'syncState';
  static SYNC_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

  constructor() {
    this.storage = new StorageManager();
    this.authManager = new AuthManager();
    this.apiClient = new ApiClient(this.authManager);
    this.syncQueue = new SyncQueue();
    this.conflictResolver = new ConflictResolver();
    this.isSyncing = false;
  }

  /**
   * Get current sync state
   * @returns {Promise<Object>}
   */
  async getSyncState() {
    const state = await this.storage.get(SyncManager.SYNC_STATE_KEY);
    return state || {
      lastSyncAt: 0,
      lastPushAt: 0,
      lastPullAt: 0,
      status: 'idle',
      error: null,
    };
  }

  /**
   * Update sync state
   * @private
   * @param {Object} updates
   */
  async _updateSyncState(updates) {
    const current = await this.getSyncState();
    await this.storage.set(SyncManager.SYNC_STATE_KEY, {
      ...current,
      ...updates,
    });
  }

  /**
   * Perform full sync (push + pull)
   * @returns {Promise<Object>} Sync results
   */
  async sync() {
    if (this.isSyncing) {
      console.log('[SyncManager] Sync already in progress');
      return { skipped: true };
    }

    const isAuth = await this.authManager.isAuthenticated();
    if (!isAuth) {
      console.log('[SyncManager] Not authenticated, skipping sync');
      return { skipped: true, reason: 'not_authenticated' };
    }

    this.isSyncing = true;
    await this._updateSyncState({ status: 'syncing' });

    try {
      // Push local changes first
      const pushResult = await this.push();

      // Then pull remote changes
      const pullResult = await this.pull();

      const now = Date.now();
      await this._updateSyncState({
        status: 'idle',
        lastSyncAt: now,
        error: null,
      });

      console.log('[SyncManager] Sync completed successfully');
      return { push: pushResult, pull: pullResult };
    } catch (error) {
      console.error('[SyncManager] Sync error:', error);
      await this._updateSyncState({
        status: 'error',
        error: error.message,
      });
      throw error;
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Push local changes to server
   * @returns {Promise<Object>}
   */
  async push() {
    const operations = await this.syncQueue.getGroupedOperations();
    const reviewedClipOps = operations.clips.filter((op) => (
      op.operation === 'delete' || isClipReviewed(op.data)
    ));

    // Always include all local categories so defaults reach the server.
    // The server uses upsert (create-or-update) so duplicates are safe.
    const localCategoriesObj = await this.storage.get(STORAGE_KEYS.CATEGORIES) || {};

    // Also include DEFAULT_CATEGORIES from constants — pull may have erased them
    // from local storage (server-authoritative merge), but they should still
    // reach the server at least once.
    const allLocalIds = new Set(Object.keys(localCategoriesObj));
    const defaultsNotInLocal = DEFAULT_CATEGORIES
      .filter(cat => !allLocalIds.has(cat.id))
      .reduce((obj, cat) => { obj[cat.id] = cat; return obj; }, {});
    const mergedCategoriesObj = { ...defaultsNotInLocal, ...localCategoriesObj };

    const queuedCategoryIds = new Set(operations.categories.map(op => op.data.id));
    const localOnlyCategories = Object.values(mergedCategoriesObj)
      .filter(cat => !cat.deletedAt && !queuedCategoryIds.has(cat.id))
      .map(cat => ({ operation: 'create', data: cat }));

    const allCategoryOps = [...operations.categories, ...localOnlyCategories];

    if (reviewedClipOps.length === 0 && allCategoryOps.length === 0) {
      return { skipped: true, reason: 'no_pending' };
    }

    // Transform data to match backend schema
    const transformedOps = toSyncPushPayload({
      clips: reviewedClipOps,
      categories: allCategoryOps
    });

    try {
      const result = await this.apiClient.syncPush(transformedOps);

      // Clear queue on success
      await this.syncQueue.clear();

      await this._updateSyncState({ lastPushAt: Date.now() });

      return result;
    } catch (error) {
      console.error('[SyncManager] Push error:', error);
      throw error;
    }
  }

  /**
   * Push a single clip operation immediately (real-time sync)
   * @param {string} operation - 'create', 'update', 'delete'
   * @param {Object} clip - Clip data
   * @returns {Promise<Object>} Push result
   * @throws {Error} If not authenticated or push fails
   */
  async pushImmediate(operation, clip) {
    const isAuth = await this.authManager.isAuthenticated();
    if (!isAuth) {
      throw new Error('Not authenticated');
    }

    if (operation !== 'delete' && !isClipReviewed(clip)) {
      return { skipped: true, reason: 'not_reviewed' };
    }

    const transformedClip = this._transformClipForAPI(clip);

    const payload = {
      clips: [{
        operation,
        data: transformedClip
      }],
      categories: []
    };

    try {
      const result = await this.apiClient.syncPush(payload);
      
      // Remove this specific clip from queue since it's been synced
      await this.syncQueue.removeItem('clip', clip.id);
      
      console.log('[SyncManager] Immediate push successful:', clip.id);
      return result;
    } catch (error) {
      console.error('[SyncManager] Immediate push error:', error);
      throw error;
    }
  }

  /**
   * Transform clip data for API (flatten source and metadata)
   * @private
   * @param {Object} clip
   * @returns {Object}
   */
  _transformClipForAPI(clip) {
    return serializeSyncClip(clip);
  }

  /**
   * Transform category data for API (flatten if needed)
   * @private
   * @param {Object} category
   * @returns {Object}
   */
  _transformCategoryForAPI(category) {
    return serializeSyncCategory(category);
  }

  /**
   * Pull remote changes
   * @returns {Promise<Object>}
   */
  async pull() {
    const state = await this.getSyncState();
    const since = state.lastPullAt || 0;

    try {
      const result = await this.apiClient.syncPull(since);
      const { clips: remoteClips, categories: remoteCategories, cursor } = result;

      // Merge clips
      if (remoteClips && remoteClips.length > 0) {
        await this._mergeClips(remoteClips);
      }

      // Merge categories
      if (remoteCategories && remoteCategories.length > 0) {
        await this._mergeCategories(remoteCategories);
      }

      await this._updateSyncState({ lastPullAt: cursor });

      return {
        clips: remoteClips?.length || 0,
        categories: remoteCategories?.length || 0,
        cursor,
      };
    } catch (error) {
      console.error('[SyncManager] Pull error:', error);
      throw error;
    }
  }

  /**
   * Merge remote clips into local storage
   * @private
   * @param {Array} remoteClips
   */
  async _mergeClips(remoteClips) {
    const localClips = await this.storage.get(STORAGE_KEYS.CLIPS) || [];
    const normalizedRemoteClips = remoteClips.map(normalizeRemoteClip);

    const { merged, conflicts } = this.conflictResolver.mergeArrays(
      localClips,
      normalizedRemoteClips,
      'id'
    );

    // Log conflicts for debugging
    if (conflicts.length > 0) {
      console.log('[SyncManager] Clip conflicts resolved:', conflicts.length);
    }

    // Separate deleted items
    const { active } = this.conflictResolver.separateDeleted(merged);

    // Sort by createdAt descending (most recent first)
    active.sort((a, b) => b.createdAt - a.createdAt);

    await this.storage.set(STORAGE_KEYS.CLIPS, active);
  }

  /**
   * Merge remote categories into local storage
   * @private
   * @param {Array} remoteCategories
   */
  async _mergeCategories(remoteCategories) {
    // Guard: never overwrite local with empty — caller already checks, but defensive
    if (!remoteCategories || remoteCategories.length === 0) return;

    // Server-authoritative: replace local categories entirely with server data.
    // This ensures DEFAULT_CATEGORIES don't persist over server state.
    // Remote categories with deletedAt are excluded (soft-deleted).
    const categoriesObj = {};
    for (const remote of remoteCategories) {
      if (remote.deletedAt) continue;
      categoriesObj[remote.id] = {
        id: remote.id,
        name: remote.name,
        parentId: remote.parentId || null,
        icon: remote.icon || '📂',
        order: remote.sortOrder ?? remote.order ?? 0,
        createdAt: remote.createdAt,
        updatedAt: remote.updatedAt,
      };
    }

    await this.storage.set(STORAGE_KEYS.CATEGORIES, categoriesObj);
    console.log('[SyncManager] Categories replaced from server:', Object.keys(categoriesObj).length);
  }

  /**
   * Queue a clip operation for sync
   * @param {string} operation - 'create', 'update', 'delete'
   * @param {Object} clip
   * @returns {Promise<void>}
   */
  async queueClipSync(operation, clip) {
    await this.syncQueue.enqueue('clip', operation, clip);
  }

  /**
   * Queue a category operation for sync
   * @param {string} operation - 'create', 'update', 'delete'
   * @param {Object} category
   * @returns {Promise<void>}
   */
  async queueCategorySync(operation, category) {
    await this.syncQueue.enqueue('category', operation, category);
  }

  /**
   * Initialize sync alarm for background sync
   * Call this from service worker
   */
  async initializeBackgroundSync() {
    // Create alarm for periodic sync
    chrome.alarms.create('thinkly-sync', {
      periodInMinutes: 5,
    });

    console.log('[SyncManager] Background sync initialized');
  }

  /**
   * Handle sync alarm
   * Call this from service worker alarm handler
   */
  async handleSyncAlarm() {
    console.log('[SyncManager] Background sync triggered');
    try {
      await this.sync();
    } catch (error) {
      console.error('[SyncManager] Background sync failed:', error);
    }
  }
}
