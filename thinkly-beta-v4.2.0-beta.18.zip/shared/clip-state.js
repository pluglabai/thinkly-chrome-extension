'use strict';

import { detectPlatform, extractSiteName } from './utils.js';

export const CLIP_PLATFORMS = ['chatgpt', 'claude', 'gemini', 'web', 'other', 'openclaw'];

const PLATFORM_SET = new Set(CLIP_PLATFORMS);

function normalizePlatform(value) {
  if (typeof value !== 'string') return null;
  const normalized = value.trim().toLowerCase();

  if (normalized.includes('chatgpt') || normalized.includes('chat.openai')) return 'chatgpt';
  if (normalized.includes('claude')) return 'claude';
  if (normalized.includes('gemini')) return 'gemini';
  if (PLATFORM_SET.has(normalized)) return normalized;
  return null;
}

export function getClipPlatform(clip = {}) {
  const source = clip.source || {};
  const explicitPlatform = normalizePlatform(source.platform || clip.platform);
  if (explicitPlatform) return explicitPlatform;

  const sitePlatform = normalizePlatform(source.siteName || clip.siteName);
  if (sitePlatform) return sitePlatform;

  const urlCandidates = [
    clip.url,
    clip.threadUrl,
    clip.conversationUrl,
    source.url,
    source.threadUrl,
    source.conversationUrl
  ];

  for (const url of urlCandidates) {
    const detected = detectPlatform(url);
    if (detected && detected !== 'other') return detected;
  }

  return 'other';
}

export function getClipSiteName(clip = {}) {
  const source = clip.source || {};
  const siteName = source.siteName || clip.siteName;
  if (typeof siteName === 'string' && siteName.trim()) return siteName.trim();

  const url = clip.url || clip.threadUrl || clip.conversationUrl
    || source.url || source.threadUrl || source.conversationUrl;
  return extractSiteName(url);
}

export function isClipSynced(clip = {}) {
  return (
    clip.syncStatus === 'synced'
    || clip.syncStatus === 'sent'
    || Number.isInteger(clip.sentToWebAt)
  );
}

export function isAutoCapturedClip(clip = {}) {
  return (
    clip.clipMode === 'exchange'
    || clip.blockType === 'exchange'
    || (typeof clip.id === 'string' && clip.id.startsWith('clip_auto_'))
    || Number.isInteger(clip.sourceMetadata?.turnIndex)
  );
}

export function isClipReviewed(clip = {}, reviewState = {}) {
  const state = reviewState[clip.id];
  if (state?.status === 'reviewed') return true;
  if (state?.status === 'needs_review') return false;

  if (clip.reviewStatus === 'reviewed' || Number.isInteger(clip.reviewedAt)) return true;
  if (clip.reviewStatus === 'needs_review') return false;

  if (isClipSynced(clip)) return true;
  return !isAutoCapturedClip(clip);
}

export function normalizeRemoteClip(remoteClip = {}) {
  const platform = getClipPlatform(remoteClip);
  return {
    ...remoteClip,
    syncStatus: 'synced',
    reviewStatus: 'reviewed',
    source: {
      ...(remoteClip.source || {}),
      platform,
      siteName: getClipSiteName(remoteClip),
      model: remoteClip.source?.model || remoteClip.model || null,
      conversationUrl: remoteClip.source?.conversationUrl || remoteClip.conversationUrl || null,
      conversationId: remoteClip.source?.conversationId || remoteClip.conversationId || null
    }
  };
}
