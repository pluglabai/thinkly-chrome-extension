'use strict';

import { isCaptureV2Ready } from './capture-v2-settings.js';

export function shouldOpenCaptureV2Onboarding({ reason, captureV2 }) {
  if (reason !== 'install' && reason !== 'update') {
    return false;
  }

  return !isCaptureV2Ready(captureV2);
}

export function getCaptureV2OnboardingUrl() {
  return 'onboarding/index.html';
}
