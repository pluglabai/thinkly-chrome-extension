'use strict';

/**
 * Storage keys for chrome.storage.local
 * @constant
 */
export const STORAGE_KEYS = {
  CLIPS: 'clips',
  CATEGORIES: 'categories',
  SETTINGS: 'settings'
};

/**
 * Validation rules for data schemas
 * @constant
 */
export const VALIDATION_RULES = {
  // Clip validation
  CLIP_TEXT_MIN: 1,
  CLIP_TEXT_MAX: 100000,
  CLIP_TITLE_MIN: 1,
  CLIP_TITLE_MAX: 200,

  // Category validation
  CATEGORY_NAME_MIN: 1,
  CATEGORY_NAME_MAX: 50,
  MAX_CATEGORY_DEPTH: 2,

  // Platform validation
  VALID_PLATFORMS: ['chatgpt', 'claude', 'gemini', 'web', 'other']
};

/**
 * Default categories created on extension install
 * @constant
 */
export const DEFAULT_CATEGORIES = [
  {
    id: 'cat_general',
    name: 'General',
    parentId: null,
    icon: '📂',
    order: 0,
    createdAt: Date.now(),
    updatedAt: Date.now()
  },
  {
    id: 'cat_work',
    name: 'Work',
    parentId: null,
    icon: '💼',
    order: 1,
    createdAt: Date.now(),
    updatedAt: Date.now()
  },
  {
    id: 'cat_personal',
    name: 'Personal',
    parentId: null,
    icon: '🧠',
    order: 2,
    createdAt: Date.now(),
    updatedAt: Date.now()
  },
  {
    id: 'cat_ideas',
    name: 'Ideas',
    parentId: null,
    icon: '💡',
    order: 3,
    createdAt: Date.now(),
    updatedAt: Date.now()
  }
];

/**
 * Performance targets from constitution
 * @constant
 */
export const PERFORMANCE_TARGETS = {
  INLINE_POPUP_MS: 500,
  SEARCH_RESPONSE_MS: 100,
  POPUP_LOAD_MS: 500,
  MEMORY_LIMIT_MB: 50,
  STORAGE_OPERATION_MS: 50
};

/**
 * URL patterns for platform detection and conversation ID extraction
 * @constant
 */
export const URL_PATTERNS = {
  CHATGPT: /(?:chat\.openai\.com|chatgpt\.com)\/(?:c|share)\/([a-zA-Z0-9-]+)/,
  CLAUDE: /claude\.ai\/chat\/([a-zA-Z0-9-]+)/,
  GEMINI: /gemini\.google\.com\/app\/([a-zA-Z0-9-]+)/
};

/**
 * Message types for communication between extension components
 * @constant
 */
export const MESSAGE_TYPES = {
  CLIP_SAVED: 'CLIP_SAVED',
  ERROR: 'ERROR'
};

/**
 * Quick Save defaults
 * @constant
 */
export const QUICK_SAVE_DEFAULTS = {
  CATEGORY_ID: null,
  ICON: '💡'
};

/**
 * Available icons for clip selection (reduced set for Stage 2)
 * @constant
 */
export const CLIP_ICONS = ['💡', '⚠️', '✅', '❓', '🔖'];

// ========================================
// PLG Growth Constants (F2)
// ========================================

/**
 * Export branding configuration
 * @constant
 */
export const BRANDING = {
  /** Footer text added to all exports */
  FOOTER: '\n\n---\n\n💡 Saved with [Thinkly](https://thinkly.pluglab.ai) — Capture AI insights before they disappear',

  /** Twitter handle for social sharing */
  TWITTER_HANDLE: '@thinkly_app'
};

/**
 * Cloud storage quota limits
 * @constant
 */
export const QUOTA_LIMITS = {
  /** Free plan cloud clip limit */
  FREE_CLOUD_CLIPS: 50,

  /** Pro plan cloud clip limit */
  PRO_CLOUD_CLIPS: Infinity,

  /** Warning threshold (80% of limit) */
  WARNING_THRESHOLD: 0.8,

  /** Cache duration for quota API (5 minutes) */
  CACHE_DURATION_MS: 5 * 60 * 1000
};

/**
 * Subscription pricing
 * @constant
 */
export const PRICING = {
  PRO: {
    monthly: 4.99,
    currency: 'USD',
    features: [
      'unlimited_cloud_clips',
      'branding_removal',
      'advanced_search',
      'priority_support'
    ]
  }
};

/**
 * User-facing upgrade messages
 * @constant
 */
export const UPGRADE_MESSAGES = {
  /** Message when approaching limit */
  APPROACHING_LIMIT: (remaining) =>
    `${remaining} clips remaining — Upgrade for unlimited`,

  /** Message when limit reached */
  LIMIT_REACHED: "You've reached your cloud storage limit. Upgrade to Pro for unlimited clips.",

  /** Modal title */
  PRO_TITLE: "🚀 Upgrade to Thinkly Pro",

  /** CTA button text */
  PRO_CTA: "Upgrade Now",

  /** Continue without upgrading */
  CONTINUE_LOCAL: "Continue with Local Only"
};

/**
 * Clip-related event names
 * @constant
 */
export const CLIP_EVENTS = {
  QUOTA_EXCEEDED: 'quotaExceeded',
  SYNC_FAILED: 'syncFailed',
  SYNC_SUCCESS: 'syncSuccess',
  CLIP_SAVED: 'clipSaved'
};
