'use strict';

import { URL_PATTERNS } from './constants.js';

/**
 * Generate unique ID with prefix
 * @param {string} prefix - ID prefix ('clip', 'cat', etc.)
 * @returns {string} Unique ID like "clip_1234567890_abc123"
 * @example
 * generateId('clip') // => "clip_1737123456789_x7k3p9"
 */
export function generateId(prefix) {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 11);  // 9 chars
  return `${prefix}_${timestamp}_${random}`;
}

/**
 * Format timestamp as relative time
 * @param {number} timestamp - Unix timestamp (ms)
 * @returns {string} "Just now", "2m ago", "3h ago", "5d ago"
 * @example
 * getRelativeTime(Date.now() - 120000) // => "2m ago"
 */
export function getRelativeTime(timestamp) {
  if (!timestamp || typeof timestamp !== 'number') {
    return 'Unknown time';
  }

  const seconds = Math.floor((Date.now() - timestamp) / 1000);

  if (seconds < 0) return 'Just now';  // Future timestamp
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

/**
 * Truncate text with ellipsis
 * @param {string} text - Text to truncate
 * @param {number} maxLength - Maximum length (including ellipsis)
 * @returns {string} Truncated text with "..." if needed
 * @example
 * truncate('Hello world', 8) // => "Hello..."
 */
export function truncate(text, maxLength) {
  if (!text) return '';
  if (text.length <= maxLength) return text;
  if (maxLength <= 3) return '';  // Not enough room for "..."
  return text.substring(0, maxLength - 3) + '...';
}

/**
 * Detect AI platform from URL
 * @param {string} url - Conversation URL
 * @returns {'chatgpt'|'claude'|'gemini'|'other'} Platform identifier
 * @example
 * detectPlatform('https://chat.openai.com/c/abc123') // => 'chatgpt'
 */
export function detectPlatform(url) {
  if (!url || typeof url !== 'string') return 'other';

  if (url.includes('chat.openai.com') || url.includes('chatgpt.com')) return 'chatgpt';
  if (url.includes('claude.ai')) return 'claude';
  if (url.includes('gemini.google.com')) return 'gemini';
  return 'other';
}

/**
 * Extract conversation ID from ChatGPT, Claude, or Gemini URL
 * @param {string} url - Conversation URL
 * @returns {string|null} Conversation ID or null if not found
 * @example
 * extractConversationId('https://chat.openai.com/c/abc-123') // => 'abc-123'
 * extractConversationId('https://claude.ai/chat/xyz-789') // => 'xyz-789'
 */
export function extractConversationId(url) {
  if (!url || typeof url !== 'string') return null;

  // Try ChatGPT pattern: /c/{id} or /share/{id}
  const chatgptMatch = url.match(URL_PATTERNS.CHATGPT);
  if (chatgptMatch) return chatgptMatch[1];

  // Try Claude pattern: /chat/{id}
  const claudeMatch = url.match(URL_PATTERNS.CLAUDE);
  if (claudeMatch) return claudeMatch[1];

  const geminiMatch = url.match(URL_PATTERNS.GEMINI);
  if (geminiMatch) return geminiMatch[1];

  return null;  // No match found
}

/**
 * Extract user-friendly site name from URL
 * @param {string} url - Page URL
 * @returns {string} Site name ("ChatGPT", "Claude", or domain)
 * @example
 * extractSiteName('https://chat.openai.com/c/abc-123') // => 'ChatGPT'
 * extractSiteName('https://claude.ai/chat/xyz') // => 'Claude'
 * extractSiteName('https://example.com/page') // => 'example.com'
 */
/**
 * Escape HTML special characters to prevent XSS
 * @param {string} str - String to escape
 * @returns {string} Escaped string safe for innerHTML
 * @example
 * escapeHTML('<script>alert("xss")</script>') // => '&lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt;'
 */
export function escapeHTML(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function extractSiteName(url) {
  if (!url || typeof url !== 'string') return 'Unknown';

  // Check for known AI platforms
  if (url.includes('chat.openai.com') || url.includes('chatgpt.com')) return 'ChatGPT';
  if (url.includes('claude.ai')) return 'Claude';
  if (url.includes('gemini.google.com')) return 'Gemini';

  // Extract domain for generic URLs
  try {
    const urlObj = new URL(url);
    return urlObj.hostname.replace('www.', '');
  } catch {
    return 'Unknown';
  }
}
