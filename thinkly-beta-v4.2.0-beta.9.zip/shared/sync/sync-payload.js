'use strict';

const VALID_API_PLATFORMS = new Set(['chatgpt', 'claude', 'web', 'other', 'openclaw']);

function positiveTimestamp(value, fallback = Date.now()) {
  return Number.isInteger(value) && value > 0 ? value : fallback;
}

function nonNegativeInteger(value) {
  return Number.isInteger(value) && value >= 0 ? value : null;
}

function nullableUrl(value) {
  if (!value || typeof value !== 'string') return null;

  try {
    return new URL(value).toString();
  } catch {
    return null;
  }
}

function nullableString(value, maxLength) {
  if (typeof value !== 'string') return null;

  const trimmed = value.trim();
  if (!trimmed) return null;
  return trimmed.slice(0, maxLength);
}

function titleForClip(clip) {
  const title = nullableString(clip.title, 200);
  if (title) return title;

  const textTitle = nullableString(clip.text, 200);
  if (textTitle) return textTitle;

  return 'Untitled capture';
}

function platformForApi(platform) {
  return VALID_API_PLATFORMS.has(platform) ? platform : 'other';
}

export function serializeSyncClip(clip = {}, { now = Date.now(), includeDeletedAt = true } = {}) {
  const createdAt = positiveTimestamp(clip.createdAt, now);
  const updatedAt = positiveTimestamp(clip.updatedAt, createdAt);
  const metadata = clip.metadata || {};
  const source = clip.source || {};

  const data = {
    id: nullableString(clip.id, 200) || `clip_${createdAt}`,
    text: nullableString(clip.text, 100000) || titleForClip(clip),
    title: titleForClip(clip),
    url: nullableUrl(clip.url || source.url),
    icon: nullableString(clip.icon, 10),
    platform: platformForApi(source.platform || clip.platform || 'other'),
    siteName: nullableString(source.siteName || clip.siteName, 100),
    model: nullableString(source.model || clip.model, 50),
    conversationUrl: nullableUrl(source.conversationUrl || clip.conversationUrl),
    conversationId: nullableString(source.conversationId || clip.conversationId, 100),
    categoryId: nullableString(clip.categoryId, 50),
    wordCount: nonNegativeInteger(metadata.wordCount ?? clip.wordCount),
    characterCount: nonNegativeInteger(metadata.characterCount ?? clip.characterCount),
    language: nullableString(metadata.language || clip.language, 10) || 'en',
    tags: Array.isArray(clip.tags) ? clip.tags.filter(tag => typeof tag === 'string') : [],
    starred: clip.starred === true,
    createdAt,
    updatedAt
  };

  if (includeDeletedAt) {
    data.deletedAt = Number.isInteger(clip.deletedAt) && clip.deletedAt > 0 ? clip.deletedAt : null;
  }

  return data;
}

export function serializeSyncCategory(category = {}, { now = Date.now() } = {}) {
  const createdAt = positiveTimestamp(category.createdAt, now);
  const updatedAt = positiveTimestamp(category.updatedAt, createdAt);
  const sortOrder = Number.isInteger(category.sortOrder)
    ? category.sortOrder
    : Number.isInteger(category.order)
      ? category.order
      : 0;

  return {
    id: nullableString(category.id, 200) || `cat_${createdAt}`,
    name: nullableString(category.name, 50) || 'Untitled',
    parentId: nullableString(category.parentId, 50),
    icon: nullableString(category.icon, 10),
    sortOrder: Math.max(0, sortOrder),
    createdAt,
    updatedAt,
    deletedAt: Number.isInteger(category.deletedAt) && category.deletedAt > 0
      ? category.deletedAt
      : null
  };
}

export function toSyncPushPayload(operations = {}, options = {}) {
  return {
    clips: (operations.clips || []).map(op => ({
      operation: op.operation,
      data: serializeSyncClip(op.data, options)
    })),
    categories: (operations.categories || []).map(op => ({
      operation: op.operation,
      data: serializeSyncCategory(op.data, options)
    }))
  };
}
