'use strict';

import AuthManager from './AuthManager.js';
import { getApiBaseUrl } from '../config.js';

/**
 * ApiClient - HTTP client for Thinkly API with auth handling
 * @class
 */
export default class ApiClient {
  constructor(authManager = null) {
    this.authManager = authManager || new AuthManager();
    this.baseUrl = getApiBaseUrl();
  }

  /**
   * Make authenticated API request
   * @param {string} path - API endpoint path
   * @param {Object} options - Fetch options
   * @returns {Promise<Object>} Response data
   * @throws {Error} If request fails
   */
  async request(path, options = {}) {
    const token = await this.authManager.getAccessToken();

    if (!token) {
      throw new Error('Not authenticated');
    }

    const url = `${this.baseUrl}${path}`;
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
      ...options.headers,
    };

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      // Handle 401 - try to refresh token
      if (response.status === 401) {
        const newToken = await this.authManager.refreshToken();
        headers['Authorization'] = `Bearer ${newToken}`;

        const retryResponse = await fetch(url, {
          ...options,
          headers,
        });

        if (!retryResponse.ok) {
          throw new Error(`API error: ${retryResponse.status}`);
        }

        return retryResponse.json();
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (errorData.details) {
          console.error('[ApiClient] API error details:', errorData.details);
        }

        const error = new Error(errorData.error || `API error: ${response.status}`);
        error.status = response.status;
        error.details = errorData.details;
        throw error;
      }

      return response.json();
    } catch (error) {
      console.error('[ApiClient] Request error:', error);
      throw error;
    }
  }

  /**
   * GET request
   * @param {string} path
   * @param {Object} params - Query parameters
   * @returns {Promise<Object>}
   */
  async get(path, params = {}) {
    const queryString = new URLSearchParams(params).toString();
    const fullPath = queryString ? `${path}?${queryString}` : path;

    return this.request(fullPath, { method: 'GET' });
  }

  /**
   * POST request
   * @param {string} path
   * @param {Object} data - Request body
   * @returns {Promise<Object>}
   */
  async post(path, data = {}) {
    return this.request(path, {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  /**
   * PATCH request
   * @param {string} path
   * @param {Object} data - Request body
   * @returns {Promise<Object>}
   */
  async patch(path, data = {}) {
    return this.request(path, {
      method: 'PATCH',
      body: JSON.stringify(data),
    });
  }

  /**
   * DELETE request
   * @param {string} path
   * @returns {Promise<Object>}
   */
  async delete(path) {
    return this.request(path, { method: 'DELETE' });
  }

  // ===== Clips API =====

  /**
   * Get clips with optional filtering
   * @param {Object} params - Query params (page, pageSize, categoryId, search)
   * @returns {Promise<Object>}
   */
  async getClips(params = {}) {
    return this.get('/api/clips', params);
  }

  /**
   * Create clip
   * @param {Object} clip
   * @returns {Promise<Object>}
   */
  async createClip(clip) {
    return this.post('/api/clips', clip);
  }

  /**
   * Update clip
   * @param {string} id
   * @param {Object} updates
   * @returns {Promise<Object>}
   */
  async updateClip(id, updates) {
    return this.patch(`/api/clips/${id}`, updates);
  }

  /**
   * Delete clip
   * @param {string} id
   * @returns {Promise<Object>}
   */
  async deleteClip(id) {
    return this.delete(`/api/clips/${id}`);
  }

  // ===== Categories API =====

  /**
   * Get all categories
   * @returns {Promise<Object>}
   */
  async getCategories() {
    return this.get('/api/categories');
  }

  /**
   * Create category
   * @param {Object} category
   * @returns {Promise<Object>}
   */
  async createCategory(category) {
    return this.post('/api/categories', category);
  }

  /**
   * Update category
   * @param {string} id
   * @param {Object} updates
   * @returns {Promise<Object>}
   */
  async updateCategory(id, updates) {
    return this.patch(`/api/categories/${id}`, updates);
  }

  /**
   * Delete category
   * @param {string} id
   * @returns {Promise<Object>}
   */
  async deleteCategory(id) {
    return this.delete(`/api/categories/${id}`);
  }

  // ===== Sync API =====

  /**
   * Push local changes to server
   * @param {Object} data - { clips, categories }
   * @returns {Promise<Object>}
   */
  async syncPush(data) {
    return this.post('/api/sync/push', data);
  }

  /**
   * Pull changes from server since cursor
   * @param {number} since - Timestamp cursor
   * @returns {Promise<Object>}
   */
  async syncPull(since) {
    return this.post('/api/sync/pull', { since });
  }
}
