'use strict';

export const CAPTURE_V2_ONBOARDING_VERSION = 'extension-v2';
export const SETTINGS_STORAGE_KEY = 'settings';

export function buildDefaultCaptureV2Settings() {
  return {
    onboardingVersion: null,
    completedAt: null,
    completionSource: null,
    globalEnabled: true,
    platforms: {
      chatgpt: true,
      claude: true,
      gemini: true
    },
    pageOverrides: {},
    lastPopupTab: 'feed'
  };
}

function mergeCaptureV2Settings(existing = {}) {
  const defaults = buildDefaultCaptureV2Settings();

  return {
    ...defaults,
    ...existing,
    platforms: {
      ...defaults.platforms,
      ...(existing.platforms || {})
    },
    pageOverrides: {
      ...defaults.pageOverrides,
      ...(existing.pageOverrides || {})
    }
  };
}

export async function getCaptureV2Settings(storage = chrome.storage.local) {
  const result = await storage.get([SETTINGS_STORAGE_KEY]);
  const settings = result?.[SETTINGS_STORAGE_KEY] || {};
  return mergeCaptureV2Settings(settings.captureV2);
}

async function persistCaptureV2Settings(storage, captureV2) {
  const result = await storage.get([SETTINGS_STORAGE_KEY]);
  const settings = result?.[SETTINGS_STORAGE_KEY] || {};

  await storage.set({
    [SETTINGS_STORAGE_KEY]: {
      ...settings,
      captureV2
    }
  });
}

export async function markCaptureV2OnboardingCompleted(
  storage = chrome.storage.local,
  {
    completionSource = 'onboarding',
    completedAt = Date.now(),
    platforms = buildDefaultCaptureV2Settings().platforms
  } = {}
) {
  const current = await getCaptureV2Settings(storage);
  const next = mergeCaptureV2Settings({
    ...current,
    onboardingVersion: CAPTURE_V2_ONBOARDING_VERSION,
    completedAt,
    completionSource,
    platforms
  });

  await persistCaptureV2Settings(storage, next);
  return next;
}

export async function updateCaptureV2PlatformPreference(
  storage = chrome.storage.local,
  platform,
  enabled
) {
  const current = await getCaptureV2Settings(storage);
  const next = mergeCaptureV2Settings({
    ...current,
    platforms: {
      ...current.platforms,
      [platform]: enabled
    }
  });

  await persistCaptureV2Settings(storage, next);
  return next;
}

export async function updateCaptureV2GlobalPreference(
  storage = chrome.storage.local,
  enabled
) {
  const current = await getCaptureV2Settings(storage);
  const next = mergeCaptureV2Settings({
    ...current,
    globalEnabled: enabled === true
  });

  await persistCaptureV2Settings(storage, next);
  return next;
}

export function isCaptureV2Ready(captureV2Settings) {
  return (
    captureV2Settings?.onboardingVersion === CAPTURE_V2_ONBOARDING_VERSION
    && typeof captureV2Settings?.completedAt === 'number'
    && captureV2Settings.completedAt > 0
  );
}
