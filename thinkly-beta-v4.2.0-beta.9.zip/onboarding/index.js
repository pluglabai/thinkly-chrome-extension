'use strict';

import { markCaptureV2OnboardingCompleted } from '../shared/capture-v2-settings.js';

function getPlatformsFromForm() {
  return {
    chatgpt: document.getElementById('toggle-chatgpt').checked,
    claude: document.getElementById('toggle-claude').checked,
    gemini: document.getElementById('toggle-gemini').checked
  };
}

async function handleSubmit() {
  const button = document.getElementById('start-capture-btn');
  const status = document.getElementById('setup-status');

  button.disabled = true;
  status.textContent = 'Saving your capture preferences...';

  try {
    await markCaptureV2OnboardingCompleted(chrome.storage.local, {
      completionSource: 'onboarding',
      platforms: getPlatformsFromForm()
    });
    status.textContent = 'Capture is on. Opening Thinkly...';

    if (canOpenExtensionPopup()) {
      try {
        await chrome.action.openPopup();
        status.textContent = 'Capture is on. You can close this tab.';
        return;
      } catch (error) {
        console.warn('[Thinkly] Could not open extension popup from onboarding:', error);
      }
    }

    status.textContent = 'Capture is on. Open Thinkly from the extension icon when you are ready.';
  } catch (error) {
    console.error('[Thinkly] Failed to finish onboarding:', error);
    status.textContent = 'Could not save settings. Please try again.';
    button.disabled = false;
  }
}

function canOpenExtensionPopup() {
  return typeof chrome !== 'undefined'
    && typeof chrome.action?.openPopup === 'function';
}

document.getElementById('start-capture-btn')?.addEventListener('click', handleSubmit);
