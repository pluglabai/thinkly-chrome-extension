'use strict';

export const POPUP_NEW_COPY = {
  documentTitle: 'Thinkly - AI Capture Library',
  headerSubtitle: 'Save the ideas worth revisiting',
  loginActionLabel: 'Sync & organize free',
  loginActionTitle: 'Sign in to sync captures and use free AI organization',
  aiSyncBannerTitle: 'Sync for free AI organization',
  aiSyncBannerCopy: 'Back up your local captures and let Thinkly group the useful parts automatically.',
  searchPlaceholder: 'Search saved ideas',
  exportActionLabel: 'Export saved ideas',
  emptyTitle: 'Your best AI answers will appear here',
  emptyDescription: 'Select text or finish setup for automatic capture.',
  cloudSectionCopy: 'Sign in to send captures to your Thinkly workspace and organize them on the web.',
  syncNowLabel: 'Sync to workspace',
  modalTitle: 'Clip Title',
  selectionPrompt: 'Select clips to export',
  syncCompleteToast: 'Synced to your workspace',
  loginSuccessToast: 'Workspace sync is on',
  deleteDialog: {
    title: 'Delete clip?',
    message: 'This will remove the clip from your local library.',
    confirmText: 'Delete',
    cancelText: 'Keep',
  },
};

export function applyPopupNewCopy(doc, copy = POPUP_NEW_COPY) {
  doc.title = copy.documentTitle;

  const headerSubtitle = doc.querySelector('.popup-subtitle');
  if (headerSubtitle) {
    headerSubtitle.textContent = copy.headerSubtitle;
  }

  doc.querySelectorAll('[data-login-action]').forEach((loginButton) => {
    loginButton.textContent = copy.loginActionLabel;
    loginButton.setAttribute('title', copy.loginActionTitle);
    loginButton.setAttribute('aria-label', copy.loginActionTitle);
  });

  doc.querySelectorAll('.ai-sync-banner-title').forEach((element) => {
    element.textContent = copy.aiSyncBannerTitle;
  });

  doc.querySelectorAll('.ai-sync-banner-copy').forEach((element) => {
    element.textContent = copy.aiSyncBannerCopy;
  });

  const searchInput = doc.getElementById('search-input');
  if (searchInput) {
    searchInput.setAttribute('placeholder', copy.searchPlaceholder);
  }

  const exportLabel = doc.getElementById('settings-export-label');
  if (exportLabel) {
    exportLabel.textContent = copy.exportActionLabel;
  }

  const settingsExport = doc.getElementById('settings-export');
  if (settingsExport) {
    settingsExport.textContent = copy.exportActionLabel;
  }

  const emptyTitle = doc.getElementById('empty-state-title');
  if (emptyTitle) {
    emptyTitle.textContent = copy.emptyTitle;
  }

  const emptyDescription = doc.getElementById('empty-state-desc');
  if (emptyDescription) {
    emptyDescription.textContent = copy.emptyDescription;
  }

  const cloudSectionCopy = doc.getElementById('settings-cloud-copy');
  if (cloudSectionCopy) {
    cloudSectionCopy.textContent = copy.cloudSectionCopy;
  }

  const syncNowButton = doc.getElementById('settings-sync-now');
  if (syncNowButton) {
    syncNowButton.textContent = copy.syncNowLabel;
  }

  const modalTitle = doc.getElementById('modal-title');
  if (modalTitle && !modalTitle.textContent?.trim()) {
    modalTitle.textContent = copy.modalTitle;
  }
}
