'use strict';

import { VALIDATION_RULES } from '../shared/constants.js';

/**
 * Get selected text from current selection
 * @returns {string} Selected text (trimmed)
 * @example
 * const text = getSelectedText();
 */
export function getSelectedText() {
  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0) {
    return '';
  }

  return selection.toString().trim();
}

/**
 * Validate if selection is valid for clipping
 * @param {string} text - Selected text
 * @returns {boolean} True if valid
 * @example
 * if (isValidSelection(text)) { ... }
 */
export function isValidSelection(text) {
  if (!text || typeof text !== 'string') {
    return false;
  }

  const trimmed = text.trim();

  // Must be at least 3 characters
  if (trimmed.length < 3) {
    return false;
  }

  // Must not exceed clip text hard cap
  if (trimmed.length > VALIDATION_RULES.CLIP_TEXT_MAX) {
    console.warn(`[Thinkly] Selection too long: ${trimmed.length} chars (limit: ${VALIDATION_RULES.CLIP_TEXT_MAX})`);
    return false;
  }

  return true;
}

/**
 * Get coordinates of current selection
 * @returns {Object|null} Coordinates {x, y, width, height} or null
 * @example
 * const coords = getSelectionCoordinates();
 * // { x: 100, y: 200, width: 150, height: 20 }
 */
export function getSelectionCoordinates() {
  const selection = window.getSelection();

  if (!selection || selection.rangeCount === 0) {
    return null;
  }

  const range = selection.getRangeAt(0);
  const rect = range.getBoundingClientRect();

  return {
    x: rect.left + window.scrollX,
    y: rect.top + window.scrollY,
    width: rect.width,
    height: rect.height
  };
}

/**
 * Debounce function execution
 * @param {Function} func - Function to debounce
 * @param {number} delay - Delay in milliseconds
 * @returns {Function} Debounced function
 * @example
 * const debouncedFn = debounce(() => console.log('Hello'), 250);
 */
export function debounce(func, delay) {
  let timeoutId;

  return function debounced(...args) {
    const context = this;

    clearTimeout(timeoutId);

    timeoutId = setTimeout(() => {
      func.apply(context, args);
    }, delay);
  };
}
