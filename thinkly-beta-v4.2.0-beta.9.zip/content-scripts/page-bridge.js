'use strict';

(() => {
  const FLAG = '__THINKLY_PAGE_BRIDGE_ACTIVE__';

  if (window[FLAG]) {
    return;
  }

  window[FLAG] = true;

  function post(type, detail = {}) {
    window.postMessage(
      {
        source: 'thinkly-page-bridge',
        type,
        detail
      },
      window.location.origin
    );
  }

  const originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = async (...args) => {
      const requestUrl = typeof args[0] === 'string' ? args[0] : args[0]?.url;
      post('network:fetch:start', { requestUrl });
      try {
        const response = await originalFetch(...args);
        post('network:fetch:complete', {
          requestUrl,
          responseUrl: response?.url || requestUrl,
          ok: response?.ok === true,
          status: response?.status || 0
        });
        return response;
      } catch (error) {
        post('network:fetch:error', {
          requestUrl,
          message: error?.message || 'Unknown fetch error'
        });
        throw error;
      }
    };
  }

  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function open(method, url, ...rest) {
    this.__thinklyRequestUrl = url;
    return originalOpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function send(...args) {
    post('network:xhr:start', { requestUrl: this.__thinklyRequestUrl || null });
    this.addEventListener('loadend', () => {
      post('network:xhr:complete', {
        requestUrl: this.__thinklyRequestUrl || null,
        status: this.status
      });
    });
    return originalSend.apply(this, args);
  };
})();
