'use strict';

/**
 * SelectionBar - Floating action bar for export selection mode
 * @class
 */
export default class SelectionBar {
  /**
   * Create SelectionBar instance
   * @param {Object} options
   * @param {string} options.containerId - Container element ID
   * @param {number} options.selectedCount - Number of selected clips
   * @param {number} options.totalCount - Total number of clips
   * @param {Function} options.onClose - Close button handler
   * @param {Function} options.onSelectAll - Select all button handler
   * @param {Function} options.onExport - Export button handler
   * @param {Function} [options.onDelete] - Delete selected button handler
   */
  constructor(options) {
    this.containerId = options.containerId;
    this.selectedCount = options.selectedCount || 0;
    this.totalCount = options.totalCount || 0;
    this.onClose = options.onClose || (() => {});
    this.onSelectAll = options.onSelectAll || (() => {});
    this.onExport = options.onExport || (() => {});
    this.onDelete = options.onDelete || null;
    this.container = null;
    this.element = null;
  }

  /**
   * Check if all clips are selected
   * @returns {boolean}
   */
  get isAllSelected() {
    return this.selectedCount === this.totalCount && this.totalCount > 0;
  }

  /**
   * Render the selection bar
   */
  render() {
    this.container = document.getElementById(this.containerId);
    if (!this.container) {
      console.error('[SelectionBar] Container not found:', this.containerId);
      return;
    }

    const html = `
      <div class="selection-bar">
        <!-- Close button -->
        <button class="selection-close-btn" title="Cancel selection">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M6 18L18 6M6 6l12 12" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>

        <!-- Divider -->
        <div class="selection-divider"></div>

        <!-- Selected count -->
        <span class="selection-counter">${this.selectedCount} selected</span>

        <!-- Divider -->
        <div class="selection-divider"></div>

        <!-- Select All button -->
        <button class="selection-select-all-btn">
          ${this.isAllSelected ? 'Deselect All' : 'Select All'}
        </button>

        <!-- Export button -->
        <button class="selection-export-btn" ${this.selectedCount === 0 ? 'disabled' : ''}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
          Export Selected
        </button>

        ${this.onDelete ? `
          <button class="selection-delete-btn" ${this.selectedCount === 0 ? 'disabled' : ''}>
            Delete selected
          </button>
        ` : ''}
      </div>
    `;

    this.container.innerHTML = html;
    this.element = this.container.querySelector('.selection-bar');
    this._attachEventListeners();
  }

  /**
   * Attach event listeners
   * @private
   */
  _attachEventListeners() {
    const closeBtn = this.container.querySelector('.selection-close-btn');
    const selectAllBtn = this.container.querySelector('.selection-select-all-btn');
    const exportBtn = this.container.querySelector('.selection-export-btn');
    const deleteBtn = this.container.querySelector('.selection-delete-btn');

    closeBtn.addEventListener('click', () => {
      this.onClose();
    });

    selectAllBtn.addEventListener('click', () => {
      this.onSelectAll();
    });

    exportBtn.addEventListener('click', () => {
      if (this.selectedCount > 0) {
        this.onExport();
      }
    });

    deleteBtn?.addEventListener('click', () => {
      if (this.selectedCount > 0 && this.onDelete) {
        this.onDelete();
      }
    });
  }

  /**
   * Update selection bar state
   * @param {Object} updates
   * @param {number} [updates.selectedCount]
   * @param {number} [updates.totalCount]
   */
  update(updates) {
    if (updates.selectedCount !== undefined) {
      this.selectedCount = updates.selectedCount;
    }
    if (updates.totalCount !== undefined) {
      this.totalCount = updates.totalCount;
    }
    
    // Re-render with new state
    this.render();
  }

  /**
   * Show the selection bar
   */
  show() {
    if (this.element) {
      this.element.style.display = 'flex';
    }
  }

  /**
   * Hide the selection bar
   */
  hide() {
    if (this.element) {
      this.element.style.display = 'none';
    }
  }

  /**
   * Remove the selection bar from DOM
   */
  destroy() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}
