'use strict';

import StorageManager from './StorageManager.js';
import { validateClipData } from './validators.js';
import { STORAGE_KEYS } from './constants.js';
import { normalizeTags } from './TagUtils.js';

/**
 * ClipManager - Manages clip CRUD operations, search, and filtering
 * @class
 * @example
 * const manager = new ClipManager();
 * const clip = await manager.addClip({ text: 'Sample', ... });
 */
export default class ClipManager {
  /**
   * Create ClipManager instance
   * @param {Object} options - Optional configuration
   * @param {Object} options.syncManager - SyncManager instance for cloud sync
   * @param {Object} options.quotaManager - QuotaManager instance for quota checking
   */
  constructor(options = {}) {
    this.storage = new StorageManager();
    this.syncManager = options.syncManager || null;
    this.quotaManager = options.quotaManager || null;
    this.eventListeners = new Map();
  }

  /**
   * Set the sync manager for cloud sync operations
   * @param {Object} syncManager - SyncManager instance
   */
  setSyncManager(syncManager) {
    this.syncManager = syncManager;
  }

  /**
   * Set the quota manager for quota checking
   * @param {Object} quotaManager - QuotaManager instance
   */
  setQuotaManager(quotaManager) {
    this.quotaManager = quotaManager;
  }

  /**
   * Add event listener
   * @param {string} event - Event name
   * @param {Function} handler - Event handler
   */
  on(event, handler) {
    if (!this.eventListeners.has(event)) {
      this.eventListeners.set(event, []);
    }
    this.eventListeners.get(event).push(handler);
  }

  /**
   * Emit event
   * @param {string} event - Event name
   * @param {*} data - Event data
   * @private
   */
  _emit(event, data) {
    const handlers = this.eventListeners.get(event);
    if (handlers) {
      handlers.forEach(handler => handler(data));
    }
  }

  /**
   * Add new clip with validation
   * @param {Object} clip - Clip data
   * @returns {Promise<Object>} Added clip
   * @throws {Error} Validation error
   * @example
   * const clip = await manager.addClip({
   *   id: 'clip_test',
   *   text: 'Sample text',
   *   title: 'Title',
   *   url: 'https://chat.openai.com/c/123',
   *   icon: '💡',
   *   categoryId: 'cat_general',
   *   source: { platform: 'chatgpt', ... },
   *   createdAt: Date.now()
   * });
   */
  async addClip(clip) {
    // Auto-generate metadata if not provided
    if (!clip.metadata) {
      clip.metadata = this.generateMetadata(clip.text);
    }

    // Add updatedAt if not provided
    const now = Date.now();
    if (!clip.updatedAt) {
      clip.updatedAt = now;
    }

    // Add tags default if not provided
    if (!clip.tags) {
      clip.tags = [];
    }
    if (clip.categoryId === undefined) {
      clip.categoryId = null;
    }
    // Normalize tags (trim, lowercase, dedup)
    clip.tags = normalizeTags(clip.tags);

    // Add starred default if not provided
    if (clip.starred === undefined || clip.starred === null) {
      clip.starred = false;
    }
    
    // MVP: Set syncStatus to 'local' by default (not sent to web yet)
    if (!clip.syncStatus) {
      clip.syncStatus = 'local';
    }

    // Validate clip data
    const validatedClip = validateClipData(clip);

    // Get existing clips
    const clips = await this.getAllClips();

    // Prepend new clip (most recent first)
    clips.unshift(validatedClip);

    // Save
    await this.storage.set(STORAGE_KEYS.CLIPS, clips);

    // Try to sync to cloud (with quota check)
    await this._tryCloudSync('create', validatedClip);

    return validatedClip;
  }

  /**
   * Try to sync to cloud with quota check
   * Performs immediate sync (real-time) instead of queuing
   * @private
   * @param {string} operation - Operation type ('create', 'update', 'delete')
   * @param {Object} clip - Clip data
   */
  async _tryCloudSync(operation, clip) {
    if (!this.syncManager) return;

    if (typeof this.syncManager.authManager?.isAuthenticated === 'function') {
      try {
        const isAuthenticated = await this.syncManager.authManager.isAuthenticated();
        if (!isAuthenticated) {
          return;
        }
      } catch (error) {
        console.warn('[ClipManager] Skipping cloud sync auth check:', error);
        this._emit('syncError', { clip, error: error.message });
        return;
      }
    }

    // Check quota if quotaManager is available (only for create/update)
    if (this.quotaManager && operation !== 'delete') {
      try {
        const canAddToCloud = await this.quotaManager.canAddToCloud();
        if (!canAddToCloud) {
          // Emit quota exceeded event
          this._emit('quotaExceeded', clip);
          return;
        }
      } catch (error) {
        console.warn('[ClipManager] Quota check failed, continuing with queued sync:', error);
        this._emit('syncError', { clip, error: error.message });
      }
    }

    try {
      // Queue for sync (as backup for offline). Sync is best-effort after local save.
      await this.syncManager.queueClipSync(operation, clip);

      // Immediate sync - push right away (real-time)
      await this.syncManager.pushImmediate(operation, clip);
      // Update syncStatus to 'synced' on success
      await this._updateClipSyncStatus(clip.id, 'synced');
      this._emit('syncSuccess', clip);
    } catch (error) {
      console.error('[ClipManager] Immediate sync failed, will retry later:', error);
      // Keep in queue for background retry
      this._emit('syncError', { clip, error: error.message });
    }
  }

  /**
   * Update clip sync status
   * @private
   * @param {string} clipId - Clip ID
   * @param {string} status - Sync status ('local', 'syncing', 'synced', 'error')
   */
  async _updateClipSyncStatus(clipId, status) {
    try {
      const clips = await this.getAllClips();
      const clipIndex = clips.findIndex(c => c.id === clipId);
      if (clipIndex !== -1) {
        clips[clipIndex].syncStatus = status;
        await this.storage.set(STORAGE_KEYS.CLIPS, clips);
      }
    } catch (error) {
      console.error('[ClipManager] Failed to update sync status:', error);
    }
  }

  /**
   * Save clip (alias for addClip for backward compatibility)
   * @param {Object} clip - Clip data
   * @returns {Promise<Object>} Saved clip
   */
  async saveClip(clip) {
    return this.addClip(clip);
  }

  /**
   * Get clip by ID
   * @param {string} clipId - Clip ID
   * @returns {Promise<Object|null>} Clip or null if not found
   * @example
   * const clip = await manager.getClip('clip_123');
   */
  async getClip(clipId) {
    const clips = await this.storage.get(STORAGE_KEYS.CLIPS);

    if (!clips || !Array.isArray(clips)) {
      return null;
    }

    return clips.find(clip => clip.id === clipId) || null;
  }

  /**
   * Get all clips
   * @returns {Promise<Array>} All clips (most recent first)
   * @example
   * const clips = await manager.getAllClips();
   */
  async getAllClips() {
    const clips = await this.storage.get(STORAGE_KEYS.CLIPS);
    return clips || [];
  }

  /**
   * Update existing clip
   * @param {string} clipId - Clip ID
   * @param {Object} updates - Fields to update
   * @param {Object} options - Update behavior flags
   * @param {boolean} options.validate - Whether to revalidate the full clip
   * @param {boolean} options.sync - Whether to trigger cloud sync
   * @returns {Promise<Object>} Updated clip
   * @throws {Error} If clip not found or validation fails
   * @example
   * const updated = await manager.updateClip('clip_123', {
   *   title: 'New Title',
   *   categoryId: 'cat_work'
   * });
   */
  async updateClip(clipId, updates, options = {}) {
    const clips = await this.getAllClips();
    const clipIndex = clips.findIndex(c => c.id === clipId);
    const shouldValidate = options.validate !== false;
    const shouldSync = options.sync !== false;

    if (clipIndex === -1) {
      throw new Error('Clip not found');
    }

    // Merge updates with new updatedAt timestamp
    const updatedClip = {
      ...clips[clipIndex],
      ...updates,
      id: clips[clipIndex].id,  // Prevent ID change
      createdAt: clips[clipIndex].createdAt,  // Prevent createdAt change
      updatedAt: Date.now()  // Always update timestamp
    };

    const finalClip = shouldValidate ? validateClipData(updatedClip) : updatedClip;

    // Replace in array
    clips[clipIndex] = finalClip;

    // Save
    await this.storage.set(STORAGE_KEYS.CLIPS, clips);

    if (shouldSync) {
      await this._tryCloudSync('update', finalClip);
    }

    return finalClip;
  }

  /**
   * Delete clip by ID
   * @param {string} clipId - Clip ID
   * @returns {Promise<Object>} Deleted clip data (for sync)
   * @throws {Error} If clip not found
   * @example
   * await manager.deleteClip('clip_123');
   */
  async deleteClip(clipId) {
    const clips = await this.getAllClips();
    const clipIndex = clips.findIndex(c => c.id === clipId);

    if (clipIndex === -1) {
      throw new Error('Clip not found');
    }

    // Get clip data for sync before removing
    const deletedClip = {
      ...clips[clipIndex],
      updatedAt: Date.now(),
      deletedAt: Date.now()
    };

    // Remove clip
    clips.splice(clipIndex, 1);

    // Save
    await this.storage.set(STORAGE_KEYS.CLIPS, clips);

    // Try to sync to cloud (delete doesn't check quota)
    await this._tryCloudSync('delete', deletedClip);

    return deletedClip;
  }

  /**
   * Get clips filtered by category
   * @param {string} categoryId - Category ID
   * @returns {Promise<Array>} Clips in category
   * @example
   * const workClips = await manager.getClipsByCategory('cat_work');
   */
  async getClipsByCategory(categoryId) {
    const clips = await this.getAllClips();
    return clips.filter(clip => clip.categoryId === categoryId);
  }

  /**
   * Search clips by query (case-insensitive)
   * @param {string} query - Search query
   * @returns {Promise<Array>} Matching clips
   * @example
   * const results = await manager.searchClips('javascript');
   */
  async searchClips(query) {
    const clips = await this.getAllClips();

    if (!query || query.trim() === '') {
      return clips;
    }

    const lowerQuery = query.toLowerCase();

    return clips.filter(clip => {
      const titleMatch = clip.title && clip.title.toLowerCase().includes(lowerQuery);
      const textMatch = clip.text && clip.text.toLowerCase().includes(lowerQuery);
      return titleMatch || textMatch;
    });
  }

  /**
   * Get clips from same conversation (conversation threading)
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<Array>} Related clips sorted by timestamp (oldest first)
   * @example
   * const related = await manager.getRelatedClips('conv-123');
   */
  async getRelatedClips(conversationId) {
    if (!conversationId) {
      return [];
    }

    const clips = await this.getAllClips();

    const relatedClips = clips.filter(clip =>
      clip.source && clip.source.conversationId === conversationId
    );

    // Sort by timestamp (oldest first for conversation flow)
    return relatedClips.sort((a, b) => a.createdAt - b.createdAt);
  }

  /**
   * Generate metadata from clip text
   * @param {string} text - Clip text
   * @returns {Object} Metadata object
   * @example
   * const metadata = manager.generateMetadata('Hello world');
   * // { wordCount: 2, characterCount: 11, language: 'en' }
   */
  generateMetadata(text) {
    if (!text) {
      return {
        wordCount: 0,
        characterCount: 0,
        language: 'en'
      };
    }

    // Count words (split by whitespace and filter empty strings)
    const words = text.trim().split(/\s+/).filter(word => word.length > 0);
    const wordCount = words.length;

    // Count characters
    const characterCount = text.length;

    return {
      wordCount,
      characterCount,
      language: 'en'  // MVP only supports English
    };
  }
}
