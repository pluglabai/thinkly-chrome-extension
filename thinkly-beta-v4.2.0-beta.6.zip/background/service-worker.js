'use strict';

/**
 * Thinkly Background Service Worker
 * Handles extension lifecycle, commands, and background sync
 */

// Import managers statically (Service Worker doesn't support dynamic import)
import { AuthManager, SyncManager } from '../shared/sync/index.js';
import { getCaptureV2OnboardingUrl, shouldOpenCaptureV2Onboarding } from '../shared/capture-v2-onboarding.js';
import { getCaptureV2Settings } from '../shared/capture-v2-settings.js';

// Initialize managers
let syncManager = null;
let authManager = null;

const getSyncManager = () => {
  if (!syncManager) {
    syncManager = new SyncManager();
  }
  return syncManager;
};

const getAuthManager = () => {
  if (!authManager) {
    authManager = new AuthManager();
  }
  return authManager;
};

// MVP Feature Flags (injected at build time)
const MVP_AUTO_SYNC_ENABLED = typeof THINKLY_AUTO_SYNC !== 'undefined' ? THINKLY_AUTO_SYNC : false;
const MVP_PULL_ENABLED = typeof THINKLY_PULL_ENABLED !== 'undefined' ? THINKLY_PULL_ENABLED : false;

console.log('[Thinkly] Service worker started at:', new Date().toISOString());
console.log('[Thinkly] MVP Flags - Auto Sync:', MVP_AUTO_SYNC_ENABLED, '| Pull:', MVP_PULL_ENABLED);

// Listen for extension installation
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('[Thinkly] Extension installed:', details.reason);

  if (details.reason === 'install') {
    console.log('[Thinkly] First time installation - welcome!');
  } else if (details.reason === 'update') {
    console.log('[Thinkly] Extension updated to version:', chrome.runtime.getManifest().version);
  }

  try {
    const captureV2 = await getCaptureV2Settings(chrome.storage.local);
    if (shouldOpenCaptureV2Onboarding({ reason: details.reason, captureV2 })) {
      await chrome.tabs.create({
        url: getCaptureV2OnboardingUrl()
      });
    }
  } catch (error) {
    console.error('[Thinkly] Failed to evaluate onboarding state:', error);
  }

  // Initialize background sync alarm (MVP: disabled by default)
  if (MVP_AUTO_SYNC_ENABLED) {
    chrome.alarms.create('thinkly-sync', {
      periodInMinutes: 5,
    });
    console.log('[Thinkly] Background sync alarm created');
  } else {
    // Clear any existing alarm
    chrome.alarms.clear('thinkly-sync');
    console.log('[Thinkly] Background sync disabled (MVP mode)');
  }
});

// Listen for keyboard command (Cmd+Shift+S / Ctrl+Shift+S)
chrome.commands.onCommand.addListener((command) => {
  console.log('[Thinkly] Command received:', command);

  if (command === 'save-clip') {
    console.log('[Thinkly] Save clip command triggered');
  }
});

// Listen for alarms (background sync) - MVP: gated by feature flag
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'thinkly-sync') {
    if (!MVP_AUTO_SYNC_ENABLED) {
      console.log('[Thinkly] Background sync alarm ignored (MVP mode)');
      return;
    }
    
    console.log('[Thinkly] Background sync alarm triggered');

    try {
      const manager = getSyncManager();
      await manager.sync();
      console.log('[Thinkly] Background sync completed');
    } catch (error) {
      console.error('[Thinkly] Background sync failed:', error);
    }
  }
});

// Listen for messages from content scripts or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Thinkly] Message received:', message);

  // Handle async operations
  const handleMessage = async () => {
    switch (message.type) {
      case 'CLIP_SAVED':
        console.log('[Thinkly] Clip saved successfully:', message.clipId);
        return { success: true };

      case 'ERROR':
        console.error('[Thinkly] Error:', message.error);
        return { success: false };

      case 'SYNC_NOW':
        console.log('[Thinkly] Manual sync requested');
        try {
          const manager = getSyncManager();
          const result = await manager.sync();
          return { success: true, result };
        } catch (error) {
          console.error('[Thinkly] Manual sync failed:', error);
          return { success: false, error: error.message };
        }

      case 'GET_SYNC_STATE':
        try {
          const manager = getSyncManager();
          const state = await manager.getSyncState();
          return { success: true, state };
        } catch (error) {
          return { success: false, error: error.message };
        }

      case 'GET_AUTH_STATE':
        try {
          const manager = getAuthManager();
          const state = await manager.getAuthState();
          return { success: true, state };
        } catch (error) {
          return { success: false, error: error.message };
        }

      case 'SIGN_IN':
        try {
          const manager = getAuthManager();
          const result = await manager.signIn();
          return { success: true, result };
        } catch (error) {
          console.error('[Thinkly] Sign in failed:', error);
          return { success: false, error: error.message };
        }

      case 'SIGN_OUT':
        try {
          const manager = getAuthManager();
          await manager.signOut();
          return { success: true };
        } catch (error) {
          console.error('[Thinkly] Sign out failed:', error);
          return { success: false, error: error.message };
        }

      default:
        console.log('[Thinkly] Unknown message type:', message.type);
        return { success: false, error: 'Unknown message type' };
    }
  };

  // Execute async handler and send response
  handleMessage().then(sendResponse);

  // Return true to indicate we'll send response asynchronously
  return true;
});

// Keep service worker alive when needed
chrome.runtime.onConnect.addListener((port) => {
  console.log('[Thinkly] Port connected:', port.name);

  port.onDisconnect.addListener(() => {
    console.log('[Thinkly] Port disconnected:', port.name);
  });
});
