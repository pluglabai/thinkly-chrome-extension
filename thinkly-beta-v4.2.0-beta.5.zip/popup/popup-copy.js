'use strict';

export const POPUP_NEW_COPY = {
  documentTitle: 'Thinkly - AI Capture Library',
  headerSubtitle: 'Save the ideas worth revisiting',
  loginActionLabel: 'Sync & organize',
  loginActionTitle: 'Sync & organize your captures',
  searchPlaceholder: 'Search saved ideas',
  exportActionLabel: 'Export saved ideas',
  emptyTitle: 'Your best AI answers will appear here',
  emptyDescription: 'Select text or finish setup for automatic capture.',
  cloudSectionCopy: 'Sign in to send captures to your Thinkly workspace and organize them on the web.',
  syncNowLabel: 'Sync to workspace',
  modalTitle: 'Clip Title',
  selectionPrompt: 'Select clips to export',
  syncCompleteToast: 'Synced to your workspace',
  loginSuccessToast: 'Workspace sync is on',
  deleteDialog: {
    title: 'Delete clip?',
    message: 'This will remove the clip from your local library.',
    confirmText: 'Delete',
    cancelText: 'Keep',
  },
};

export function applyPopupNewCopy(doc, copy = POPUP_NEW_COPY) {
  doc.title = copy.documentTitle;

  const headerSubtitle = doc.querySelector('.popup-subtitle');
  if (headerSubtitle) {
    headerSubtitle.textContent = copy.headerSubtitle;
  }

  const loginButton = doc.getElementById('login-btn');
  if (loginButton) {
    loginButton.textContent = copy.loginActionLabel;
    loginButton.setAttribute('title', copy.loginActionTitle);
  }

  const searchInput = doc.getElementById('search-input');
  if (searchInput) {
    searchInput.setAttribute('placeholder', copy.searchPlaceholder);
  }

  const exportLabel = doc.getElementById('settings-export-label');
  if (exportLabel) {
    exportLabel.textContent = copy.exportActionLabel;
  }

  const settingsExport = doc.getElementById('settings-export');
  if (settingsExport) {
    settingsExport.textContent = copy.exportActionLabel;
  }

  const emptyTitle = doc.getElementById('empty-state-title');
  if (emptyTitle) {
    emptyTitle.textContent = copy.emptyTitle;
  }

  const emptyDescription = doc.getElementById('empty-state-desc');
  if (emptyDescription) {
    emptyDescription.textContent = copy.emptyDescription;
  }

  const cloudSectionCopy = doc.getElementById('settings-cloud-copy');
  if (cloudSectionCopy) {
    cloudSectionCopy.textContent = copy.cloudSectionCopy;
  }

  const syncNowButton = doc.getElementById('settings-sync-now');
  if (syncNowButton) {
    syncNowButton.textContent = copy.syncNowLabel;
  }

  const modalTitle = doc.getElementById('modal-title');
  if (modalTitle && !modalTitle.textContent?.trim()) {
    modalTitle.textContent = copy.modalTitle;
  }
}
