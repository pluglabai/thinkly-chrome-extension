'use strict';

import { extractConversationId, extractSiteName } from '../shared/utils.js';

const EXCLUDED_CAPTURE_SELECTOR = [
  'nav',
  'header',
  'footer',
  'aside',
  'dialog',
  '[role="alert"]',
  '[role="banner"]',
  '[role="button"]',
  'button',
  '.thinkly-status-pill',
  '.thinkly-mini-toolbar',
  '.thinkly-save-panel',
].join(',');

function hashCaptureKey(rawKey) {
  let hash = 2166136261;
  for (let index = 0; index < rawKey.length; index += 1) {
    hash ^= rawKey.charCodeAt(index);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }

  return Math.abs(hash >>> 0).toString(36);
}

export function buildAutoCaptureClipId(exchange) {
  const rawKey = [
    exchange.platform,
    exchange.conversationId || exchange.threadUrl,
    String(exchange.turnIndex ?? 'unknown'),
    exchange.userText || '',
  ].join('::');

  return `clip_auto_${hashCaptureKey(rawKey)}`;
}

export function buildAutoCaptureContentFingerprint(exchange) {
  const rawKey = [
    buildAutoCaptureClipId(exchange),
    exchange.userText || '',
    exchange.assistantText || '',
  ].join('::');

  return hashCaptureKey(rawKey);
}

export function shouldDeferAutoCapture({
  activeRequestCount = 0,
  isGenerating = false,
  previousFingerprint = null,
  currentFingerprint = null,
  elapsedMs = 0,
  quietWindowMs = 2000,
} = {}) {
  if (activeRequestCount > 0 || isGenerating) {
    return true;
  }

  if (!currentFingerprint) {
    return true;
  }

  if (previousFingerprint !== currentFingerprint) {
    return true;
  }

  return elapsedMs < quietWindowMs;
}

export function resolveAutoCaptureAction({
  force = false,
  activeRequestCount = 0,
  isGenerating = false,
  previousFingerprint = null,
  currentFingerprint = null,
  elapsedMs = 0,
  quietWindowMs = 2000,
  elapsedSinceDraftMs = 0,
  draftIntervalMs = 10000,
  staleGeneratingMs = 0,
  maxGeneratingMs = 10000,
} = {}) {
  if (!currentFingerprint) {
    return 'wait';
  }

  if (force) {
    return 'final';
  }

  const hasStaleGeneratingIndicator = isGenerating && staleGeneratingMs >= maxGeneratingMs;
  const shouldWaitForGenerating = isGenerating && !hasStaleGeneratingIndicator;

  if (activeRequestCount > 0 || shouldWaitForGenerating || previousFingerprint !== currentFingerprint) {
    return elapsedSinceDraftMs >= draftIntervalMs ? 'draft' : 'wait';
  }

  return elapsedMs >= quietWindowMs ? 'final' : 'wait';
}

export function isProviderChromeText(text = '') {
  return false;
}

export function isAutoCaptureExchangeEligible(exchange, _options = {}) {
  if (!exchange || !normalizeCaptureText(exchange.assistantText)) {
    return {
      eligible: false,
      reason: 'missing_assistant_turn',
    };
  }

  return {
    eligible: true,
    reason: 'eligible',
  };
}

export function readLatestVisibleExchangeFromDom({
  document: doc = globalThis.document,
  platform,
  url = globalThis.location?.href || '',
  title = doc?.title || '',
} = {}) {
  const exchanges = readVisibleExchangesFromDom({
    document: doc,
    platform,
    url,
    title,
  });

  return exchanges.at(-1) || null;
}

export function readVisibleExchangesFromDom({
  document: doc = globalThis.document,
  platform,
  url = globalThis.location?.href || '',
  title = doc?.title || '',
} = {}) {
  const blocks = getMessageBlocksForPlatform(platform, doc);
  if (blocks.length === 0) {
    return [];
  }

  return blocks
    .map((block, index) => {
      if (block.role !== 'assistant' || !block.text) {
        return null;
      }

      const userBlock = [...blocks.slice(0, index)]
        .reverse()
        .find((candidate) => candidate.role === 'user' && candidate.text);

      return {
        platform,
        title: userBlock?.text || block.text,
        userText: userBlock?.text || '',
        assistantText: block.text,
        turnIndex: index,
        conversationUrl: url,
        conversationId: extractConversationId(url),
        pageTitle: title,
        threadUrl: url,
        confidence: block.confidence === 'high' && userBlock?.confidence === 'high'
          ? 'high'
          : 'fallback',
      };
    })
    .filter(Boolean);
}

export function getMessageBlocksForPlatform(platform, doc = globalThis.document) {
  if (!doc) {
    return [];
  }

  if (platform === 'chatgpt') {
    return Array.from(doc.querySelectorAll('[data-message-author-role]'))
      .map((node) => buildRoleBlock(
        node,
        node.getAttribute('data-message-author-role') === 'assistant' ? 'assistant' : 'user',
        'high'
      ))
      .filter(Boolean);
  }

  const roleBlocks = Array.from(doc.querySelectorAll([
    '[data-testid*="message"]',
    '[data-testid*="turn"]',
    '[data-testid*="response"]',
    '[data-testid*="conversation-turn"]',
    '[data-message-author-role]',
    '[data-author]',
    '[data-role]',
  ].join(',')))
    .map((node) => {
      const role = inferRoleFromNode(node);
      return role ? buildRoleBlock(node, role, 'high') : null;
    })
    .filter(Boolean);

  if (roleBlocks.length > 0) {
    return roleBlocks;
  }

  return Array.from(doc.querySelectorAll('main div, main article, main p, main section'))
    .map((node) => {
      if (isExcludedCaptureNode(node)) {
        return null;
      }

      const text = normalizeCaptureText(node.innerText || node.textContent || '');
      return text.length > 20 ? text : null;
    })
    .filter((text, index, arr) => text && arr.indexOf(text) === index)
    .slice(-12)
    .map((text, index) => ({
      role: index % 2 === 0 ? 'user' : 'assistant',
      text,
      confidence: 'fallback',
    }));
}

export function buildAutoCapturedClip(exchange, clipId, model, options = {}) {
  const captureStatus = options.captureStatus || 'final';
  const titleSource = exchange.userText || exchange.assistantText;
  return {
    id: clipId,
    text: exchange.userText
      ? `${exchange.userText}\n\n${exchange.assistantText}`
      : exchange.assistantText,
    title: titleSource.substring(0, 60),
    url: exchange.threadUrl,
    icon: '🔖',
    categoryId: null,
    contentFormat: 'markdown',
    renderMarkdown: exchange.assistantText,
    clipMode: exchange.userText ? 'exchange' : 'user_only',
    blockType: 'exchange',
    pageTitle: exchange.pageTitle,
    threadUrl: exchange.threadUrl,
    sourceMetadata: {
      captureStatus,
      isStreaming: captureStatus === 'draft',
      pairedUserMissing: !exchange.userText,
      turnIndex: exchange.turnIndex ?? null,
    },
    source: {
      platform: exchange.platform,
      siteName: extractSiteName(exchange.threadUrl),
      model,
      conversationUrl: exchange.conversationUrl,
      conversationId: exchange.conversationId,
      assistantMsgIds: [],
      userMessageId: null,
    },
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
}

function buildRoleBlock(node, role, confidence) {
  if (isExcludedCaptureNode(node)) {
    return null;
  }

  const text = normalizeCaptureText(node.innerText || node.textContent || '');
  if (text.length <= 20) {
    return null;
  }

  return {
    role,
    text,
    confidence,
  };
}

function inferRoleFromNode(node) {
  const marker = [
    node.getAttribute('data-testid'),
    node.getAttribute('data-message-author-role'),
    node.getAttribute('data-author'),
    node.getAttribute('data-role'),
    node.getAttribute('aria-label'),
  ].filter(Boolean).join(' ').toLowerCase();

  if (/user|human|prompt/.test(marker)) {
    return 'user';
  }

  if (/assistant|model|response|answer|claude|gemini|chatgpt/.test(marker)) {
    return 'assistant';
  }

  return null;
}

function isExcludedCaptureNode(node) {
  if (!node || typeof node.closest !== 'function') {
    return true;
  }

  return Boolean(node.closest(EXCLUDED_CAPTURE_SELECTOR));
}

function normalizeCaptureText(text = '') {
  return String(text)
    .replace(/\s+/g, ' ')
    .trim();
}
