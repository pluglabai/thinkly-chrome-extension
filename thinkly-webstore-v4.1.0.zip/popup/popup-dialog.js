'use strict';

const DIALOG_ROOT_CLASS = 'popup-dialog-root';

function removeActiveDialog() {
  const existing = document.querySelector(`.${DIALOG_ROOT_CLASS}`);
  if (existing) {
    existing.remove();
  }
}

function buildDialogElement({
  title,
  message,
  confirmText,
  cancelText,
  isDanger
}) {
  const root = document.createElement('div');
  root.className = DIALOG_ROOT_CLASS;

  const overlay = document.createElement('div');
  overlay.className = 'popup-dialog-overlay';

  const card = document.createElement('div');
  card.className = 'popup-dialog-card';
  card.setAttribute('role', 'dialog');
  card.setAttribute('aria-modal', 'true');
  card.setAttribute('aria-labelledby', 'popup-dialog-title');

  const badge = document.createElement('div');
  badge.className = 'popup-dialog-badge';
  badge.textContent = isDanger ? '⚠️' : '💬';

  const titleEl = document.createElement('h2');
  titleEl.id = 'popup-dialog-title';
  titleEl.className = 'popup-dialog-title';
  titleEl.textContent = title;

  const messageEl = document.createElement('p');
  messageEl.className = 'popup-dialog-message';
  messageEl.textContent = message;

  const actions = document.createElement('div');
  actions.className = 'popup-dialog-actions';

  if (cancelText) {
    const cancelButton = document.createElement('button');
    cancelButton.type = 'button';
    cancelButton.className = 'popup-dialog-action-btn popup-dialog-cancel-btn';
    cancelButton.textContent = cancelText;
    actions.appendChild(cancelButton);
  }

  const confirmButton = document.createElement('button');
  confirmButton.type = 'button';
  confirmButton.className = isDanger
    ? 'popup-dialog-action-btn popup-dialog-confirm-btn danger'
    : 'popup-dialog-action-btn popup-dialog-confirm-btn';
  confirmButton.textContent = confirmText;
  actions.appendChild(confirmButton);

  card.append(badge, titleEl, messageEl, actions);
  root.append(overlay, card);

  return root;
}

function showPopupDialog({
  title = 'Thinkly',
  message,
  confirmText = 'OK',
  cancelText = '',
  isDanger = false
}) {
  removeActiveDialog();

  const dialogRoot = buildDialogElement({
    title,
    message,
    confirmText,
    cancelText,
    isDanger
  });
  document.body.appendChild(dialogRoot);

  return new Promise((resolve) => {
    const cleanup = (result) => {
      document.removeEventListener('keydown', handleEscape);
      dialogRoot.remove();
      resolve(result);
    };

    const handleEscape = (event) => {
      if (event.key === 'Escape') {
        cleanup(false);
      }
    };

    dialogRoot.querySelector('.popup-dialog-overlay')
      ?.addEventListener('click', () => cleanup(false));
    dialogRoot.querySelector('.popup-dialog-confirm-btn')
      ?.addEventListener('click', () => cleanup(true));
    dialogRoot.querySelector('.popup-dialog-cancel-btn')
      ?.addEventListener('click', () => cleanup(false));

    document.addEventListener('keydown', handleEscape);
  });
}

export function showPopupAlert({ title = 'Thinkly', message, buttonText = 'OK' }) {
  return showPopupDialog({
    title,
    message,
    confirmText: buttonText
  });
}

export function showPopupConfirm({
  title = 'Thinkly',
  message,
  confirmText = 'Confirm',
  cancelText = 'Cancel',
  isDanger = true
}) {
  return showPopupDialog({
    title,
    message,
    confirmText,
    cancelText,
    isDanger
  });
}
