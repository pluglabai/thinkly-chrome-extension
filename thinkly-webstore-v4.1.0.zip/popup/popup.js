'use strict';

import ClipManager from '../shared/ClipManager.js';
import CategoryManager from '../shared/CategoryManager.js';
import ExportManager from '../shared/ExportManager.js';
import { getRelativeTime, escapeHTML } from '../shared/utils.js';
import { AuthManager, SyncManager, QuotaManager } from '../shared/sync/index.js';
import { getWebDashboardUrl, getApiBaseUrl } from '../shared/config.js';
import { getCategoryDisplay, toStoredCategoryId } from '../shared/category-display.js';
import StorageManager from '../shared/StorageManager.js';

// MVP Feature Flags (can be overridden by build-time env)
const MVP_AUTO_SYNC_ENABLED = typeof THINKLY_AUTO_SYNC !== 'undefined' ? THINKLY_AUTO_SYNC : false;
const MVP_PULL_ENABLED = typeof THINKLY_PULL_ENABLED !== 'undefined' ? THINKLY_PULL_ENABLED : false;
import QuotaIndicator from './components/QuotaIndicator.js';
import UpgradeModal from './components/UpgradeModal.js';
import SelectionBar from './components/SelectionBar.js';
import FAB from './components/FAB.js';
import CategoryPills, { buildCategoryPillsHTML } from './components/CategoryPills.js';

// Initialize managers
const clipManager = new ClipManager();
const categoryManager = new CategoryManager();
const exportManager = new ExportManager();
const authManager = new AuthManager();
const syncManager = new SyncManager();
const quotaManager = new QuotaManager(syncManager.apiClient);
let quotaIndicator = null;

// State
let allClips = [];
let allCategories = {};
let currentCategoryId = null;
let currentSearchQuery = '';
let currentClip = null;
let exportMode = 'single'; // 'single' or 'grouped'

// Selection Mode State
let isSelectionMode = false;
const selectedClipIds = new Set();
let selectionBar = null;
let currentCategoryForEdit = null; // Track category being edited/deleted
let isAuthenticated = false;
let currentUser = null;
let syncStatePollingInterval = null;

// FAB & Add Panel State (WP05)
let fab = null;
let categoryPills = null;
let currentAddPanelType = null;
let selectedFile = null;

// MVP Debug Storage
const debugStorage = new StorageManager();
const API_URL_STORAGE_KEY = 'thinkly_api_url_override';

/**
 * MVP Debug: Update debug bar with current status
 */
async function updateDebugBar() {
  const debugApi = document.getElementById('debug-api');
  const debugAuth = document.getElementById('debug-auth');
  const unsentCount = document.getElementById('unsent-count');
  const sendAllBtn = document.getElementById('send-all-btn');
  
  // 1. API Base URL
  const baseUrl = await getEffectiveApiUrl();
  const shortUrl = baseUrl.replace('https://', '').replace('http://', '');
  if (debugApi) {
    debugApi.textContent = `API: ${shortUrl}`;
    debugApi.title = baseUrl;
  }
  console.log('[Thinkly] baseUrl =', baseUrl);
  
  // 2. Auth Status
  if (debugAuth) {
    if (isAuthenticated) {
      debugAuth.textContent = 'Auth: logged-in';
      debugAuth.classList.remove('logged-out');
    } else {
      debugAuth.textContent = 'Auth: logged-out';
      debugAuth.classList.add('logged-out');
    }
  }
  console.log('[Thinkly] isAuthenticated =', isAuthenticated);
  
  // 3. Unsent Count (clips with syncStatus !== 'sent')
  const unsentClips = await getUnsentClipsCount();
  if (unsentCount) {
    unsentCount.textContent = unsentClips;
  }
  
  // 4. Show/hide Send All button
  if (sendAllBtn) {
    if (isAuthenticated && unsentClips > 0) {
      sendAllBtn.style.display = 'inline-block';
      sendAllBtn.textContent = `Send All (${unsentClips})`;
    } else {
      sendAllBtn.style.display = 'none';
    }
  }
}

/**
 * Get effective API URL (with override support)
 */
async function getEffectiveApiUrl() {
  const override = await debugStorage.get(API_URL_STORAGE_KEY);
  if (override) {
    return override;
  }
  return getApiBaseUrl();
}

/**
 * Get count of unsent clips (syncStatus !== 'sent')
 */
async function getUnsentClipsCount() {
  const clips = await clipManager.getAllClips();
  return clips.filter(clip => clip.syncStatus !== 'sent').length;
}

/**
 * Get unsent clips for sending
 */
async function getUnsentClips() {
  const clips = await clipManager.getAllClips();
  return clips.filter(clip => clip.syncStatus !== 'sent');
}

/**
 * Toggle API URL between production and localhost
 */
async function toggleApiUrl() {
  const current = await getEffectiveApiUrl();
  const PROD_URL = 'https://thinkly.pluglab.ai';
  const LOCAL_URL = 'http://localhost:3000';
  
  if (current === PROD_URL) {
    await debugStorage.set(API_URL_STORAGE_KEY, LOCAL_URL);
    showToast('Switched to localhost:3000', 'info');
  } else {
    await debugStorage.set(API_URL_STORAGE_KEY, PROD_URL);
    showToast('Switched to production', 'info');
  }
  
  await updateDebugBar();
}

/**
 * Handle Send All button click
 */
async function handleSendAll() {
  const sendAllBtn = document.getElementById('send-all-btn');
  
  // Check auth first - never silently skip
  if (!isAuthenticated) {
    showToast('Login required to send to Web', 'error');
    return;
  }
  
  const unsentClips = await getUnsentClips();
  if (unsentClips.length === 0) {
    showToast('No clips to send', 'info');
    return;
  }
  
  try {
    sendAllBtn.disabled = true;
    sendAllBtn.textContent = 'Sending...';
    
    // Get API URL
    const baseUrl = await getEffectiveApiUrl();
    const endpoint = `${baseUrl}/api/sync/push`;
    
    // Prepare payload (clips only, no tags - server generates them)
    const payload = {
      clips: unsentClips.map(clip => ({
        operation: 'create',
        data: transformClipForSend(clip)
      })),
      categories: []
    };
    
    console.log(`[Thinkly] POST ${endpoint}`);
    console.log(`[Thinkly] Sending ${payload.clips.length} clips`);
    
    // Get auth token
    const token = await authManager.getAccessToken();
    if (!token) {
      showToast('Login required to send to Web', 'error');
      return;
    }
    
    // Make request
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    
    const responseBody = await response.json().catch(() => ({}));
    console.log(`[Thinkly] Response: ${response.status}`, responseBody);
    
    // Handle auth errors explicitly
    if (response.status === 401 || response.status === 403) {
      showToast('Login required to send to Web', 'error');
      return;
    }
    
    if (!response.ok) {
      throw new Error(responseBody.error || `Server error: ${response.status}`);
    }
    
    // Success: Mark clips as sent
    for (const clip of unsentClips) {
      await clipManager.updateClip(
        clip.id,
        {
          syncStatus: 'sent',
          sentToWebAt: Date.now()
        },
        {
          validate: false,
          sync: false
        }
      );
    }
    
    showToast(`Sent ${unsentClips.length} clips to Web`, 'success');
    
    // Update UI
    await updateDebugBar();
    await loadData();
    renderClips();
    
  } catch (error) {
    console.error('[Thinkly] Send All error:', error);
    showToast(`Send failed: ${error.message}`, 'error');
  } finally {
    sendAllBtn.disabled = false;
    await updateDebugBar();
  }
}

/**
 * Transform clip data for API (exclude tags - server generates them)
 */
function transformClipForSend(clip) {
  return {
    id: clip.id,
    text: clip.text,
    title: clip.title,
    url: clip.url || null,
    icon: clip.icon || null,
    platform: clip.source?.platform || null,
    siteName: clip.source?.siteName || null,
    model: clip.source?.model || null,
    conversationUrl: clip.source?.conversationUrl || null,
    conversationId: clip.source?.conversationId || null,
    categoryId: clip.categoryId || null,
    wordCount: clip.metadata?.wordCount || null,
    characterCount: clip.metadata?.characterCount || null,
    language: clip.metadata?.language || 'en',
    tags: [], // Empty - server generates tags
    starred: clip.starred || false,
    createdAt: clip.createdAt,
    updatedAt: clip.updatedAt,
  };
}

/**
 * Format source information
 * @param {Object} source - Source object
 * @returns {string} Formatted source
 * @example
 * formatSource({ platform: 'chatgpt', siteName: 'ChatGPT', model: 'gpt-4' }) // "ChatGPT • gpt-4"
 * formatSource({ platform: 'other', siteName: 'example.com' }) // "example.com • unknown"
 */
export function formatSource(source) {
  if (!source || !source.platform) {
    return 'Unknown';
  }

  // Prefer siteName over platform mapping (backward compatible)
  let platformName;
  if (source.siteName) {
    platformName = source.siteName;
  } else {
    const platformMap = {
      chatgpt: 'ChatGPT',
      claude: 'Claude',
      other: 'Other'
    };
    platformName = platformMap[source.platform] || 'Other';
  }

  const model = source.model || 'unknown';

  return `${platformName} • ${model}`;
}

/**
 * Get category name by ID
 * @param {string} categoryId - Category ID
 * @param {Object} categories - All categories
 * @returns {string} Category name
 */
export function getCategoryName(categoryId, categories) {
  return getCategoryDisplay(categoryId, categories)?.name || 'Unknown';
}

/**
 * Filter clips by category
 * @param {Array} clips - All clips
 * @param {string|null} categoryId - Category ID (null for all)
 * @returns {Array} Filtered clips
 */
export function filterClipsByCategory(clips, categoryId) {
  if (!categoryId) {
    return clips; // Return all clips
  }

  const storedCategoryId = toStoredCategoryId(categoryId);

  if (storedCategoryId === null) {
    return clips.filter((clip) => clip.categoryId === null || clip.categoryId === undefined);
  }

  return clips.filter(clip => clip.categoryId === storedCategoryId);
}

/**
 * Filter clips by search query
 * @param {Array} clips - All clips
 * @param {string} query - Search query
 * @returns {Array} Filtered clips
 */
export function filterClipsBySearch(clips, query) {
  if (!query || query.trim() === '') {
    return clips;
  }

  const lowerQuery = query.toLowerCase();

  return clips.filter(clip => {
    const titleMatch = clip.title && clip.title.toLowerCase().includes(lowerQuery);
    const textMatch = clip.text && clip.text.toLowerCase().includes(lowerQuery);
    return titleMatch || textMatch;
  });
}

/**
 * Get filtered clips (respecting current category and search)
 * @returns {Array} Filtered clips
 */
function getFilteredClips() {
  let filteredClips = allClips;

  if (currentCategoryId) {
    filteredClips = filterClipsByCategory(filteredClips, currentCategoryId);
  }

  if (currentSearchQuery) {
    filteredClips = filterClipsBySearch(filteredClips, currentSearchQuery);
  }

  return filteredClips;
}

/**
 * Build clip card HTML
 * @param {Object} clip - Clip object
 * @returns {string} HTML string
 */
export function buildClipCardHTML(clip, selectionMode = false, selectedIds = new Set()) {
  const preview = clip.text.substring(0, 150);
  const source = formatSource(clip.source);
  const time = getRelativeTime(clip.createdAt);
  
  const isSelected = selectedIds.has(clip.id);
  const selectionModeClass = selectionMode ? ' clip-card--selection-mode' : '';
  const selectedClass = isSelected ? ' clip-card--selected' : '';
  
  const checkboxHTML = selectionMode ? `
    <div class="clip-checkbox${isSelected ? ' clip-checkbox--checked' : ''}"></div>
  ` : '';

  return `
    <div class="clip-card${selectionModeClass}${selectedClass}" data-clip-id="${clip.id}">
      ${checkboxHTML}
      <div class="clip-card-header">
        <span class="clip-card-icon">${escapeHTML(clip.icon)}</span>
        <div class="clip-card-title">${escapeHTML(clip.title)}</div>
      </div>
      <div class="clip-card-preview">${escapeHTML(preview)}</div>
      <div class="clip-card-footer">
        <span class="clip-source">${escapeHTML(source)}</span>
        <span class="clip-time">${time}</span>
      </div>
    </div>
  `;
}

/**
 * Build category tree HTML
 * @param {Object} categories - All categories
 * @param {Object} clipCounts - Clip counts per category
 * @param {string|null} activeCategoryId - Active category ID
 * @returns {string} HTML string
 */
export function buildCategoryTreeHTML(categories, clipCounts, activeCategoryId) {
  const categoriesArray = Object.values(categories);

  if (categoriesArray.length === 0) {
    return '';
  }

  // Sort by order
  categoriesArray.sort((a, b) => a.order - b.order);

  // Separate root and child categories
  const roots = categoriesArray.filter(cat => !cat.parentId);
  const children = categoriesArray.filter(cat => cat.parentId);

  let html = '';

  roots.forEach(root => {
    const count = clipCounts[root.id] || 0;
    const isActive = root.id === activeCategoryId;
    const activeClass = isActive ? ' active' : '';
    const isDefaultCategory = ['cat_general', 'cat_work', 'cat_personal', 'cat_ideas'].includes(root.id);

    html += `
      <div class="category-item${activeClass}" data-category-id="${root.id}">
        <span class="category-icon">${escapeHTML(root.icon)}</span>
        <span class="category-name">${escapeHTML(root.name)}</span>
        <span class="category-count">${count}</span>
        ${!isDefaultCategory ? `
          <div class="category-actions">
            <button class="category-action-btn category-edit-btn" data-category-id="${root.id}" title="Edit">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
            <button class="category-action-btn category-delete-btn" data-category-id="${root.id}" title="Delete">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        ` : ''}
      </div>
    `;

    // Add children
    const rootChildren = children.filter(child => child.parentId === root.id);
    rootChildren.forEach(child => {
      const childCount = clipCounts[child.id] || 0;
      const childIsActive = child.id === activeCategoryId;
      const childActiveClass = childIsActive ? ' active' : '';

      html += `
        <div class="category-item child${childActiveClass}" data-category-id="${child.id}">
          <span class="category-icon">${escapeHTML(child.icon)}</span>
          <span class="category-name">${escapeHTML(child.name)}</span>
          <span class="category-count">${childCount}</span>
          <div class="category-actions">
            <button class="category-action-btn category-edit-btn" data-category-id="${child.id}" title="Edit">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
              </svg>
            </button>
            <button class="category-action-btn category-delete-btn" data-category-id="${child.id}" title="Delete">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
              </svg>
            </button>
          </div>
        </div>
      `;
    });
  });

  return html;
}

/**
 * Calculate clip counts per category
 * @param {Array} clips - All clips
 * @returns {Object} Clip counts keyed by category ID
 */
function calculateClipCounts(clips) {
  const counts = {};

  clips.forEach(clip => {
    if (!counts[clip.categoryId]) {
      counts[clip.categoryId] = 0;
    }
    counts[clip.categoryId]++;
  });

  return counts;
}

/**
 * Initialize popup
 */
async function init() {
  console.log('[Thinkly] Popup initialized');

  try {
    // 인증 상태 먼저 체크
    await checkAuthState();

    // ClipManager와 CategoryManager에 SyncManager 연결
    clipManager.setSyncManager(syncManager);
    clipManager.setQuotaManager(quotaManager);
    categoryManager.setSyncManager(syncManager);

    // 쿼타 초과 이벤트 리스너
    clipManager.on('quotaExceeded', handleQuotaExceeded);

    // 데이터 로드
    await loadData();

    // UI 렌더링
    renderCategoryTree();
    renderCategoryPills();
    renderClips();

    // FAB 초기화 (WP05)
    initFAB();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // 이벤트 리스너 설정
    setupEventListeners();
    setupAddPanelListeners();

    // 로그인된 경우 동기화 상태 폴링 시작 (MVP: disabled)
    if (isAuthenticated && MVP_AUTO_SYNC_ENABLED) {
      startSyncStatePolling();
    }
    
    // MVP Debug Bar 업데이트
    await updateDebugBar();

  } catch (error) {
    console.error('[Thinkly] Error initializing popup:', error);
  }
}

/**
 * 인증 상태 확인 및 업데이트
 */
async function checkAuthState() {
  try {
    const authState = await authManager.getAuthState();
    isAuthenticated = authState?.isAuthenticated === true;
    currentUser = authState?.user || null;

    console.log('[Thinkly] Auth state:', isAuthenticated ? 'authenticated' : 'not authenticated');

    updateAuthUI();

  } catch (error) {
    console.error('[Thinkly] Error checking auth state:', error);
    isAuthenticated = false;
    currentUser = null;
    updateAuthUI();
  }
}

/**
 * Auth UI 업데이트
 */
function updateAuthUI() {
  console.log('[Thinkly Popup] updateAuthUI called, isAuthenticated:', isAuthenticated);
  const loginBtn = document.getElementById('login-btn');
  const userInfo = document.getElementById('user-info');
  const userAvatar = document.getElementById('user-avatar');
  const syncBtn = document.getElementById('sync-btn');
  const syncStatus = document.getElementById('sync-status');

  if (isAuthenticated && currentUser) {
    // 로그인 상태: 사용자 정보 및 동기화 UI 표시
    console.log('[Thinkly Popup] Showing user info, hiding login button');
    loginBtn.style.display = 'none';
    userInfo.style.display = 'flex';
    syncBtn.style.display = 'block';
    syncStatus.style.display = 'flex';

    // 아바타 설정
    if (currentUser.avatarUrl) {
      userAvatar.src = currentUser.avatarUrl;
      userAvatar.alt = currentUser.name || currentUser.email || 'User';
    } else {
      const initial = (currentUser.name || currentUser.email || '?')[0].toUpperCase();
      userAvatar.src = createAvatarDataUri(initial);
      userAvatar.alt = currentUser.name || currentUser.email || 'User';
    }
  } else {
    // 로그아웃 상태: 로그인 버튼만 표시
    console.log('[Thinkly Popup] Showing login button, hiding user info');
    loginBtn.style.display = 'block';
    loginBtn.textContent = 'Sign In';
    userInfo.style.display = 'none';
    syncBtn.style.display = 'none';
    syncStatus.style.display = 'none';
  }
}

/**
 * 아바타 이니셜 이미지 생성
 */
function createAvatarDataUri(initial) {
  const canvas = document.createElement('canvas');
  canvas.width = 48;
  canvas.height = 48;
  const ctx = canvas.getContext('2d');

  // 배경
  ctx.fillStyle = '#6366f1';
  ctx.fillRect(0, 0, 48, 48);

  // 텍스트
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 24px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(initial, 24, 24);

  return canvas.toDataURL();
}

/**
 * Load data from storage
 */
async function loadData() {
  allClips = await clipManager.getAllClips();
  allCategories = await categoryManager.getAllCategories();

  console.log('[Thinkly] Loaded:', allClips.length, 'clips,', Object.keys(allCategories).length, 'categories');
}

/**
 * 로그인 버튼 클릭 핸들러
 */
async function handleLogin() {
  console.log('[Thinkly Popup] handleLogin called');
  const loginBtn = document.getElementById('login-btn');
  const originalText = loginBtn.textContent;
  console.log('[Thinkly Popup] Login button found:', loginBtn);

  try {
    loginBtn.textContent = 'Signing in...';
    loginBtn.disabled = true;

    // Service worker로 로그인 메시지 전송
    console.log('[Thinkly Popup] Sending SIGN_IN message to service worker...');
    const response = await chrome.runtime.sendMessage({ type: 'SIGN_IN' });
    console.log('[Thinkly Popup] Response from service worker:', response);

    if (!response.success) {
      throw new Error(response.error || 'Sign in failed');
    }

    // 로컬 상태 업데이트
    isAuthenticated = true;
    currentUser = response.result.user;

    // UI 업데이트
    updateAuthUI();

    // 동기화 상태 폴링 시작
    startSyncStatePolling();

    // 첫 동기화 실행
    await handleManualSync();

    showToast('Signed in successfully', 'success');

  } catch (error) {
    console.error('[Thinkly] Login error:', error);
    showToast('Sign in failed: ' + error.message, 'error');

    loginBtn.textContent = originalText;
    loginBtn.disabled = false;
  }
}

/**
 * 로그아웃 버튼 클릭 핸들러
 */
async function handleLogout() {
  const confirmed = confirm('Sign out? Your local clips will remain saved on this device.');

  if (!confirmed) return;

  try {
    const response = await chrome.runtime.sendMessage({ type: 'SIGN_OUT' });

    if (!response.success) {
      throw new Error(response.error || 'Sign out failed');
    }

    // 로컬 상태 업데이트
    isAuthenticated = false;
    currentUser = null;

    // 동기화 폴링 중지
    stopSyncStatePolling();

    // UI 업데이트
    updateAuthUI();

    showToast('Signed out successfully', 'success');

  } catch (error) {
    console.error('[Thinkly] Logout error:', error);
    showToast('Sign out failed: ' + error.message, 'error');
  }
}

/**
 * 동기화 상태 폴링 시작 (2초 간격)
 */
function startSyncStatePolling() {
  stopSyncStatePolling();

  // 즉시 실행
  updateSyncStatus();

  // 2초마다 폴링
  syncStatePollingInterval = setInterval(() => {
    updateSyncStatus();
  }, 2000);

  console.log('[Thinkly] Sync state polling started');
}

/**
 * 동기화 상태 폴링 중지
 */
function stopSyncStatePolling() {
  if (syncStatePollingInterval) {
    clearInterval(syncStatePollingInterval);
    syncStatePollingInterval = null;
    console.log('[Thinkly] Sync state polling stopped');
  }
}

/**
 * 동기화 상태 표시 업데이트
 */
async function updateSyncStatus() {
  if (!isAuthenticated) return;

  const syncStatusEl = document.getElementById('sync-status');
  const syncStatusIcon = document.getElementById('sync-status-icon');
  const syncStatusText = document.getElementById('sync-status-text');

  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_SYNC_STATE' });

    if (!response.success) {
      console.error('[Thinkly] Failed to get sync state:', response.error);
      return;
    }

    const syncState = response.state;

    // 상태 클래스 초기화
    syncStatusEl.classList.remove('syncing', 'error', 'success');

    // 상태별 UI 업데이트
    switch (syncState.status) {
      case 'syncing':
        syncStatusEl.classList.add('syncing');
        syncStatusIcon.textContent = '⟳';
        syncStatusText.textContent = 'Syncing...';
        break;

      case 'error':
        syncStatusEl.classList.add('error');
        syncStatusIcon.textContent = '⚠';
        syncStatusText.textContent = 'Sync error';
        break;

      case 'idle':
      default:
        if (syncState.lastSyncAt > 0) {
          syncStatusEl.classList.add('success');
          syncStatusIcon.textContent = '✓';
          const timeAgo = getRelativeTime(syncState.lastSyncAt);
          syncStatusText.textContent = `Synced ${timeAgo}`;
        } else {
          syncStatusIcon.textContent = '○';
          syncStatusText.textContent = 'Not synced';
        }
        break;
    }

  } catch (error) {
    console.error('[Thinkly] Error updating sync status:', error);
  }
}

/**
 * 수동 동기화 버튼 클릭 핸들러
 */
async function handleManualSync() {
  const syncBtn = document.getElementById('sync-btn');

  try {
    syncBtn.disabled = true;
    syncBtn.classList.add('syncing');

    const response = await chrome.runtime.sendMessage({ type: 'SYNC_NOW' });

    if (!response.success) {
      throw new Error(response.error || 'Sync failed');
    }

    // 데이터 다시 로드
    await loadData();
    renderCategoryTree();
    renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // 동기화 상태 즉시 업데이트
    await updateSyncStatus();

    showToast('Synced successfully', 'success');

  } catch (error) {
    console.error('[Thinkly] Manual sync error:', error);
    showToast('Sync failed: ' + error.message, 'error');
  } finally {
    syncBtn.disabled = false;
    syncBtn.classList.remove('syncing');
  }
}

/**
 * Render category tree
 */
function renderCategoryTree() {
  const treeContainer = document.getElementById('category-tree');

  // Add "All Clips" option
  const totalClips = allClips.length;
  const allClipsActive = currentCategoryId === null ? ' active' : '';

  let html = `
    <div class="category-item${allClipsActive}" data-category-id="">
      <span class="category-icon">📚</span>
      <span class="category-name">All Clips</span>
      <span class="category-count">${totalClips}</span>
    </div>
  `;

  // Add categories
  const clipCounts = calculateClipCounts(allClips);
  html += buildCategoryTreeHTML(allCategories, clipCounts, currentCategoryId);

  treeContainer.innerHTML = html;
}

/**
 * Render category pills (horizontal filter bar) - WP05
 */
function renderCategoryPills() {
  const pillsContainer = document.getElementById('category-pills');
  if (!pillsContainer) return;

  pillsContainer.innerHTML = buildCategoryPillsHTML(allCategories, currentCategoryId);

  // Bind click events
  pillsContainer.querySelectorAll('.category-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const categoryId = pill.dataset.categoryId || null;
      currentCategoryId = categoryId;
      renderCategoryTree();
      renderCategoryPills();
      renderClips();
    });
  });
}

/**
 * Initialize FAB (Floating Action Button) - WP05
 */
function initFAB() {
  fab = new FAB('#fab-container');
  fab.setOnOptionSelect(handleFABOption);
}

/**
 * Handle FAB option selection - WP05
 * @param {string} type - 'url' | 'file' | 'text'
 */
function handleFABOption(type) {
  openAddPanel(type);
}

/**
 * Open add panel - WP05
 * @param {string} type - 'url' | 'file' | 'text'
 */
function openAddPanel(type) {
  currentAddPanelType = type;
  
  // Update category options in all panels
  updatePanelCategoryOptions();
  
  // Show overlay and panel
  document.getElementById('add-panel-overlay').classList.add('show');
  document.getElementById(`${type}-panel`).classList.add('show');
  
  // Focus first input
  const panel = document.getElementById(`${type}-panel`);
  const firstInput = panel.querySelector('input[type="text"], textarea');
  if (firstInput) {
    setTimeout(() => firstInput.focus(), 100);
  }
}

/**
 * Close add panel - WP05
 */
function closeAddPanel() {
  document.getElementById('add-panel-overlay').classList.remove('show');
  document.querySelectorAll('.add-panel').forEach(p => p.classList.remove('show'));
  currentAddPanelType = null;
  selectedFile = null;
  
  // Reset inputs
  document.getElementById('url-panel-input').value = '';
  document.getElementById('text-panel-title').value = '';
  document.getElementById('text-panel-content').value = '';
  document.getElementById('file-panel-info').classList.remove('show');
  document.getElementById('file-panel-add').disabled = true;
}

/**
 * Update category options in add panels - WP05
 */
function updatePanelCategoryOptions() {
  const categoryOptions = Object.values(allCategories)
    .filter(cat => !cat.parentId)
    .sort((a, b) => (a.order ?? 999) - (b.order ?? 999))
    .map(cat => `<option value="${cat.id}">${escapeHTML(cat.icon || '📁')} ${escapeHTML(cat.name)}</option>`)
    .join('');

  const defaultOption = '<option value="">📂 Select category</option>';
  const options = defaultOption + categoryOptions;

  document.getElementById('url-panel-category').innerHTML = options;
  document.getElementById('file-panel-category').innerHTML = options;
  document.getElementById('text-panel-category').innerHTML = options;
}

/**
 * Setup add panel event listeners - WP05
 */
function setupAddPanelListeners() {
  // Overlay click to close
  document.getElementById('add-panel-overlay').addEventListener('click', closeAddPanel);
  
  // Close buttons
  document.querySelectorAll('.add-panel-close').forEach(btn => {
    btn.addEventListener('click', closeAddPanel);
  });
  
  // URL Panel
  document.getElementById('url-panel-add').addEventListener('click', handleAddUrl);
  document.getElementById('url-panel-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleAddUrl();
  });
  
  // File Panel
  const dropzone = document.getElementById('file-panel-dropzone');
  const fileInput = document.getElementById('file-panel-input');
  
  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('drag-over');
  });
  dropzone.addEventListener('dragleave', () => {
    dropzone.classList.remove('drag-over');
  });
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  });
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) {
      handleFileSelect(e.target.files[0]);
    }
  });
  document.getElementById('file-panel-remove').addEventListener('click', () => {
    selectedFile = null;
    document.getElementById('file-panel-info').classList.remove('show');
    document.getElementById('file-panel-add').disabled = true;
  });
  document.getElementById('file-panel-add').addEventListener('click', handleAddFile);
  
  // Text Panel
  document.getElementById('text-panel-add').addEventListener('click', handleAddText);
  
  // ESC key to close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && currentAddPanelType) {
      closeAddPanel();
    }
  });
}

/**
 * Handle file selection - WP05
 * @param {File} file
 */
function handleFileSelect(file) {
  const validTypes = ['.txt', '.md', '.json'];
  const ext = '.' + file.name.split('.').pop().toLowerCase();
  
  if (!validTypes.includes(ext)) {
    alert('Supported formats: .txt, .md, .json');
    return;
  }
  
  selectedFile = file;
  document.getElementById('file-panel-name').textContent = file.name;
  document.getElementById('file-panel-info').classList.add('show');
  document.getElementById('file-panel-add').disabled = false;
}

/**
 * Handle URL add - WP05
 */
async function handleAddUrl() {
  const input = document.getElementById('url-panel-input');
  const categorySelect = document.getElementById('url-panel-category');
  const url = input.value.trim();
  
  if (!url) {
    alert('Please enter a URL');
    return;
  }
  
  // Validate URL
  try {
    new URL(url);
  } catch {
    alert('Please enter a valid URL');
    return;
  }
  
  const btn = document.getElementById('url-panel-add');
  btn.disabled = true;
  btn.textContent = 'Adding...';
  
  try {
    // For now, create a simple clip with the URL
    // TODO: Integrate with /api/extract-url when web dashboard API is available
    const clip = {
      id: `clip_${Date.now()}`,
      title: url,
      text: `URL: ${url}`,
      icon: '🔗',
      source: {
        platform: 'other',
        siteName: new URL(url).hostname,
        url: url
      },
      categoryId: categorySelect.value || 'cat_general',
      createdAt: Date.now()
    };
    
    await clipManager.saveClip(clip);
    await loadData();
    renderCategoryTree();
    renderCategoryPills();
    renderClips();
    closeAddPanel();
    
  } catch (error) {
    console.error('Error adding URL clip:', error);
    alert('Failed to add URL. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add';
  }
}

/**
 * Handle file add - WP05
 */
async function handleAddFile() {
  if (!selectedFile) return;
  
  const categorySelect = document.getElementById('file-panel-category');
  const btn = document.getElementById('file-panel-add');
  btn.disabled = true;
  btn.textContent = 'Uploading...';
  
  try {
    const text = await selectedFile.text();
    const ext = selectedFile.name.split('.').pop().toLowerCase();
    
    let title = selectedFile.name.replace(/\.[^/.]+$/, '');
    let content = text;
    
    // For JSON, try to extract meaningful content
    if (ext === 'json') {
      try {
        const json = JSON.parse(text);
        title = json.title || json.name || title;
        content = json.text || json.content || JSON.stringify(json, null, 2);
      } catch {
        content = text;
      }
    }
    
    const clip = {
      id: `clip_${Date.now()}`,
      title: title,
      text: content,
      icon: '📄',
      source: {
        platform: 'other',
        siteName: 'File Upload',
        fileName: selectedFile.name
      },
      categoryId: categorySelect.value || 'cat_general',
      createdAt: Date.now()
    };
    
    await clipManager.saveClip(clip);
    await loadData();
    renderCategoryTree();
    renderCategoryPills();
    renderClips();
    closeAddPanel();
    
  } catch (error) {
    console.error('Error adding file clip:', error);
    alert('Failed to upload file. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Upload';
  }
}

/**
 * Handle text add - WP05
 */
async function handleAddText() {
  const titleInput = document.getElementById('text-panel-title');
  const contentInput = document.getElementById('text-panel-content');
  const categorySelect = document.getElementById('text-panel-category');
  
  const title = titleInput.value.trim();
  const content = contentInput.value.trim();
  
  if (!content) {
    alert('Please enter some text content');
    return;
  }
  
  const btn = document.getElementById('text-panel-add');
  btn.disabled = true;
  btn.textContent = 'Saving...';
  
  try {
    const clip = {
      id: `clip_${Date.now()}`,
      title: title || content.substring(0, 50) + (content.length > 50 ? '...' : ''),
      text: content,
      icon: '📝',
      source: {
        platform: 'other',
        siteName: 'Manual Entry'
      },
      categoryId: categorySelect.value || 'cat_general',
      createdAt: Date.now()
    };
    
    await clipManager.saveClip(clip);
    await loadData();
    renderCategoryTree();
    renderCategoryPills();
    renderClips();
    closeAddPanel();
    
  } catch (error) {
    console.error('Error adding text clip:', error);
    alert('Failed to save text. Please try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save';
  }
}

/**
 * Render clips
 */
function renderClips() {
  const gridContainer = document.getElementById('clip-grid');
  const emptyState = document.getElementById('empty-state');
  const contentTitle = document.getElementById('content-title');
  const clipCount = document.getElementById('clip-count');

  // Filter clips
  let filteredClips = allClips;

  if (currentCategoryId) {
    filteredClips = filterClipsByCategory(filteredClips, currentCategoryId);
  }

  if (currentSearchQuery) {
    filteredClips = filterClipsBySearch(filteredClips, currentSearchQuery);
  }

  // Update title
  if (currentCategoryId) {
    const categoryName = getCategoryName(currentCategoryId, allCategories);
    contentTitle.textContent = categoryName;
  } else {
    contentTitle.textContent = 'All Clips';
  }

  // Update count
  clipCount.textContent = `${filteredClips.length} clip${filteredClips.length !== 1 ? 's' : ''}`;

  // Show empty state if no clips
  if (filteredClips.length === 0) {
    gridContainer.style.display = 'none';
    emptyState.style.display = 'flex';
    return;
  }

  // Hide empty state
  gridContainer.style.display = 'grid';
  emptyState.style.display = 'none';

  // Render clips
  const html = filteredClips.map(clip => buildClipCardHTML(clip, isSelectionMode, selectedClipIds)).join('');
  gridContainer.innerHTML = html;
  
  // Update content title for selection mode
  if (isSelectionMode) {
    contentTitle.textContent = 'Select clips to export';
  }
}

/**
 * Show detail modal
 * @param {string} clipId - Clip ID
 */
async function showDetailModal(clipId) {
  const clip = allClips.find(c => c.id === clipId);

  if (!clip) {
    console.error('[Thinkly] Clip not found:', clipId);
    return;
  }

  currentClip = clip;

  const modal = document.getElementById('detail-modal');
  const modalIcon = document.getElementById('modal-icon');
  const modalTitle = document.getElementById('modal-title');
  const modalText = document.getElementById('modal-text');
  const modalSource = document.getElementById('modal-source');
  const modalCreated = document.getElementById('modal-created');
  const modalCategory = document.getElementById('modal-category');
  const modalWords = document.getElementById('modal-words');
  const modalRelated = document.getElementById('modal-related');
  const modalRelatedList = document.getElementById('modal-related-list');
  const modalMoveSelect = document.getElementById('modal-move-select');

  // Populate modal
  modalIcon.textContent = clip.icon;
  modalTitle.textContent = clip.title;
  modalText.textContent = clip.text;
  modalSource.textContent = formatSource(clip.source);
  modalCreated.textContent = getRelativeTime(clip.createdAt);
  modalCategory.textContent = getCategoryName(clip.categoryId, allCategories);
  modalWords.textContent = clip.metadata ? clip.metadata.wordCount : 0;

  // Related clips
  if (clip.source && clip.source.conversationId) {
    const relatedClips = await clipManager.getRelatedClips(clip.source.conversationId);
    const otherClips = relatedClips.filter(c => c.id !== clip.id);

    if (otherClips.length > 0) {
      modalRelated.style.display = 'block';
      modalRelatedList.innerHTML = otherClips.map(rc => `
        <div class="related-clip-item" data-clip-id="${rc.id}">
          <span class="related-clip-icon">${escapeHTML(rc.icon)}</span>
          <span class="related-clip-title">${escapeHTML(rc.title)}</span>
          <span class="related-clip-time">${getRelativeTime(rc.createdAt)}</span>
        </div>
      `).join('');
    } else {
      modalRelated.style.display = 'none';
    }
  } else {
    modalRelated.style.display = 'none';
  }

  // Update move select options
  let moveOptions = '<option value="">Move to...</option>';
  Object.values(allCategories).forEach(cat => {
    if (cat.id !== clip.categoryId && !cat.parentId) {
      moveOptions += `<option value="${cat.id}">${escapeHTML(cat.icon)} ${escapeHTML(cat.name)}</option>`;
    }
  });
  modalMoveSelect.innerHTML = moveOptions;

  // Show modal
  modal.style.display = 'block';
}

/**
 * Hide detail modal
 */
function hideDetailModal() {
  const modal = document.getElementById('detail-modal');
  modal.style.display = 'none';
  currentClip = null;
}

/**
 * Handle copy clip
 */
async function handleCopy() {
  if (!currentClip) return;

  try {
    await navigator.clipboard.writeText(currentClip.text);

    // Show feedback
    const copyBtn = document.getElementById('modal-copy-btn');
    const originalText = copyBtn.textContent;
    copyBtn.textContent = '✓ Copied!';

    setTimeout(() => {
      copyBtn.textContent = originalText;
    }, 1500);

  } catch (error) {
    console.error('[Thinkly] Error copying to clipboard:', error);
  }
}

/**
 * Handle move clip
 * @param {string} newCategoryId - New category ID
 */
async function handleMove(newCategoryId) {
  if (!currentClip || !newCategoryId) return;

  try {
    await clipManager.updateClip(currentClip.id, {
      categoryId: newCategoryId
    });

    // Reload data and re-render
    await loadData();
    renderCategoryTree();
    renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // Update modal category
    const modalCategory = document.getElementById('modal-category');
    modalCategory.textContent = getCategoryName(newCategoryId, allCategories);

    // Reset select
    const modalMoveSelect = document.getElementById('modal-move-select');
    modalMoveSelect.value = '';

    console.log('[Thinkly] Clip moved to:', newCategoryId);

  } catch (error) {
    console.error('[Thinkly] Error moving clip:', error);
  }
}

/**
 * Handle delete clip
 */
async function handleDelete() {
  if (!currentClip) return;

  // Confirm deletion
  const confirmed = confirm(`Delete clip "${currentClip.title}"?`);

  if (!confirmed) return;

  try {
    await clipManager.deleteClip(currentClip.id);

    // Reload data and re-render
    await loadData();
    renderCategoryTree();
    renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // Hide modal
    hideDetailModal();

    console.log('[Thinkly] Clip deleted:', currentClip.id);

  } catch (error) {
    console.error('[Thinkly] Error deleting clip:', error);
  }
}

/**
 * Handle export clips to markdown
 */
/**
 * Handle Export button click - Enter selection mode
 */
function handleExport() {
  enterSelectionMode();
}

/**
 * Enter selection mode
 */
function enterSelectionMode() {
  isSelectionMode = true;
  selectedClipIds.clear();
  
  // Hide export button
  const exportBtn = document.getElementById('export-btn');
  if (exportBtn) {
    exportBtn.style.display = 'none';
  }
  
  // Render clips with selection UI
  renderClips();
  
  // Show selection bar
  showSelectionBar();
}

/**
 * Exit selection mode
 */
function exitSelectionMode() {
  isSelectionMode = false;
  selectedClipIds.clear();
  
  // Show export button
  const exportBtn = document.getElementById('export-btn');
  if (exportBtn) {
    exportBtn.style.display = 'flex';
  }
  
  // Hide selection bar
  hideSelectionBar();
  
  // Re-render clips without selection UI
  renderClips();
}

/**
 * Toggle clip selection
 * @param {string} clipId - Clip ID to toggle
 */
function toggleClipSelection(clipId) {
  if (selectedClipIds.has(clipId)) {
    selectedClipIds.delete(clipId);
  } else {
    selectedClipIds.add(clipId);
  }
  
  // Update UI
  renderClips();
  updateSelectionBar();
}

/**
 * Select all visible clips
 */
function selectAllClips() {
  const filteredClips = getFilteredClips();
  
  if (selectedClipIds.size === filteredClips.length) {
    // Deselect all if all are selected
    selectedClipIds.clear();
  } else {
    // Select all
    filteredClips.forEach(clip => selectedClipIds.add(clip.id));
  }
  
  renderClips();
  updateSelectionBar();
}

/**
 * Show selection bar
 */
function showSelectionBar() {
  const filteredClips = getFilteredClips();
  
  selectionBar = new SelectionBar({
    containerId: 'selection-bar-container',
    selectedCount: selectedClipIds.size,
    totalCount: filteredClips.length,
    onClose: exitSelectionMode,
    onSelectAll: selectAllClips,
    onExport: exportSelectedClips
  });
  
  selectionBar.render();
}

/**
 * Hide selection bar
 */
function hideSelectionBar() {
  if (selectionBar) {
    selectionBar.destroy();
    selectionBar = null;
  }
}

/**
 * Update selection bar counts
 */
function updateSelectionBar() {
  if (selectionBar) {
    const filteredClips = getFilteredClips();
    selectionBar.update({
      selectedCount: selectedClipIds.size,
      totalCount: filteredClips.length
    });
  }
}

/**
 * Export selected clips
 */
async function exportSelectedClips() {
  try {
    if (selectedClipIds.size === 0) {
      alert('No clips selected');
      return;
    }
    
    // Get selected clips
    const selectedClips = allClips.filter(clip => selectedClipIds.has(clip.id));
    
    // Determine category name
    const categoryName = currentCategoryId
      ? (allCategories[currentCategoryId]?.name || 'Selected Clips')
      : 'Selected Clips';
    
    // Export
    await exportManager.exportToMarkdown(selectedClips, { categoryName });
    
    console.log('[Thinkly] Exported', selectedClips.length, 'selected clips');
    
    // Exit selection mode after export
    exitSelectionMode();
    
  } catch (error) {
    console.error('[Thinkly] Error exporting clips:', error);
    alert('Error exporting clips: ' + error.message);
  }
}

/**
 * Handle search
 * @param {string} query - Search query
 */
async function handleSearch(query) {
  currentSearchQuery = query;
  renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }
}

/**
 * Category Management Functions
 */

/**
 * Show Add Category modal
 */
function showAddCategoryModal() {
  const modal = document.getElementById('add-category-modal');
  const form = document.getElementById('add-category-form');

  // Reset form
  form.reset();
  clearFormErrors('add-category');

  // Render emoji picker
  renderEmojiPicker('add-category-emoji-picker', (emoji) => {
    document.getElementById('add-category-icon').value = emoji;
  });

  // Render parent category options
  renderParentCategorySelect('add-category-parent');

  // Show modal
  modal.style.display = 'block';

  // Focus first input
  document.getElementById('add-category-name').focus();
}

/**
 * Hide Add Category modal
 */
function hideAddCategoryModal() {
  const modal = document.getElementById('add-category-modal');
  modal.style.display = 'none';
}

/**
 * Show Edit Category modal
 * @param {string} categoryId - Category ID to edit
 */
function showEditCategoryModal(categoryId) {
  const modal = document.getElementById('edit-category-modal');
  const category = allCategories[categoryId];

  if (!category) {
    console.error('[Thinkly] Category not found:', categoryId);
    return;
  }

  // Store for later use
  currentCategoryForEdit = categoryId;

  // Pre-fill form
  document.getElementById('edit-category-name').value = category.name;
  document.getElementById('edit-category-icon').value = category.icon;

  // Render emoji picker with current selection
  renderEmojiPicker('edit-category-emoji-picker', (emoji) => {
    document.getElementById('edit-category-icon').value = emoji;
  }, category.icon);

  // Show modal
  modal.style.display = 'block';
  document.getElementById('edit-category-name').focus();
}

/**
 * Hide Edit Category modal
 */
function hideEditCategoryModal() {
  const modal = document.getElementById('edit-category-modal');
  modal.style.display = 'none';
  currentCategoryForEdit = null;
}

/**
 * Show Delete Category confirmation
 * @param {string} categoryId - Category ID to delete
 */
function showDeleteCategoryModal(categoryId) {
  const modal = document.getElementById('delete-category-modal');
  const category = allCategories[categoryId];

  if (!category) return;

  // Store for later use
  currentCategoryForEdit = categoryId;

  // Set category name
  document.getElementById('delete-category-name-display').textContent = category.name;

  // Check for clips
  const clipsInCategory = allClips.filter(c => c.categoryId === categoryId);
  const clipWarning = document.getElementById('delete-category-clips-warning');
  const clipCount = document.getElementById('delete-category-clip-count');

  if (clipsInCategory.length > 0) {
    clipCount.textContent = clipsInCategory.length;
    clipWarning.style.display = 'block';
  } else {
    clipWarning.style.display = 'none';
  }

  // Check for children
  const hasChildren = Object.values(allCategories).some(c => c.parentId === categoryId);
  const childrenError = document.getElementById('delete-category-children-error');
  const confirmBtn = document.getElementById('delete-category-confirm-btn');

  if (hasChildren) {
    childrenError.style.display = 'block';
    confirmBtn.disabled = true;
  } else {
    childrenError.style.display = 'none';
    confirmBtn.disabled = false;
  }

  modal.style.display = 'block';
}

/**
 * Hide Delete Category modal
 */
function hideDeleteCategoryModal() {
  const modal = document.getElementById('delete-category-modal');
  modal.style.display = 'none';
  currentCategoryForEdit = null;
}

/**
 * Handle Add Category
 */
async function handleAddCategory() {
  try {
    const nameInput = document.getElementById('add-category-name');
    const iconInput = document.getElementById('add-category-icon');
    const parentSelect = document.getElementById('add-category-parent');

    const formData = {
      name: nameInput.value.trim(),
      icon: iconInput.value,
      parentId: parentSelect.value || null
    };

    // Validate
    const errors = validateCategoryForm(formData);
    if (errors.length > 0) {
      showFormErrors('add-category', errors);
      return;
    }

    // Create category object
    const newCategory = {
      id: generateCategoryId(),
      ...formData,
      order: Object.values(allCategories).filter(c => c.parentId === formData.parentId).length,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    // Add to backend
    await categoryManager.addCategory(newCategory);

    // Reload data
    await loadData();

    // Re-render
    renderCategoryTree();

    // Hide modal
    hideAddCategoryModal();

    // Show success toast
    showToast('Category added successfully', 'success');

    console.log('[Thinkly] Category added:', newCategory.id);

  } catch (error) {
    console.error('[Thinkly] Error adding category:', error);
    showToast('Error adding category: ' + error.message, 'error');
  }
}

/**
 * Handle Edit Category
 */
async function handleEditCategory() {
  try {
    if (!currentCategoryForEdit) return;

    const nameInput = document.getElementById('edit-category-name');
    const iconInput = document.getElementById('edit-category-icon');

    const updates = {
      name: nameInput.value.trim(),
      icon: iconInput.value,
      updatedAt: Date.now()
    };

    // Validate
    const errors = validateCategoryForm({ ...updates, parentId: null });
    if (errors.length > 0) {
      showFormErrors('edit-category', errors);
      return;
    }

    // Update backend
    await categoryManager.updateCategory(currentCategoryForEdit, updates);

    // Reload data
    await loadData();

    // Re-render
    renderCategoryTree();
    renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // Hide modal
    hideEditCategoryModal();

    // Show success toast
    showToast('Category updated successfully', 'success');

    console.log('[Thinkly] Category updated:', currentCategoryForEdit);

  } catch (error) {
    console.error('[Thinkly] Error updating category:', error);
    showToast('Error updating category: ' + error.message, 'error');
  }
}

/**
 * Handle Delete Category
 */
async function handleDeleteCategory() {
  try {
    if (!currentCategoryForEdit) return;

    // Delete from backend (clips will be migrated automatically)
    await categoryManager.deleteCategory(currentCategoryForEdit);

    // Reload data
    await loadData();

    // Re-render
    renderCategoryTree();
    renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }

    // Hide modal
    hideDeleteCategoryModal();

    // Show success toast
    showToast('Category deleted successfully', 'success');

    console.log('[Thinkly] Category deleted:', currentCategoryForEdit);

  } catch (error) {
    console.error('[Thinkly] Error deleting category:', error);
    showToast('Error deleting category: ' + error.message, 'error');
  }
}

/**
 * UI Helper Functions
 */

/**
 * Validate category form data
 * @param {Object} formData - { name, icon, parentId }
 * @returns {Array} Array of error objects
 */
function validateCategoryForm(formData) {
  const errors = [];

  // Name validation
  if (!formData.name || formData.name.length === 0) {
    errors.push({ field: 'name', message: 'Category name is required' });
  } else if (formData.name.length > 50) {
    errors.push({ field: 'name', message: 'Category name must be 50 characters or less' });
  }

  // Icon validation
  if (!formData.icon) {
    errors.push({ field: 'icon', message: 'Icon is required' });
  }

  // Parent validation
  if (formData.parentId) {
    const parent = allCategories[formData.parentId];
    if (!parent) {
      errors.push({ field: 'parent', message: 'Parent category not found' });
    } else if (parent.parentId !== null) {
      errors.push({ field: 'parent', message: 'Cannot create grandchild categories (max 2 levels)' });
    }
  }

  return errors;
}

/**
 * Generate unique category ID
 * @returns {string} Category ID
 */
function generateCategoryId() {
  return `cat_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Render emoji picker grid
 * @param {string} containerId - Container element ID
 * @param {Function} onSelect - Callback when emoji selected
 * @param {string} selectedEmoji - Initially selected emoji
 */
function renderEmojiPicker(containerId, onSelect, selectedEmoji = null) {
  const container = document.getElementById(containerId);
  const emojis = [
    '📂', '💼', '🚀', '🧠', '💡', '🎯',
    '📝', '🗂️', '📊', '🎨', '🔧', '⚙️',
    '🌟', '🔥', '💪', '🎓', '📚', '🏆',
    '🎮', '🎵', '🎬', '📷', '✈️', '🏠'
  ];

  let html = '';
  emojis.forEach(emoji => {
    const isSelected = emoji === selectedEmoji ? 'selected' : '';
    html += `<div class="emoji-option ${isSelected}" data-emoji="${emoji}">${emoji}</div>`;
  });

  container.innerHTML = html;

  // Add click handlers
  container.querySelectorAll('.emoji-option').forEach(option => {
    option.addEventListener('click', () => {
      // Remove previous selection
      container.querySelectorAll('.emoji-option').forEach(o => o.classList.remove('selected'));

      // Mark as selected
      option.classList.add('selected');

      // Callback
      onSelect(option.dataset.emoji);
    });
  });
}

/**
 * Render parent category select options
 * @param {string} selectId - Select element ID
 */
function renderParentCategorySelect(selectId) {
  const select = document.getElementById(selectId);
  const rootCategories = Object.values(allCategories).filter(c => c.parentId === null);

  let html = '<option value="">None (Root Category)</option>';
  rootCategories.forEach(category => {
    html += `<option value="${category.id}">${escapeHTML(category.icon)} ${escapeHTML(category.name)}</option>`;
  });

  select.innerHTML = html;
}

/**
 * Show form validation errors
 * @param {string} formPrefix - Form ID prefix ('add-category' or 'edit-category')
 * @param {Array} errors - Array of error objects
 */
function showFormErrors(formPrefix, errors) {
  // Clear previous errors
  clearFormErrors(formPrefix);

  // Show new errors
  errors.forEach(error => {
    const errorSpan = document.getElementById(`${formPrefix}-${error.field}-error`);
    if (errorSpan) {
      errorSpan.textContent = error.message;
    }
  });
}

/**
 * Clear form validation errors
 * @param {string} formPrefix - Form ID prefix
 */
function clearFormErrors(formPrefix) {
  const errorSpans = document.querySelectorAll(`[id^="${formPrefix}-"][id$="-error"]`);
  errorSpans.forEach(span => {
    span.textContent = '';
  });
}

/**
 * Show toast notification
 * @param {string} message - Toast message
 * @param {string} type - 'success' or 'error'
 */
function showToast(message, type = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);

  // Fade in
  setTimeout(() => toast.classList.add('show'), 10);

  // Fade out and remove
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
  console.log('[Thinkly Popup] setupEventListeners called');

  // Auth 버튼
  const loginBtn = document.getElementById('login-btn');
  console.log('[Thinkly Popup] login-btn element:', loginBtn);

  if (loginBtn) {
    loginBtn.addEventListener('click', handleLogin);
    console.log('[Thinkly Popup] Click event listener added to login-btn');
  } else {
    console.error('[Thinkly Popup] login-btn element not found!');
  }

  document.getElementById('logout-btn').addEventListener('click', handleLogout);

  // Web Dashboard 링크 버튼
  document.getElementById('web-link-btn').addEventListener('click', () => {
    window.open(getWebDashboardUrl(), '_blank');
  });

  // Sync 버튼 (legacy)
  document.getElementById('sync-btn').addEventListener('click', handleManualSync);
  
  // MVP: Send All 버튼
  document.getElementById('send-all-btn').addEventListener('click', handleSendAll);
  
  // MVP: API URL 토글 버튼
  document.getElementById('switch-api-btn').addEventListener('click', toggleApiUrl);

  // Add Category button
  document.getElementById('add-category-btn').addEventListener('click', showAddCategoryModal);

  // Add Category modal
  document.getElementById('add-category-close-btn').addEventListener('click', hideAddCategoryModal);
  document.getElementById('add-category-cancel-btn').addEventListener('click', hideAddCategoryModal);
  document.getElementById('add-category-save-btn').addEventListener('click', handleAddCategory);
  document.querySelector('#add-category-modal .modal-overlay').addEventListener('click', hideAddCategoryModal);

  // Edit Category modal
  document.getElementById('edit-category-close-btn').addEventListener('click', hideEditCategoryModal);
  document.getElementById('edit-category-cancel-btn').addEventListener('click', hideEditCategoryModal);
  document.getElementById('edit-category-save-btn').addEventListener('click', handleEditCategory);
  document.querySelector('#edit-category-modal .modal-overlay').addEventListener('click', hideEditCategoryModal);

  // Delete Category modal
  document.getElementById('delete-category-close-btn').addEventListener('click', hideDeleteCategoryModal);
  document.getElementById('delete-category-cancel-btn').addEventListener('click', hideDeleteCategoryModal);
  document.getElementById('delete-category-confirm-btn').addEventListener('click', handleDeleteCategory);
  document.querySelector('#delete-category-modal .modal-overlay').addEventListener('click', hideDeleteCategoryModal);

  // Category selection and action buttons
  document.getElementById('category-tree').addEventListener('click', async (e) => {
    // Edit button
    if (e.target.closest('.category-edit-btn')) {
      e.stopPropagation(); // Prevent category selection
      const categoryId = e.target.closest('.category-edit-btn').dataset.categoryId;
      showEditCategoryModal(categoryId);
      return;
    }

    // Delete button
    if (e.target.closest('.category-delete-btn')) {
      e.stopPropagation(); // Prevent category selection
      const categoryId = e.target.closest('.category-delete-btn').dataset.categoryId;
      showDeleteCategoryModal(categoryId);
      return;
    }

    // Category selection
    const categoryItem = e.target.closest('.category-item');
    if (categoryItem) {
      const categoryId = categoryItem.dataset.categoryId;
      currentCategoryId = categoryId || null;
      renderCategoryTree();
      renderCategoryPills();
      renderClips();

    // 쿼타 인디케이터 렌더링 (로그인된 경우)
    if (isAuthenticated) {
      await renderQuotaIndicator();
    }
    }
  });

  // Clip card click
  document.getElementById('clip-grid').addEventListener('click', (e) => {
    const clipCard = e.target.closest('.clip-card');
    if (clipCard) {
      const clipId = clipCard.dataset.clipId;
      
      // Selection mode: toggle selection
      if (isSelectionMode) {
        toggleClipSelection(clipId);
      } else {
        // Normal mode: show detail modal
        showDetailModal(clipId);
      }
    }
  });

  // Search input
  const searchInput = document.getElementById('search-input');
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      handleSearch(e.target.value);
    }, 300);
  });

  // Export button - Enter selection mode
  document.getElementById('export-btn').addEventListener('click', handleExport);

  // Modal close
  document.getElementById('modal-close-btn').addEventListener('click', hideDetailModal);
  document.querySelector('.modal-overlay').addEventListener('click', hideDetailModal);

  // ESC key handler
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      // Exit selection mode first if active
      if (isSelectionMode) {
        exitSelectionMode();
        return;
      }
      // Then close modals
      hideDetailModal();
      hideAddCategoryModal();
      hideEditCategoryModal();
      hideDeleteCategoryModal();
    }
  });

  // Modal actions
  document.getElementById('modal-copy-btn').addEventListener('click', handleCopy);
  document.getElementById('modal-move-select').addEventListener('change', (e) => {
    handleMove(e.target.value);
  });
  document.getElementById('modal-delete-btn').addEventListener('click', handleDelete);

  // Related clip click
  document.getElementById('modal-related-list').addEventListener('click', (e) => {
    const relatedItem = e.target.closest('.related-clip-item');
    if (relatedItem) {
      const clipId = relatedItem.dataset.clipId;
      showDetailModal(clipId);
    }
  });
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// ========================================
// PLG Growth Functions (F2)
// ========================================

/**
 * 쿼타 인디케이터 렌더링
 */
async function renderQuotaIndicator() {
  try {
    // 쿼타 컨테이너가 없으면 생성
    let quotaContainer = document.getElementById('quota-indicator');
    if (!quotaContainer) {
      quotaContainer = document.createElement('div');
      quotaContainer.id = 'quota-indicator';
      
      // 헤더에 추가
      const header = document.querySelector('.header');
      if (header) {
        header.appendChild(quotaContainer);
      }
    }

    quotaIndicator = new QuotaIndicator('quota-indicator', quotaManager);
    await quotaIndicator.render();

    // 업그레이드 이벤트 리스너
    quotaContainer.addEventListener('quota:upgrade', () => {
      showUpgradeModal();
    });
  } catch (error) {
    console.error('[Thinkly] Error rendering quota indicator:', error);
  }
}

/**
 * 쿼타 초과 핸들러
 */
function handleQuotaExceeded(clip) {
  showUpgradeModal();
  showToast('Cloud storage limit reached. Upgrade to Pro for unlimited clips.', 'warning');
}

/**
 * 업그레이드 모달 표시
 */
function showUpgradeModal() {
  const modal = new UpgradeModal({
    onUpgrade: () => {
      // 업그레이드 페이지 열기
      chrome.tabs.create({ url: 'https://thinkly.app/upgrade' });
    },
    onContinue: () => {
      // 로컬 저장으로 계속
      showToast('Clip saved locally. Upgrade to sync to cloud.', 'info');
    }
  });
  modal.show();
}

/**
 * Popup 종료 시 정리
 */
window.addEventListener('unload', () => {
  stopSyncStatePolling();
  console.log('[Thinkly] Popup closed, cleanup complete');
});
