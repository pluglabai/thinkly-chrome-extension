'use strict';

import { escapeHTML } from '../../shared/utils.js';

/**
 * CategoryPills Component
 * Horizontal scrollable category filter pills
 */

/**
 * Build category pills HTML
 * @param {Object} categories - Categories object keyed by ID
 * @param {string|null} selectedCategoryId - Currently selected category ID (null for All)
 * @returns {string} HTML string
 */
export function buildCategoryPillsHTML(categories, selectedCategoryId) {
  // Get root categories (no parentId) and sort by order
  const rootCategories = Object.values(categories)
    .filter(cat => !cat.parentId)
    .sort((a, b) => (a.order ?? 999) - (b.order ?? 999));

  // Start with "All" pill
  const isAllActive = !selectedCategoryId;
  let html = `
    <div class="category-pill${isAllActive ? ' active' : ''}" data-category-id="">
      <span class="pill-icon">📚</span>
      <span class="pill-text">All</span>
    </div>
  `;

  // Add category pills
  for (const cat of rootCategories) {
    const isActive = selectedCategoryId === cat.id;
    html += `
      <div class="category-pill${isActive ? ' active' : ''}" data-category-id="${cat.id}">
        <span class="pill-icon">${escapeHTML(cat.icon || '📁')}</span>
        <span class="pill-text">${escapeHTML(cat.name)}</span>
      </div>
    `;
  }

  return html;
}

/**
 * CategoryPills Controller class
 */
export default class CategoryPills {
  constructor(containerSelector) {
    this.container = document.querySelector(containerSelector);
    this.categories = {};
    this.selectedCategoryId = null;
    this.onCategoryChange = null;
    
    this._bindContainerEvents();
  }

  _bindContainerEvents() {
    if (!this.container) {
      console.error('CategoryPills: Container not found');
      return;
    }

    // Use event delegation for pill clicks
    this.container.addEventListener('click', (e) => {
      const pill = e.target.closest('.category-pill');
      if (pill) {
        const categoryId = pill.dataset.categoryId || null;
        this.select(categoryId);
      }
    });
  }

  /**
   * Render pills with given categories
   * @param {Object} categories - Categories object
   * @param {string|null} selectedCategoryId - Selected category ID
   */
  render(categories, selectedCategoryId = null) {
    this.categories = categories;
    this.selectedCategoryId = selectedCategoryId;

    if (!this.container) return;

    this.container.innerHTML = buildCategoryPillsHTML(categories, selectedCategoryId);
  }

  /**
   * Select a category
   * @param {string|null} categoryId - Category ID to select
   */
  select(categoryId) {
    // Skip if already selected
    if (categoryId === this.selectedCategoryId) return;

    // Update selection
    this.selectedCategoryId = categoryId;

    // Update UI
    const pills = this.container.querySelectorAll('.category-pill');
    pills.forEach(pill => {
      const pillCategoryId = pill.dataset.categoryId || null;
      pill.classList.toggle('active', pillCategoryId === categoryId);
    });

    // Trigger callback
    if (this.onCategoryChange) {
      this.onCategoryChange(categoryId);
    }
  }

  /**
   * Get currently selected category ID
   * @returns {string|null}
   */
  getSelectedCategoryId() {
    return this.selectedCategoryId;
  }

  /**
   * Set callback for category change
   * @param {Function} callback - Called with (categoryId: string|null)
   */
  setOnCategoryChange(callback) {
    this.onCategoryChange = callback;
  }

  destroy() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}
