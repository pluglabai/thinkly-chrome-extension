'use strict';

import { PRICING, UPGRADE_MESSAGES } from '../../shared/constants.js';

/**
 * Upgrade modal UI component
 * @class
 */
export default class UpgradeModal {
  /**
   * @param {Object} options - Options
   * @param {Function} options.onUpgrade - Upgrade button handler
   * @param {Function} options.onContinue - Continue button handler
   */
  constructor(options = {}) {
    this.onUpgrade = options.onUpgrade || (() => {});
    this.onContinue = options.onContinue || (() => {});
    this.overlay = null;
  }

  /**
   * Render modal HTML
   * @returns {string} HTML string
   */
  render() {
    const pricing = PRICING.PRO;

    const featureMap = {
      'unlimited_cloud_clips': 'Unlimited cloud clips',
      'branding_removal': 'Remove export branding',
      'advanced_search': 'Advanced search',
      'priority_support': 'Priority support'
    };

    return `
      <div class="upgrade-modal-overlay">
        <div class="upgrade-modal">
          <button class="modal-close-btn">&times;</button>
          <div class="upgrade-header">
            <span class="upgrade-icon">🚀</span>
            <h3>${UPGRADE_MESSAGES.PRO_TITLE}</h3>
          </div>

          <p class="upgrade-description">
            ${UPGRADE_MESSAGES.LIMIT_REACHED}
          </p>

          <div class="pricing-card">
            <span class="price">$${pricing.monthly}</span>
            <span class="period">/month</span>
          </div>

          <ul class="features-list">
            ${pricing.features.map(f => `
              <li><span class="check">✓</span> ${featureMap[f] || f}</li>
            `).join('')}
          </ul>

          <button class="upgrade-btn primary">
            ${UPGRADE_MESSAGES.PRO_CTA}
          </button>

          <button class="continue-btn secondary">
            ${UPGRADE_MESSAGES.CONTINUE_LOCAL}
          </button>
        </div>
      </div>
    `;
  }

  /**
   * Show modal
   */
  show() {
    // Create overlay element directly (not a wrapper)
    const wrapper = document.createElement('div');
    wrapper.innerHTML = this.render();
    this.overlay = wrapper.querySelector('.upgrade-modal-overlay');
    
    // Move the overlay to body and remove wrapper
    document.body.appendChild(this.overlay);

    // Add event listeners
    this.overlay.querySelector('.upgrade-btn').addEventListener('click', () => {
      this.onUpgrade();
    });

    this.overlay.querySelector('.continue-btn').addEventListener('click', () => {
      this.onContinue();
      this.hide();
    });

    this.overlay.querySelector('.modal-close-btn').addEventListener('click', () => {
      this.hide();
    });

    // Close on overlay click (but not modal content)
    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) {
        this.hide();
      }
    });
  }

  /**
   * Hide modal
   */
  hide() {
    if (this.overlay) {
      this.overlay.remove();
      this.overlay = null;
    }
  }
}
