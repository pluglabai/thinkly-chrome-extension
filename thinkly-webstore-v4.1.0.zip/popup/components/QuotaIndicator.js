'use strict';

import { UPGRADE_MESSAGES, PRICING } from '../../shared/constants.js';

/**
 * Quota indicator UI component
 * @class
 */
export default class QuotaIndicator {
  /**
   * @param {string} containerId - Container element ID
   * @param {Object} quotaManager - QuotaManager instance
   * @param {Object} options - Display options
   * @param {boolean} options.showBar - Show usage bar (for settings page)
   */
  constructor(containerId, quotaManager, options = {}) {
    this.container = document.getElementById(containerId);
    this.quotaManager = quotaManager;
    this.showBar = options.showBar || false;
  }

  /**
   * Render quota indicator
   */
  async render() {
    const quota = await this.quotaManager.getQuotaStatus();
    const isWarning = await this.quotaManager.isApproachingLimit();
    const isExceeded = quota.used >= quota.limit;
    const remaining = await this.quotaManager.getRemainingClips();
    const percentage = Math.min((quota.used / quota.limit) * 100, 100);

    let className = 'quota-indicator';
    if (isExceeded) className += ' exceeded';
    else if (isWarning) className += ' warning';

    let html = `
      <div class="${className}">
        <span class="quota-icon">☁️</span>
        <span class="quota-count">${quota.used}/${quota.limit}</span>
        <span class="quota-label">clips</span>
        ${isWarning && !isExceeded ? `<span class="quota-remaining">(${remaining} left)</span>` : ''}
        ${isExceeded ? '<span class="quota-upgrade">Upgrade →</span>' : ''}
      </div>
    `;

    // Add usage bar for settings page
    if (this.showBar) {
      html += this._renderUsageBar(percentage, isWarning, isExceeded, remaining);
    }

    this.container.innerHTML = html;

    // Add click handler for upgrade
    if (isExceeded || isWarning) {
      this.container.querySelector('.quota-indicator').addEventListener('click', () => {
        this.container.dispatchEvent(new CustomEvent('quota:upgrade'));
      });
    }
  }

  /**
   * Render usage bar for settings
   * @private
   */
  _renderUsageBar(percentage, isWarning, isExceeded, remaining) {
    let barClass = 'usage-bar';
    if (isExceeded) barClass += ' exceeded';
    else if (isWarning) barClass += ' warning';

    const pricing = PRICING.PRO;
    const featureMap = {
      'unlimited_cloud_clips': 'Unlimited cloud clips',
      'branding_removal': 'Remove export branding',
      'advanced_search': 'Advanced search',
      'priority_support': 'Priority support'
    };

    return `
      <div class="usage-stats">
        <div class="usage-bar-container">
          <div class="${barClass}" style="width: ${percentage}%"></div>
        </div>
        <div class="usage-text">
          <span class="usage-count">${Math.round(percentage)}%</span>
        </div>
        ${isWarning ? `
          <div class="upgrade-prompt">
            <p>⚠️ ${remaining} clips remaining</p>
            <ul class="features-list">
              ${pricing.features.map(f => `
                <li><span class="check">✓</span> ${featureMap[f] || f}</li>
              `).join('')}
            </ul>
            <button class="upgrade-btn-sm">
              🚀 Upgrade to Pro - $${pricing.monthly}/month
            </button>
          </div>
        ` : ''}
      </div>
    `;
  }

  /**
   * Update quota display (clear cache and re-render)
   */
  async update() {
    this.quotaManager.clearCache();
    await this.render();
  }
}
