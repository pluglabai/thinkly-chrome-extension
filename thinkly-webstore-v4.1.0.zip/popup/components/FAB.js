'use strict';

/**
 * FAB (Floating Action Button) Component
 * Provides quick access to add URL/File/Text clips
 */

export const FAB_TYPES = {
  URL: 'url',
  FILE: 'file',
  TEXT: 'text'
};

/**
 * Create FAB HTML
 * @returns {string} FAB HTML
 */
export function createFABHTML() {
  return `
    <button class="fab" id="fab-btn" title="Add clip">+</button>
    <div class="fab-menu" id="fab-menu">
      <div class="fab-option" data-type="${FAB_TYPES.URL}">
        <span class="fab-option-icon">🔗</span>
        <span class="fab-option-text">URL</span>
      </div>
      <div class="fab-option" data-type="${FAB_TYPES.FILE}">
        <span class="fab-option-icon">📁</span>
        <span class="fab-option-text">File</span>
      </div>
      <div class="fab-option" data-type="${FAB_TYPES.TEXT}">
        <span class="fab-option-icon">📝</span>
        <span class="fab-option-text">Text</span>
      </div>
    </div>
  `;
}

/**
 * FAB Controller class
 */
export default class FAB {
  constructor(containerSelector) {
    this.container = document.querySelector(containerSelector);
    this.isExpanded = false;
    this.onOptionSelect = null;
    
    this._init();
  }

  _init() {
    if (!this.container) {
      console.error('FAB: Container not found');
      return;
    }

    // Inject HTML
    this.container.innerHTML = createFABHTML();

    // Get elements
    this.fabBtn = this.container.querySelector('#fab-btn');
    this.fabMenu = this.container.querySelector('#fab-menu');
    this.options = this.container.querySelectorAll('.fab-option');

    // Bind events
    this._bindEvents();
  }

  _bindEvents() {
    // FAB button click
    this.fabBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      this.toggle();
    });

    // Option clicks
    this.options.forEach(option => {
      option.addEventListener('click', (e) => {
        const type = e.currentTarget.dataset.type;
        this.collapse();
        if (this.onOptionSelect) {
          this.onOptionSelect(type);
        }
      });
    });

    // Click outside to close
    document.addEventListener('click', (e) => {
      if (!this.container.contains(e.target)) {
        this.collapse();
      }
    });

    // Escape key to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isExpanded) {
        this.collapse();
      }
    });
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
    this.fabBtn.classList.toggle('expanded', this.isExpanded);
    this.fabMenu.classList.toggle('show', this.isExpanded);
  }

  expand() {
    this.isExpanded = true;
    this.fabBtn.classList.add('expanded');
    this.fabMenu.classList.add('show');
  }

  collapse() {
    this.isExpanded = false;
    this.fabBtn.classList.remove('expanded');
    this.fabMenu.classList.remove('show');
  }

  /**
   * Set callback for option selection
   * @param {Function} callback - Called with (type: 'url'|'file'|'text')
   */
  setOnOptionSelect(callback) {
    this.onOptionSelect = callback;
  }

  destroy() {
    if (this.container) {
      this.container.innerHTML = '';
    }
  }
}
