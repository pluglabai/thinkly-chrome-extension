'use strict';

import { toStoredCategoryId } from '../shared/category-display.js';

export async function moveClipToCategory({ clipManager, clipId, categoryId }) {
  if (!clipManager || !clipId) {
    return null;
  }

  return clipManager.updateClip(clipId, {
    categoryId: toStoredCategoryId(categoryId)
  });
}
