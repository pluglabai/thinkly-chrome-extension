'use strict';

export const POPUP_NEW_COPY = {
  documentTitle: 'Thinkly - Clip Library',
  searchPlaceholder: 'Search clips...',
  exportActionLabel: 'Export clips',
  emptyTitle: 'No clips yet',
  modalTitle: 'Clip Title',
  selectionPrompt: 'Select clips to export',
  deleteDialog: {
    title: 'Delete clip?',
    message: 'This will remove the clip from your local library.',
    confirmText: 'Delete',
    cancelText: 'Keep',
  },
};

export function applyPopupNewCopy(doc, copy = POPUP_NEW_COPY) {
  doc.title = copy.documentTitle;

  const searchInput = doc.getElementById('search-input');
  if (searchInput) {
    searchInput.setAttribute('placeholder', copy.searchPlaceholder);
  }

  const exportLabel = doc.getElementById('settings-export-label');
  if (exportLabel) {
    exportLabel.textContent = copy.exportActionLabel;
  }

  const emptyTitle = doc.getElementById('empty-state-title');
  if (emptyTitle) {
    emptyTitle.textContent = copy.emptyTitle;
  }

  const modalTitle = doc.getElementById('modal-title');
  if (modalTitle && !modalTitle.textContent?.trim()) {
    modalTitle.textContent = copy.modalTitle;
  }
}
