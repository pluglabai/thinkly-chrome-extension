'use strict';

export const POPUP_AUTO_SYNC_STORAGE_KEY = 'autoSync';

export async function readPopupAutoSyncPreference(storageArea) {
  const data = await storageArea.get(POPUP_AUTO_SYNC_STORAGE_KEY);
  return data[POPUP_AUTO_SYNC_STORAGE_KEY] === true;
}

export async function writePopupAutoSyncPreference(storageArea, enabled) {
  const normalizedEnabled = enabled === true;
  await storageArea.set({
    [POPUP_AUTO_SYNC_STORAGE_KEY]: normalizedEnabled
  });
  return normalizedEnabled;
}

export function shouldRunPopupAutoSync({ isAuthenticated, autoSyncEnabled }) {
  return isAuthenticated === true && autoSyncEnabled === true;
}
