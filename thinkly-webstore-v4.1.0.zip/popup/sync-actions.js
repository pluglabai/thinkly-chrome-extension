'use strict';

/**
 * Run the popup's full authenticated sync flow.
 * The caller owns auth checks and user-facing toasts.
 *
 * @param {Object} deps
 * @param {Function} deps.sendAll - Sends unsent local clips if needed
 * @param {Object} deps.syncManager - SyncManager instance
 * @param {Function} deps.loadData - Reload popup data from storage
 * @param {Function} deps.renderCategoryPills - Re-render category pills
 * @param {Function} deps.renderClips - Re-render clips list
 * @param {Function} [deps.updatePanelCategories] - Refresh add-panel category options
 * @param {Function} [deps.updateSendBar] - Refresh send bar state
 * @returns {Promise<Object>} Sync result
 */
export async function performAuthenticatedSync({
  sendAll,
  syncManager,
  loadData,
  renderCategoryPills,
  renderClips,
  updatePanelCategories,
  updateSendBar
}) {
  await sendAll();
  const syncResult = await syncManager.sync();
  await loadData();
  renderCategoryPills();

  if (updatePanelCategories) {
    updatePanelCategories();
  }

  renderClips();

  if (updateSendBar) {
    await updateSendBar();
  }

  return syncResult;
}
