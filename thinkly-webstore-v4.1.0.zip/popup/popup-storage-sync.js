'use strict';

const WATCHED_STORAGE_KEYS = ['clips', 'categories'];

export function shouldRefreshPopupForStorageChange(changes, areaName) {
  if (areaName !== 'local' || !changes) {
    return false;
  }

  return WATCHED_STORAGE_KEYS.some((key) => Object.hasOwn(changes, key));
}

export function subscribePopupStorageSync(chromeApi, onRefresh) {
  const storageOnChanged = chromeApi?.storage?.onChanged;

  if (!storageOnChanged || typeof storageOnChanged.addListener !== 'function') {
    return () => {};
  }

  const listener = (changes, areaName) => {
    if (shouldRefreshPopupForStorageChange(changes, areaName)) {
      onRefresh();
    }
  };

  storageOnChanged.addListener(listener);

  return () => {
    if (typeof storageOnChanged.removeListener === 'function') {
      storageOnChanged.removeListener(listener);
    }
  };
}
