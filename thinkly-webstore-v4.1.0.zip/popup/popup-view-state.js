'use strict';

export const POPUP_MAIN_CONTENT_SELECTORS = [
  '#category-pills',
  '.search-container',
  '#clips-list',
  '#empty-state',
  '#send-bar',
  '#fab-container',
  '.dashboard-link-container'
];

export const POPUP_SELECTION_AUXILIARY_SELECTORS = [
  '#fab-container',
  '.dashboard-link-container'
];

const PREVIOUS_DISPLAY_KEY = 'popupPrevDisplay';

function getElements(doc, selectors) {
  return selectors
    .map(selector => doc.querySelector(selector))
    .filter(Boolean);
}

function hideElements(doc, selectors) {
  getElements(doc, selectors).forEach((element) => {
    if (!Object.prototype.hasOwnProperty.call(element.dataset, PREVIOUS_DISPLAY_KEY)) {
      element.dataset[PREVIOUS_DISPLAY_KEY] = element.style.display || '';
    }
    element.style.display = 'none';
  });
}

function showElements(doc, selectors) {
  getElements(doc, selectors).forEach((element) => {
    const previousDisplay = element.dataset[PREVIOUS_DISPLAY_KEY] ?? '';
    element.style.display = previousDisplay;
    delete element.dataset[PREVIOUS_DISPLAY_KEY];
  });
}

export function hidePopupMainContent(doc) {
  hideElements(doc, POPUP_MAIN_CONTENT_SELECTORS);
}

export function showPopupMainContent(doc) {
  showElements(doc, POPUP_MAIN_CONTENT_SELECTORS);
}

export function setSelectionModeAuxiliaryVisibility(doc, isHidden) {
  if (isHidden) {
    hideElements(doc, POPUP_SELECTION_AUXILIARY_SELECTORS);
    return;
  }

  showElements(doc, POPUP_SELECTION_AUXILIARY_SELECTORS);
}
