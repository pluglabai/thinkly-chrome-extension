'use strict';

/**
 * GroupParser — Parse, serialize, and validate Group markers in Page.bodyMarkdown
 *
 * Group structure is stored inside bodyMarkdown as a marker block:
 *   <!-- THINKLY_PAGE_GROUPS schemaVersion:1 -->
 *   {"groups":[...]}
 *   <!-- /THINKLY_PAGE_GROUPS -->
 *
 * Spec: docs/files/data-model/02-page.md
 */

const MARKER_OPEN_PREFIX = '<!-- THINKLY_PAGE_GROUPS';
const MARKER_CLOSE = '<!-- /THINKLY_PAGE_GROUPS -->';

/**
 * Parse groups from bodyMarkdown marker block
 * @param {string} bodyMarkdown - Page body markdown text
 * @returns {Array<{id: string, title: string, highlightIds: string[], collapsed: boolean}>}
 */
export function parseGroupsFromMarkdown(bodyMarkdown) {
  if (!bodyMarkdown || typeof bodyMarkdown !== 'string') {
    return [];
  }

  const lines = bodyMarkdown.split('\n');
  let insideMarker = false;
  let jsonLines = [];

  for (const line of lines) {
    if (line.trimStart().startsWith(MARKER_OPEN_PREFIX)) {
      insideMarker = true;
      jsonLines = [];
      continue;
    }

    if (insideMarker && line.trimStart().startsWith(MARKER_CLOSE)) {
      // End of marker — parse collected JSON
      const jsonStr = jsonLines.join('\n').trim();
      try {
        const parsed = JSON.parse(jsonStr);
        if (parsed && Array.isArray(parsed.groups)) {
          return parsed.groups;
        }
      } catch {
        // JSON parse failure → fallback to empty groups
      }
      return [];
    }

    if (insideMarker) {
      jsonLines.push(line);
    }
  }

  // Marker opened but never closed, or no marker found
  return [];
}

/**
 * Serialize groups into bodyMarkdown, replacing existing marker block or appending
 * @param {string} bodyMarkdown - Current body markdown text
 * @param {Array<{id: string, title: string, highlightIds: string[], collapsed: boolean}>} groups
 * @returns {string} Updated body markdown
 */
export function serializeGroupsToMarkdown(bodyMarkdown, groups) {
  const body = bodyMarkdown || '';

  // Build new marker block (or empty string if no groups)
  let markerBlock = '';
  if (groups && groups.length > 0) {
    const json = JSON.stringify({ groups });
    markerBlock = `${MARKER_OPEN_PREFIX} schemaVersion:1 -->\n${json}\n${MARKER_CLOSE}`;
  }

  // Check if existing marker block exists
  const lines = body.split('\n');
  const openIdx = lines.findIndex(l => l.trimStart().startsWith(MARKER_OPEN_PREFIX));

  if (openIdx === -1) {
    // No existing marker — append if groups exist
    if (!markerBlock) return body;
    return body ? `${body}\n${markerBlock}` : markerBlock;
  }

  // Find closing marker
  let closeIdx = -1;
  for (let i = openIdx + 1; i < lines.length; i++) {
    if (lines[i].trimStart().startsWith(MARKER_CLOSE)) {
      closeIdx = i;
      break;
    }
  }

  if (closeIdx === -1) {
    // Malformed — open without close. Replace from openIdx to end.
    closeIdx = lines.length - 1;
  }

  // Replace the marker block region
  const before = lines.slice(0, openIdx);
  const after = lines.slice(closeIdx + 1);

  if (!markerBlock) {
    // Remove marker entirely
    const result = [...before, ...after].join('\n');
    return result.replace(/\n{3,}/g, '\n\n').trim();
  }

  return [...before, markerBlock, ...after].join('\n');
}

/**
 * Validate group membership rules for a page
 * Rules from spec:
 * - No duplicate membership (1 highlight max 1 group per page)
 * - All grouped highlight IDs must exist in page.highlightIds
 * @param {{highlightIds: string[], bodyMarkdown: string}} page
 * @returns {{valid: boolean, errors: string[]}}
 */
export function validateGroupMembership(page) {
  const errors = [];
  const groups = parseGroupsFromMarkdown(page.bodyMarkdown);
  const allGrouped = groups.flatMap(g => g.highlightIds || []);
  const uniqueGrouped = new Set(allGrouped);

  // Check duplicate membership
  if (allGrouped.length !== uniqueGrouped.size) {
    errors.push('Duplicate group membership: a highlight belongs to more than one group');
  }

  // Check all grouped IDs exist in page.highlightIds
  const pageIdSet = new Set(page.highlightIds || []);
  for (const id of uniqueGrouped) {
    if (!pageIdSet.has(id)) {
      errors.push(`Grouped highlight "${id}" is not in page.highlightIds`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
