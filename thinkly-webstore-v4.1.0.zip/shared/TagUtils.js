'use strict';

/**
 * TagUtils — Tag normalization utilities
 *
 * Spec: docs/files/features/02-tag-system.md
 */

// MVP: empty alias map, structure only for future expansion
const aliasMap = {};

/**
 * Normalize a single tag string
 * Rules: trim → collapse whitespace → strip leading # → lowercase → aliasMap
 * @param {string} raw
 * @returns {string}
 */
export function normalizeTag(raw) {
  if (!raw || typeof raw !== 'string') return '';
  let t = raw.trim();
  t = t.replace(/\s+/g, ' ');     // collapse consecutive whitespace
  t = t.replace(/^#+/, '');        // strip leading #
  t = t.trim();                    // re-trim after # removal
  t = t.toLowerCase();
  t = aliasMap[t] || t;            // alias mapping
  return t;
}

/**
 * Normalize an array of tags: normalize each, remove empty, dedup
 * @param {string[]} tags
 * @returns {string[]}
 */
export function normalizeTags(tags) {
  if (!Array.isArray(tags)) return [];
  return [...new Set(
    tags.map(normalizeTag).filter(t => t.length > 0)
  )];
}
