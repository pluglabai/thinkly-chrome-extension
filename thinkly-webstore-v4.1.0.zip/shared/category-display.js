'use strict';

export const UNCATEGORIZED_CATEGORY = Object.freeze({
  id: null,
  optionValue: '__uncategorized__',
  name: 'Uncategorized',
  icon: '📭',
  order: -1
});

export function isUncategorizedCategoryId(categoryId) {
  return (
    categoryId === null ||
    categoryId === undefined ||
    categoryId === '' ||
    categoryId === UNCATEGORIZED_CATEGORY.optionValue
  );
}

export function toStoredCategoryId(categoryId) {
  return isUncategorizedCategoryId(categoryId) ? null : categoryId;
}

export function toCategoryOptionValue(categoryId) {
  return isUncategorizedCategoryId(categoryId)
    ? UNCATEGORIZED_CATEGORY.optionValue
    : categoryId;
}

export function getCategoryDisplay(categoryId, categories = {}) {
  const storedCategoryId = toStoredCategoryId(categoryId);

  if (!storedCategoryId) {
    return UNCATEGORIZED_CATEGORY;
  }

  return categories[storedCategoryId] || null;
}

export function getRootCategoryOptions(categories = {}) {
  const rootCategories = Object.values(categories)
    .filter((category) => !category.parentId)
    .sort((a, b) => (a.order ?? 999) - (b.order ?? 999));

  return [UNCATEGORIZED_CATEGORY, ...rootCategories];
}
