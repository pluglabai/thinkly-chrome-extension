'use strict';

/**
 * StorageManager - Abstraction over chrome.storage.local
 * Provides error handling and quota management for extension data persistence
 *
 * @class
 * @example
 * const storage = new StorageManager();
 * await storage.set('clips', [...]);
 * const clips = await storage.get('clips');
 */
class StorageManager {
  /**
   * Storage quota constants
   * @private
   */
  static QUOTA_WARNING = 8 * 1024 * 1024;  // 8MB (80%)
  static QUOTA_MAX = 10 * 1024 * 1024;     // 10MB (100%)

  /**
   * Check if chrome.storage.local is available
   * @private
   * @returns {boolean}
   */
  _isStorageAvailable() {
    return typeof chrome !== 'undefined' && 
           chrome.storage && 
           chrome.storage.local;
  }

  /**
   * Get storage API with availability check
   * @private
   * @returns {Object} chrome.storage.local
   * @throws {Error} If storage is not available
   */
  _getStorage() {
    try {
      if (!this._isStorageAvailable()) {
        const error = new Error('Extension needs refresh. Please reload the page (Cmd+R).');
        error.isContextInvalidated = true;
        throw error;
      }
      // Double-check access to prevent race conditions
      const storage = chrome.storage.local;
      if (!storage) {
        const error = new Error('Extension needs refresh. Please reload the page (Cmd+R).');
        error.isContextInvalidated = true;
        throw error;
      }
      return storage;
    } catch (e) {
      // Catch any access errors (extension context invalidated)
      const error = new Error('Extension needs refresh. Please reload the page (Cmd+R).');
      error.isContextInvalidated = true;
      throw error;
    }
  }

  /**
   * Handle storage errors with context
   * @private
   * @param {Error} error - Original error
   * @param {string} operation - Operation name (get/set/remove/etc.)
   * @throws {Error} Enriched error
   */
  _handleStorageError(error, operation) {
    console.error(`[Thinkly Error] StorageManager.${operation}():`, error);

    // Handle extension context invalidation (extension reloaded)
    if (error.message.includes('Extension context invalidated') ||
        error.message.includes('Extension needs refresh') ||
        error.message.includes("Cannot read properties of undefined") ||
        error.message.includes("Cannot read property") ||
        error.isContextInvalidated) {
      const friendlyError = new Error('페이지 새로고침이 필요해요 (Cmd+R)');
      friendlyError.isContextInvalidated = true;
      throw friendlyError;
    }

    // Handle storage not available
    if (error.message.includes('Chrome storage API is not available')) {
      const friendlyError = new Error('페이지 새로고침이 필요해요 (Cmd+R)');
      friendlyError.isContextInvalidated = true;
      throw friendlyError;
    }

    // Handle quota errors specifically
    if (error.message.includes('QUOTA_BYTES_PER_ITEM') ||
        error.message.includes('quota exceeded')) {
      throw new Error('Storage quota exceeded');
    }

    throw error;
  }

  /**
   * Get value from chrome.storage.local
   * @param {string} key - Storage key
   * @returns {Promise<any|null>} Value or null if not found
   * @throws {Error} If storage access fails
   * @example
   * const clips = await storage.get('clips');
   * if (clips === null) {
   *   // Key not found
   * }
   */
  async get(key) {
    try {
      const storage = this._getStorage();
      const result = await storage.get([key]);
      return result[key] !== undefined ? result[key] : null;
    } catch (error) {
      this._handleStorageError(error, 'get');
    }
  }

  /**
   * Set value in chrome.storage.local
   * @param {string} key - Storage key
   * @param {any} value - Value to store
   * @returns {Promise<void>}
   * @throws {Error} If quota exceeded or storage access fails
   * @example
   * await storage.set('clips', [...]);
   */
  async set(key, value) {
    try {
      const storage = this._getStorage();
      // Check quota before writing
      const usage = await storage.getBytesInUse();

      if (usage > StorageManager.QUOTA_WARNING) {
        console.warn(`[Thinkly Warning] Storage usage > 80%:`, usage, 'bytes');
      }

      if (usage > StorageManager.QUOTA_MAX) {
        throw new Error('Storage quota exceeded');
      }

      await storage.set({ [key]: value });
    } catch (error) {
      this._handleStorageError(error, 'set');
    }
  }

  /**
   * Remove key from chrome.storage.local
   * @param {string} key - Storage key
   * @returns {Promise<void>}
   * @throws {Error} If storage access fails
   */
  async remove(key) {
    try {
      const storage = this._getStorage();
      await storage.remove(key);
    } catch (error) {
      this._handleStorageError(error, 'remove');
    }
  }

  /**
   * Get all keys and values from chrome.storage.local
   * @returns {Promise<Object>} All stored key-value pairs
   * @throws {Error} If storage access fails
   */
  async getAll() {
    try {
      const storage = this._getStorage();
      const result = await storage.get(null);
      return result;
    } catch (error) {
      this._handleStorageError(error, 'getAll');
    }
  }

  /**
   * Clear all data from chrome.storage.local
   * @returns {Promise<void>}
   * @throws {Error} If storage access fails
   */
  async clear() {
    try {
      const storage = this._getStorage();
      await storage.clear();
    } catch (error) {
      this._handleStorageError(error, 'clear');
    }
  }
}

export default StorageManager;
