'use strict';

import { VALIDATION_RULES } from './constants.js';

/**
 * Sanitize string input (remove HTML, trim, truncate)
 * @param {string} input - Raw input
 * @param {number} maxLength - Maximum length
 * @returns {string} Sanitized string
 * @example
 * sanitizeInput('<b>Hello</b>', 100) // => "bHello/b"
 */
export function sanitizeInput(input, maxLength) {
  if (!input) return '';
  return input
    .replace(/[<>]/g, '')  // Remove HTML brackets for XSS prevention
    .trim()
    .slice(0, maxLength);
}

/**
 * Validate emoji (single character only)
 * @param {string} emoji - Emoji to validate
 * @returns {boolean} True if valid single emoji
 * @example
 * isValidEmoji('💡') // => true
 * isValidEmoji('Hello') // => false
 */
export function isValidEmoji(emoji) {
  if (!emoji || typeof emoji !== 'string') return false;

  // Reject obvious non-emojis (ASCII letters, numbers, common words)
  if (/^[a-zA-Z0-9]+$/.test(emoji)) return false;

  // Allow up to 10 chars to handle multi-byte emojis (skin tones, ZWJ sequences)
  // But reject strings that are clearly too long to be a single emoji
  return emoji.length > 0 && emoji.length <= 10 && !emoji.includes(' ');
}

/**
 * Validate and sanitize clip data
 * @param {Object} clip - Clip object to validate
 * @returns {Object} Sanitized clip data
 * @throws {Error} Validation error with field name and constraint
 * @example
 * validateClipData({
 *   text: 'Sample text',
 *   title: 'Title',
 *   url: 'https://chat.openai.com/c/123',
 *   icon: '💡',
 *   categoryId: 'cat_general',
 *   source: { platform: 'chatgpt', ... },
 *   createdAt: Date.now()
 * })
 */
export function validateClipData(clip) {
  if (!clip || typeof clip !== 'object') {
    throw new Error('Clip data must be an object');
  }

  const errors = [];

  // Validate text (no silent truncation — reject if over limit)
  const text = clip.text ? clip.text.replace(/[<>]/g, '').trim() : '';
  if (text.length < VALIDATION_RULES.CLIP_TEXT_MIN) {
    errors.push(`Clip text must be at least ${VALIDATION_RULES.CLIP_TEXT_MIN} character`);
  }
  if (text.length > VALIDATION_RULES.CLIP_TEXT_MAX) {
    errors.push(`Clip text must not exceed ${VALIDATION_RULES.CLIP_TEXT_MAX} characters (got ${text.length})`);
  }

  // Validate and sanitize title
  const title = sanitizeInput(clip.title, VALIDATION_RULES.CLIP_TITLE_MAX);
  if (title.length < VALIDATION_RULES.CLIP_TITLE_MIN) {
    errors.push(`Clip title must be at least ${VALIDATION_RULES.CLIP_TITLE_MIN} character`);
  }
  if (clip.title && clip.title.length > VALIDATION_RULES.CLIP_TITLE_MAX) {
    errors.push(`Clip title must not exceed ${VALIDATION_RULES.CLIP_TITLE_MAX} characters`);
  }

  // Validate URL (optional — text paste may not have URL)
  if (clip.url !== undefined && clip.url !== null && typeof clip.url !== 'string') {
    errors.push('Clip URL must be a string');
  }

  // Validate icon
  if (!isValidEmoji(clip.icon)) {
    errors.push('Clip icon must be a valid emoji');
  }

  // Validate categoryId
  if (
    clip.categoryId !== undefined &&
    clip.categoryId !== null &&
    typeof clip.categoryId !== 'string'
  ) {
    errors.push('Category ID must be a string or null');
  }

  // Validate source
  if (!clip.source || typeof clip.source !== 'object') {
    errors.push('Clip source metadata is required');
  } else {
    const validPlatforms = VALIDATION_RULES.VALID_PLATFORMS;
    if (!validPlatforms.includes(clip.source.platform)) {
      errors.push(`Platform must be one of: ${validPlatforms.join(', ')}`);
    }
    // Validate optional siteName field
    if (clip.source.siteName !== undefined && clip.source.siteName !== null) {
      if (typeof clip.source.siteName !== 'string') {
        errors.push('Clip source siteName must be a string');
      }
    }
  }

  // Validate createdAt
  if (!clip.createdAt || typeof clip.createdAt !== 'number' || clip.createdAt <= 0) {
    errors.push('Clip createdAt must be a positive timestamp');
  }

  // Validate tags (optional, array of strings)
  if (clip.tags !== undefined && clip.tags !== null) {
    if (!Array.isArray(clip.tags)) {
      errors.push('Clip tags must be an array');
    } else if (!clip.tags.every(t => typeof t === 'string')) {
      errors.push('Clip tags must be an array of strings');
    }
  }

  // Validate starred (optional, boolean)
  if (clip.starred !== undefined && clip.starred !== null && typeof clip.starred !== 'boolean') {
    errors.push('Clip starred must be a boolean');
  }

  if (errors.length > 0) {
    throw new Error(`Clip validation failed: ${errors.join('; ')}`);
  }

  // Return sanitized clip
  return {
    ...clip,
    text,
    title,
    categoryId: clip.categoryId ?? null
  };
}

/**
 * Get category depth by traversing parent chain
 * @private
 * @param {Object} category - Category to check
 * @param {Object} existingCategories - All categories (keyed by ID)
 * @returns {number} Depth (0 = root, 1 = child, 2 = grandchild)
 */
function getCategoryDepth(category, existingCategories) {
  if (!category.parentId) return 0;  // Root category

  let depth = 1;
  let currentId = category.parentId;

  while (currentId) {
    const parent = existingCategories[currentId];
    if (!parent) break;  // Parent not found, treat as root
    if (!parent.parentId) break;  // Reached root

    depth++;
    currentId = parent.parentId;
  }

  return depth;
}

/**
 * Validate and sanitize category data
 * @param {Object} category - Category object to validate
 * @param {Object} existingCategories - All categories (for depth check)
 * @returns {Object} Sanitized category data
 * @throws {Error} Validation error with field name and constraint
 * @example
 * validateCategoryData({
 *   id: 'cat_test',
 *   name: 'Test',
 *   parentId: null,
 *   icon: '📂',
 *   order: 0,
 *   createdAt: Date.now(),
 *   updatedAt: Date.now()
 * }, {})
 */
export function validateCategoryData(category, existingCategories = {}) {
  if (!category || typeof category !== 'object') {
    throw new Error('Category data must be an object');
  }

  const errors = [];

  // Validate and sanitize name
  const name = sanitizeInput(category.name, VALIDATION_RULES.CATEGORY_NAME_MAX);
  if (name.length < VALIDATION_RULES.CATEGORY_NAME_MIN) {
    errors.push(`Category name must be at least ${VALIDATION_RULES.CATEGORY_NAME_MIN} character`);
  }
  if (category.name && category.name.length > VALIDATION_RULES.CATEGORY_NAME_MAX) {
    errors.push(`Category name must not exceed ${VALIDATION_RULES.CATEGORY_NAME_MAX} characters`);
  }

  // Validate icon
  if (!isValidEmoji(category.icon)) {
    errors.push('Category icon must be a valid emoji');
  }

  // Validate parentId
  if (category.parentId !== null && category.parentId !== undefined) {
    if (typeof category.parentId !== 'string') {
      errors.push('Category parentId must be a string or null');
    } else if (!existingCategories[category.parentId]) {
      errors.push(`Parent category '${category.parentId}' does not exist`);
    }
  }

  // Validate depth
  const depth = getCategoryDepth(category, existingCategories);
  if (depth >= VALIDATION_RULES.MAX_CATEGORY_DEPTH) {
    errors.push(`Category depth cannot exceed ${VALIDATION_RULES.MAX_CATEGORY_DEPTH} levels (root + child only)`);
  }

  if (errors.length > 0) {
    throw new Error(`Category validation failed: ${errors.join('; ')}`);
  }

  // Return sanitized category
  return {
    ...category,
    name
  };
}
