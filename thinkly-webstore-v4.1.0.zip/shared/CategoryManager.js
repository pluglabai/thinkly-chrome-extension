'use strict';

import StorageManager from './StorageManager.js';
import { validateCategoryData } from './validators.js';
import { DEFAULT_CATEGORIES, STORAGE_KEYS } from './constants.js';

/**
 * CategoryManager - Manages category CRUD operations and hierarchy
 * @class
 * @example
 * const manager = new CategoryManager();
 * await manager.initializeDefaultCategories();
 * const category = await manager.addCategory({ name: 'Test', ... });
 */
export default class CategoryManager {
  /**
   * Create CategoryManager instance
   * @param {Object} options - Optional configuration
   * @param {Object} options.syncManager - SyncManager instance for cloud sync
   */
  constructor(options = {}) {
    this.storage = new StorageManager();
    this.syncManager = options.syncManager || null;
  }

  /**
   * Set the sync manager for cloud sync operations
   * @param {Object} syncManager - SyncManager instance
   */
  setSyncManager(syncManager) {
    this.syncManager = syncManager;
  }

  /**
   * Initialize default categories if none exist
   * @returns {Promise<void>}
   * @example
   * await manager.initializeDefaultCategories();
   */
  async initializeDefaultCategories() {
    const categories = await this.storage.get(STORAGE_KEYS.CATEGORIES);

    if (categories && Object.keys(categories).length > 0) {
      return; // Categories already exist, don't overwrite
    }

    // Convert DEFAULT_CATEGORIES array to object keyed by ID
    const categoriesObj = {};
    DEFAULT_CATEGORIES.forEach(cat => {
      categoriesObj[cat.id] = cat;
    });

    await this.storage.set(STORAGE_KEYS.CATEGORIES, categoriesObj);
  }

  /**
   * Add new category with validation
   * @param {Object} category - Category data
   * @returns {Promise<Object>} Added category
   * @throws {Error} Validation error
   * @example
   * const category = await manager.addCategory({
   *   id: 'cat_test',
   *   name: 'Test',
   *   parentId: null,
   *   icon: '📁',
   *   order: 0,
   *   createdAt: Date.now(),
   *   updatedAt: Date.now()
   * });
   */
  async addCategory(category) {
    const existingCategories = await this.getAllCategories();

    // Add updatedAt if not provided
    if (!category.updatedAt) {
      category.updatedAt = Date.now();
    }

    // Validate category data (includes depth check)
    const validatedCategory = validateCategoryData(category, existingCategories);

    // Add to storage
    existingCategories[category.id] = validatedCategory;
    await this.storage.set(STORAGE_KEYS.CATEGORIES, existingCategories);

    // Queue for sync if sync manager is available
    if (this.syncManager) {
      await this.syncManager.queueCategorySync('create', validatedCategory);
    }

    return validatedCategory;
  }

  /**
   * Get category by ID
   * @param {string} categoryId - Category ID
   * @returns {Promise<Object|null>} Category or null if not found
   * @example
   * const category = await manager.getCategory('cat_general');
   */
  async getCategory(categoryId) {
    const categories = await this.storage.get(STORAGE_KEYS.CATEGORIES);

    if (!categories) {
      return null;
    }

    return categories[categoryId] || null;
  }

  /**
   * Get all categories
   * @returns {Promise<Object>} All categories (object keyed by ID)
   * @example
   * const categories = await manager.getAllCategories();
   */
  async getAllCategories() {
    const categories = await this.storage.get(STORAGE_KEYS.CATEGORIES);
    return categories || {};
  }

  /**
   * Update existing category
   * @param {string} categoryId - Category ID
   * @param {Object} updates - Fields to update
   * @returns {Promise<Object>} Updated category
   * @throws {Error} If category not found or validation fails
   * @example
   * const updated = await manager.updateCategory('cat_test', {
   *   name: 'New Name',
   *   icon: '🗂️'
   * });
   */
  async updateCategory(categoryId, updates) {
    const categories = await this.getAllCategories();
    const category = categories[categoryId];

    if (!category) {
      throw new Error('Category not found');
    }

    // Prevent changing parentId (would require re-validation of entire hierarchy)
    if (updates.parentId !== undefined && updates.parentId !== category.parentId) {
      throw new Error('Cannot change parentId after creation');
    }

    // Merge updates
    const updatedCategory = {
      ...category,
      ...updates,
      id: category.id,  // Prevent ID change
      parentId: category.parentId,  // Prevent parentId change
      createdAt: category.createdAt,  // Prevent createdAt change
      updatedAt: Date.now()
    };

    // Validate updated category
    const validatedCategory = validateCategoryData(updatedCategory, categories);

    // Save
    categories[categoryId] = validatedCategory;
    await this.storage.set(STORAGE_KEYS.CATEGORIES, categories);

    // Queue for sync if sync manager is available
    if (this.syncManager) {
      await this.syncManager.queueCategorySync('update', validatedCategory);
    }

    return validatedCategory;
  }

  /**
   * Delete category
   * @param {string} categoryId - Category ID
   * @returns {Promise<Object>} Deleted category data (for sync)
   * @throws {Error} If category has children or not found
   * @example
   * await manager.deleteCategory('cat_test');
   */
  async deleteCategory(categoryId) {
    const categories = await this.getAllCategories();

    if (!categories[categoryId]) {
      throw new Error('Category not found');
    }

    // Check for children
    const hasChildren = Object.values(categories).some(
      cat => cat.parentId === categoryId
    );

    if (hasChildren) {
      throw new Error('Cannot delete category with children. Delete child categories first.');
    }

    // Get category data for sync before removing
    const now = Date.now();
    const deletedCategory = {
      ...categories[categoryId],
      updatedAt: now,
      deletedAt: now
    };

    // Migrate orphaned clips to uncategorized
    const clips = await this.storage.get(STORAGE_KEYS.CLIPS) || [];
    let clipsMigrated = false;
    const updatedClips = clips.map(clip => {
      if (clip.categoryId === categoryId) {
        clipsMigrated = true;
        return { ...clip, categoryId: null, updatedAt: now };
      }
      return clip;
    });

    // Only update clips if any were migrated
    if (clipsMigrated) {
      await this.storage.set(STORAGE_KEYS.CLIPS, updatedClips);
    }

    // Delete category
    delete categories[categoryId];
    await this.storage.set(STORAGE_KEYS.CATEGORIES, categories);

    // Queue for sync if sync manager is available
    if (this.syncManager) {
      await this.syncManager.queueCategorySync('delete', deletedCategory);
    }

    return deletedCategory;
  }

  /**
   * Build hierarchical category tree
   * @returns {Promise<Array>} Tree structure with nested children
   * @example
   * const tree = await manager.buildCategoryTree();
   * // [{ id: 'cat_root', children: [{ id: 'cat_child', children: [] }] }]
   */
  async buildCategoryTree() {
    const categories = await this.getAllCategories();
    const categoriesArray = Object.values(categories);

    if (categoriesArray.length === 0) {
      return [];
    }

    // Get root categories (parentId is null)
    const roots = categoriesArray
      .filter(cat => !cat.parentId)
      .sort((a, b) => a.order - b.order);

    // Build tree recursively
    const buildChildren = (parentId) => {
      return categoriesArray
        .filter(cat => cat.parentId === parentId)
        .sort((a, b) => a.order - b.order)
        .map(cat => ({
          ...cat,
          children: buildChildren(cat.id)
        }));
    };

    return roots.map(root => ({
      ...root,
      children: buildChildren(root.id)
    }));
  }

  /**
   * Get category depth (0 = root, 1 = child)
   * @param {string} categoryId - Category ID
   * @returns {Promise<number|null>} Depth or null if not found
   * @example
   * const depth = await manager.getCategoryDepth('cat_child');  // 1
   */
  async getCategoryDepth(categoryId) {
    const categories = await this.getAllCategories();
    const category = categories[categoryId];

    if (!category) {
      return null;
    }

    if (!category.parentId) {
      return 0;  // Root category
    }

    let depth = 1;
    let currentId = category.parentId;

    while (currentId) {
      const parent = categories[currentId];
      if (!parent || !parent.parentId) {
        break;
      }
      depth++;
      currentId = parent.parentId;
    }

    return depth;
  }
}
