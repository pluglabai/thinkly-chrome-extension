'use strict';

import StorageManager from '../StorageManager.js';

/**
 * SyncQueue - Manages pending sync operations for offline-first sync
 * @class
 */
export default class SyncQueue {
  static STORAGE_KEY = 'syncQueue';

  constructor() {
    this.storage = new StorageManager();
  }

  /**
   * Add operation to sync queue
   * @param {string} type - 'clip' or 'category'
   * @param {string} operation - 'create', 'update', or 'delete'
   * @param {Object} data - The data to sync
   * @returns {Promise<void>}
   */
  async enqueue(type, operation, data) {
    const queue = await this.getQueue();

    // Check for duplicate operations on same item
    const existingIndex = queue.findIndex(
      item => item.type === type && item.data.id === data.id
    );

    if (existingIndex !== -1) {
      // Update existing operation
      const existing = queue[existingIndex];

      if (existing.operation === 'create' && operation === 'delete') {
        // Created then deleted - remove from queue entirely
        queue.splice(existingIndex, 1);
      } else if (existing.operation === 'create' && operation === 'update') {
        // Created then updated - keep as create with updated data
        queue[existingIndex].data = { ...existing.data, ...data };
        queue[existingIndex].timestamp = Date.now();
      } else {
        // Replace with new operation
        queue[existingIndex] = {
          type,
          operation,
          data,
          timestamp: Date.now(),
        };
      }
    } else {
      // Add new operation
      queue.push({
        type,
        operation,
        data,
        timestamp: Date.now(),
      });
    }

    await this._saveQueue(queue);
  }

  /**
   * Get all pending operations
   * @returns {Promise<Array>}
   */
  async getQueue() {
    const queue = await this.storage.get(SyncQueue.STORAGE_KEY);
    return queue || [];
  }

  /**
   * Get pending operations grouped by type
   * @returns {Promise<Object>} { clips: [], categories: [] }
   */
  async getGroupedOperations() {
    const queue = await this.getQueue();

    const clips = queue
      .filter(item => item.type === 'clip')
      .map(item => ({ operation: item.operation, data: item.data }));

    const categories = queue
      .filter(item => item.type === 'category')
      .map(item => ({ operation: item.operation, data: item.data }));

    return { clips, categories };
  }

  /**
   * Clear all pending operations
   * @returns {Promise<void>}
   */
  async clear() {
    await this._saveQueue([]);
  }

  /**
   * Remove specific item from queue by ID
   * @param {string} type
   * @param {string} id
   * @returns {Promise<void>}
   */
  async removeItem(type, id) {
    const queue = await this.getQueue();
    const filtered = queue.filter(
      item => !(item.type === type && item.data.id === id)
    );
    await this._saveQueue(filtered);
  }

  /**
   * Get queue size
   * @returns {Promise<number>}
   */
  async size() {
    const queue = await this.getQueue();
    return queue.length;
  }

  /**
   * Check if queue has pending operations
   * @returns {Promise<boolean>}
   */
  async hasPending() {
    const size = await this.size();
    return size > 0;
  }

  /**
   * Save queue to storage
   * @private
   * @param {Array} queue
   */
  async _saveQueue(queue) {
    await this.storage.set(SyncQueue.STORAGE_KEY, queue);
  }
}
