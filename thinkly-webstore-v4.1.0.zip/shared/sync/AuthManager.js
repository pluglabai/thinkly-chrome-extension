'use strict';

import StorageManager from '../StorageManager.js';
import { getApiUrl } from '../config.js';

/**
 * AuthManager - Manages authentication state for cloud sync
 * Uses chrome.identity.getAuthToken for Google OAuth (Chrome's built-in flow)
 * @class
 */
export default class AuthManager {
  static STORAGE_KEYS = {
    AUTH_STATE: 'authState',
    ACCESS_TOKEN: 'accessToken',
    USER: 'user',
  };

  constructor() {
    this.storage = new StorageManager();
  }

  /**
   * Sign in with Google using chrome.identity.getAuthToken
   * Uses manifest.json oauth2 configuration
   * @returns {Promise<Object>} User data and access token
   * @throws {Error} If sign in fails
   */
  async signIn() {
    try {
      // Get Google OAuth token using Chrome's built-in identity API
      const googleToken = await this._getGoogleToken();

      if (!googleToken) {
        throw new Error('Failed to get Google token');
      }

      // Get user info from Google using access token
      const userInfo = await this._getUserInfo(googleToken);

      if (!userInfo) {
        throw new Error('Failed to get user info');
      }

      // Exchange Google token for our API token
      const authResponse = await this._exchangeToken(googleToken, userInfo);

      // Store auth state
      await this._saveAuthState({
        isAuthenticated: true,
        accessToken: authResponse.accessToken,
        googleToken: googleToken,
        user: authResponse.user,
        lastLogin: Date.now(),
      });

      return authResponse;
    } catch (error) {
      console.error('[AuthManager] Sign in error:', error);
      throw error;
    }
  }

  /**
   * Sign out and clear auth state
   * @returns {Promise<void>}
   */
  async signOut() {
    try {
      const state = await this.getAuthState();
      
      // Revoke Chrome's cached token
      if (state?.googleToken) {
        await new Promise((resolve) => {
          chrome.identity.removeCachedAuthToken({ token: state.googleToken }, resolve);
        });
      }

      // Revoke token on Google's side (best-effort)
      if (state?.googleToken) {
        await fetch(`https://oauth2.googleapis.com/revoke?token=${state.googleToken}`, {
          method: 'POST',
        }).catch(() => {}); // best-effort
      }

      // Clear stored auth state
      await this.storage.remove(AuthManager.STORAGE_KEYS.AUTH_STATE);
    } catch (error) {
      console.error('[AuthManager] Sign out error:', error);
      throw error;
    }
  }

  /**
   * Get current auth state
   * @returns {Promise<Object|null>} Auth state or null if not authenticated
   */
  async getAuthState() {
    const state = await this.storage.get(AuthManager.STORAGE_KEYS.AUTH_STATE);
    return state;
  }

  /**
   * Check if user is authenticated
   * @returns {Promise<boolean>}
   */
  async isAuthenticated() {
    const state = await this.getAuthState();
    return state?.isAuthenticated === true && !!state?.accessToken;
  }

  /**
   * Get current access token
   * @returns {Promise<string|null>}
   */
  async getAccessToken() {
    const state = await this.getAuthState();
    return state?.accessToken || null;
  }

  /**
   * Get current user info
   * @returns {Promise<Object|null>}
   */
  async getUser() {
    const state = await this.getAuthState();
    return state?.user || null;
  }

  /**
   * Refresh access token
   * @returns {Promise<string>} New access token
   * @throws {Error} If refresh fails
   */
  async refreshToken() {
    const currentToken = await this.getAccessToken();

    if (!currentToken) {
      throw new Error('No token to refresh');
    }

    try {
      const response = await fetch(this._getApiUrl('/api/auth/refresh'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${currentToken}`,
        },
      });

      if (!response.ok) {
        // Token might be expired, try to re-authenticate
        if (response.status === 401) {
          return await this._reAuthenticate();
        }
        throw new Error('Failed to refresh token');
      }

      const data = await response.json();

      // Update stored token
      const state = await this.getAuthState();
      await this._saveAuthState({
        ...state,
        accessToken: data.accessToken,
      });

      return data.accessToken;
    } catch (error) {
      console.error('[AuthManager] Token refresh error:', error);
      throw error;
    }
  }

  /**
   * Get Google OAuth token using chrome.identity.getAuthToken
   * This uses the oauth2 configuration from manifest.json
   * @private
   * @returns {Promise<string>}
   */
  async _getGoogleToken() {
    return new Promise((resolve, reject) => {
      chrome.identity.getAuthToken({ interactive: true }, (token) => {
        if (chrome.runtime.lastError) {
          console.error('[AuthManager] getAuthToken error:', chrome.runtime.lastError);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (!token) {
          reject(new Error('No token received'));
          return;
        }

        console.log('[AuthManager] Got Google token successfully');
        resolve(token);
      });
    });
  }

  /**
   * Get user info from Google using access token
   * @private
   * @param {string} accessToken - Google OAuth access token
   * @returns {Promise<Object>} User info from Google
   */
  async _getUserInfo(accessToken) {
    const response = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to get user info from Google');
    }

    return response.json();
  }

  /**
   * Exchange Google token for our API token
   * @private
   * @param {string} googleToken - Google OAuth access token
   * @param {Object} userInfo - User info from Google
   * @returns {Promise<Object>}
   */
  async _exchangeToken(googleToken, userInfo) {
    const response = await fetch(this._getApiUrl('/api/auth/google'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        accessToken: googleToken,
        userInfo: userInfo
      }),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.error || 'Failed to authenticate');
    }

    return response.json();
  }

  /**
   * Re-authenticate with Google
   * @private
   * @returns {Promise<string>} New access token
   */
  async _reAuthenticate() {
    // Clear cached token first to force re-auth
    const state = await this.getAuthState();
    if (state?.googleToken) {
      await new Promise((resolve) => {
        chrome.identity.removeCachedAuthToken({ token: state.googleToken }, resolve);
      });
    }

    const googleToken = await this._getGoogleToken();

    if (!googleToken) {
      throw new Error('Failed to re-authenticate');
    }

    const userInfo = await this._getUserInfo(googleToken);

    if (!userInfo) {
      throw new Error('Failed to get user info');
    }

    const authResponse = await this._exchangeToken(googleToken, userInfo);

    await this._saveAuthState({
      isAuthenticated: true,
      accessToken: authResponse.accessToken,
      googleToken: googleToken,
      user: authResponse.user,
      lastLogin: Date.now(),
    });

    return authResponse.accessToken;
  }

  /**
   * Save auth state to storage
   * @private
   * @param {Object} state
   */
  async _saveAuthState(state) {
    await this.storage.set(AuthManager.STORAGE_KEYS.AUTH_STATE, state);
  }

  /**
   * Get API URL using centralized config
   * @private
   * @param {string} path
   * @returns {string}
   */
  _getApiUrl(path) {
    return getApiUrl(path);
  }
}
