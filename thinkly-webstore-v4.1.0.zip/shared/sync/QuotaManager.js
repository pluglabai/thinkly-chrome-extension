'use strict';

import { QUOTA_LIMITS } from '../constants.js';

/**
 * Manages user's cloud storage quota
 * @class
 */
export default class QuotaManager {
  /**
   * Create QuotaManager instance
   * @param {Object} apiClient - ApiClient instance for API calls
   */
  constructor(apiClient) {
    this.apiClient = apiClient;
    this.cache = null;
    this.cacheTime = null;
  }

  /**
   * Get user's cloud quota status
   * @returns {Promise<{used: number, limit: number, plan: string}>}
   * @throws {Error} If API call fails
   */
  async getQuotaStatus() {
    // Check cache
    if (this.cache && Date.now() - this.cacheTime < QUOTA_LIMITS.CACHE_DURATION_MS) {
      return this.cache;
    }

    // Fetch from API
    const quota = await this.apiClient.get('/api/quota');

    // Update cache
    this.cache = quota;
    this.cacheTime = Date.now();

    return quota;
  }

  /**
   * Check if user can add more clips to cloud
   * @returns {Promise<boolean>}
   */
  async canAddToCloud() {
    const quota = await this.getQuotaStatus();
    return quota.used < quota.limit;
  }

  /**
   * Get remaining clip count
   * @returns {Promise<number>}
   */
  async getRemainingClips() {
    const quota = await this.getQuotaStatus();
    const remaining = quota.limit - quota.used;
    return Math.max(0, remaining);
  }

  /**
   * Check if user is approaching limit (80% or more)
   * @returns {Promise<boolean>}
   */
  async isApproachingLimit() {
    const quota = await this.getQuotaStatus();
    return quota.used >= quota.limit * QUOTA_LIMITS.WARNING_THRESHOLD;
  }

  /**
   * Clear the quota cache
   */
  clearCache() {
    this.cache = null;
    this.cacheTime = null;
  }
}
