'use strict';

/**
 * ConflictResolver - Resolves sync conflicts using Last-Write-Wins strategy
 * @class
 */
export default class ConflictResolver {
  /**
   * Resolve conflict between local and remote data
   * Uses Last-Write-Wins based on updatedAt timestamp
   * @param {Object} local - Local data
   * @param {Object} remote - Remote data
   * @returns {Object} Winning data
   */
  resolve(local, remote) {
    if (!local) return { winner: 'remote', data: remote };
    if (!remote) return { winner: 'local', data: local };

    const localUpdated = local.updatedAt || 0;
    const remoteUpdated = remote.updatedAt || 0;

    if (remoteUpdated > localUpdated) {
      return { winner: 'remote', data: remote };
    } else {
      return { winner: 'local', data: local };
    }
  }

  /**
   * Merge remote changes into local data
   * @param {Array} localItems - Local items
   * @param {Array} remoteItems - Remote items
   * @param {string} idField - Field to use as ID (default: 'id')
   * @returns {Object} { merged, conflicts }
   */
  mergeArrays(localItems, remoteItems, idField = 'id') {
    const localMap = new Map(localItems.map(item => [item[idField], item]));
    const conflicts = [];
    const merged = [...localItems];

    for (const remoteItem of remoteItems) {
      const localItem = localMap.get(remoteItem[idField]);

      if (localItem) {
        // Item exists locally - resolve conflict
        const resolution = this.resolve(localItem, remoteItem);

        if (resolution.winner === 'remote') {
          // Update local with remote data
          const index = merged.findIndex(item => item[idField] === remoteItem[idField]);
          if (index !== -1) {
            merged[index] = remoteItem;
            conflicts.push({
              id: remoteItem[idField],
              winner: 'remote',
              local: localItem,
              remote: remoteItem,
            });
          }
        } else {
          // Keep local - log conflict
          conflicts.push({
            id: remoteItem[idField],
            winner: 'local',
            local: localItem,
            remote: remoteItem,
          });
        }
      } else {
        // New item from remote - add to merged
        merged.push(remoteItem);
      }
    }

    return { merged, conflicts };
  }

  /**
   * Handle deleted items
   * Items with deletedAt should be removed from active list
   * @param {Array} items
   * @returns {Object} { active, deleted }
   */
  separateDeleted(items) {
    const active = [];
    const deleted = [];

    for (const item of items) {
      if (item.deletedAt) {
        deleted.push(item);
      } else {
        active.push(item);
      }
    }

    return { active, deleted };
  }

  /**
   * Apply remote deletions to local data
   * @param {Array} localItems
   * @param {Array} remoteDeletedIds - IDs of items deleted remotely
   * @returns {Array} Filtered local items
   */
  applyDeletions(localItems, remoteDeletedIds) {
    const deletedSet = new Set(remoteDeletedIds);
    return localItems.filter(item => !deletedSet.has(item.id));
  }
}
