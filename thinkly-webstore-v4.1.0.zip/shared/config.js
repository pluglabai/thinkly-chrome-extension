'use strict';

/**
 * Configuration module for Thinkly API URLs
 * Centralizes API URL management with build-time injection support
 */

const DEFAULT_API_URL = 'https://thinkly.pluglab.ai';

/**
 * Get the API base URL
 * Uses THINKLY_API_URL global if defined (injected at build time), otherwise uses default
 * @returns {string} API base URL
 */
export function getApiBaseUrl() {
  if (typeof THINKLY_API_URL !== 'undefined' && THINKLY_API_URL) {
    return THINKLY_API_URL;
  }
  return DEFAULT_API_URL;
}

/**
 * Get full API URL for a given path
 * @param {string} path - API endpoint path (e.g., '/api/auth/google')
 * @returns {string} Full API URL
 */
export function getApiUrl(path = '') {
  const baseUrl = getApiBaseUrl();
  if (!path) return baseUrl;
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  return `${baseUrl}${normalizedPath}`;
}

/**
 * Check if the current configuration is production (HTTPS)
 * @param {string} url - URL to check (defaults to current API URL)
 * @returns {boolean} True if URL uses HTTPS
 */
export function isProduction(url = getApiBaseUrl()) {
  return url.startsWith('https://');
}

/**
 * API configuration constants
 */
export const API_CONFIG = {
  DEFAULT_URL: DEFAULT_API_URL,
  TIMEOUT_MS: 30000,
};

/**
 * Web paths configuration
 */
export const WEB_PATHS = {
  DASHBOARD: '/',  // Main dashboard is at root
  LOGIN: '/login',
};

/**
 * Get the web dashboard URL
 * @returns {string} Web dashboard URL
 */
export function getWebDashboardUrl() {
  return `${getApiBaseUrl()}${WEB_PATHS.DASHBOARD}`;
}
