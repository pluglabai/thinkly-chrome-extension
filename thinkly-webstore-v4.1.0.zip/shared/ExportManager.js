'use strict';

import { BRANDING } from './constants.js';

/**
 * ExportManager - Handles exporting clips to markdown files
 * @class
 * @example
 * const manager = new ExportManager();
 * await manager.exportToMarkdown(clips, { categoryName: 'Work' });
 */
export default class ExportManager {
  /**
   * Export clips to markdown file and trigger download
   * @param {Array} clips - Clips to export
   * @param {Object} options - Export options
   * @param {string} options.categoryName - Category name for title
   * @param {boolean} options.groupByCategory - Group clips by category sections
   * @param {Object} options.categories - Category objects (required if groupByCategory is true)
   * @returns {Promise<void>}
   * @example
   * await exportManager.exportToMarkdown(clips, { categoryName: 'Work Notes' });
   * @example
   * await exportManager.exportToMarkdown(clips, {
   *   categoryName: 'Grouped Export',
   *   groupByCategory: true,
   *   categories: allCategories
   * });
   */
  async exportToMarkdown(clips, options = {}) {
    const { groupByCategory = false, categories = {} } = options;

    const markdown = groupByCategory
      ? this.generateGroupedMarkdown(clips, categories, options)
      : this.generateMarkdown(clips, options);

    const filename = this.generateFilename(options.categoryName || 'export');
    await this.downloadFile(markdown, filename);
  }

  /**
   * Generate markdown content from clips
   * @param {Array} clips - Clips to export
   * @param {Object} options - Export options
   * @param {string} options.categoryName - Category name for title
   * @returns {string} Markdown content
   * @example
   * const markdown = exportManager.generateMarkdown(clips, { categoryName: 'Work' });
   */
  generateMarkdown(clips, options = {}) {
    const categoryName = options.categoryName || 'All Clips';
    const exportDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // Header
    let markdown = `# Thinkly Export: ${categoryName}\n\n`;
    markdown += `**Exported:** ${exportDate}\n`;
    markdown += `**Total Clips:** ${clips.length}\n\n`;
    markdown += `---\n\n`;

    // Clips
    clips.forEach((clip, index) => {
      // Title
      markdown += `## ${clip.icon} ${clip.title}\n\n`;

      // Metadata
      const sourceName = this._getSourceName(clip.source, clip.url);
      const savedDate = new Date(clip.createdAt).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });

      markdown += `**Source:** ${sourceName}\n`;
      markdown += `**URL:** ${clip.url}\n`;
      markdown += `**Saved:** ${savedDate}\n\n`;

      // Content
      markdown += `${clip.text}\n\n`;

      // Separator (except for last clip)
      if (index < clips.length - 1) {
        markdown += `---\n\n`;
      }
    });

    // Add branding footer
    markdown += this._getBrandingFooter();

    return markdown;
  }

  /**
   * Get branding footer for export
   * @private
   * @returns {string} Branding footer markdown
   */
  _getBrandingFooter() {
    return BRANDING.FOOTER;
  }

  /**
   * Get source name from clip source object
   * @private
   * @param {Object} source - Source object
   * @param {string} [url] - Clip URL fallback
   * @returns {string} Source name
   */
  _getSourceName(source, url) {
    if (source?.siteName) {
      return source.siteName;
    }

    // Fallback to platform mapping for backward compatibility
    const platformMap = {
      chatgpt: 'ChatGPT',
      claude: 'Claude',
      other: 'Other'
    };

    if (source?.platform && platformMap[source.platform]) {
      return platformMap[source.platform];
    }

    if (url) {
      try {
        return new URL(url).hostname;
      } catch {
        // Ignore invalid URL and fall through to generic label
      }
    }

    return 'Unknown';
  }

  /**
   * Group clips by category
   * @private
   * @param {Array} clips - Clips to group
   * @param {Object} categories - Category objects indexed by ID
   * @returns {Object} Grouped clips { categoryId: { category, clips: [] } }
   * @example
   * const grouped = this._groupClipsByCategory(clips, categories);
   * // Returns: { cat_work: { category: {...}, clips: [...] } }
   */
  _groupClipsByCategory(clips, categories) {
    const grouped = {};

    // Initialize groups for all categories
    Object.values(categories).forEach(cat => {
      grouped[cat.id] = { category: cat, clips: [] };
    });

    // Group clips by categoryId
    clips.forEach(clip => {
      if (grouped[clip.categoryId]) {
        grouped[clip.categoryId].clips.push(clip);
      }
    });

    return grouped;
  }

  /**
   * Generate grouped markdown with category sections
   * @param {Array} clips - Clips to export
   * @param {Object} categories - Category objects indexed by ID
   * @param {Object} options - Export options
   * @param {string} options.categoryName - Category name for title
   * @returns {string} Markdown content with category sections
   * @example
   * const markdown = exportManager.generateGroupedMarkdown(clips, categories, {
   *   categoryName: 'Grouped Export'
   * });
   */
  generateGroupedMarkdown(clips, categories, options = {}) {
    const categoryName = options.categoryName || 'Grouped Export';
    const exportDate = new Date().toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    // Header
    let markdown = `# Thinkly Export: ${categoryName}\n\n`;
    markdown += `**Exported:** ${exportDate}\n`;
    markdown += `**Total Clips:** ${clips.length}\n\n`;
    markdown += `---\n\n`;

    // Group clips by category
    const grouped = this._groupClipsByCategory(clips, categories);

    // Sort categories by order
    const sortedCategories = Object.values(grouped)
      .filter(g => g.clips.length > 0)
      .sort((a, b) => a.category.order - b.category.order);

    // Generate sections for each category
    sortedCategories.forEach((group, catIndex) => {
      const { category, clips: categoryClips } = group;

      // Category header
      const clipCount = categoryClips.length;
      const clipWord = clipCount === 1 ? 'clip' : 'clips';
      markdown += `## ${category.icon} ${category.name} (${clipCount} ${clipWord})\n\n`;

      // Clips in this category
      categoryClips.forEach((clip, clipIndex) => {
        markdown += `### ${clip.icon} ${clip.title}\n\n`;

        const sourceName = this._getSourceName(clip.source, clip.url);
        const savedDate = new Date(clip.createdAt).toLocaleDateString('en-US', {
          year: 'numeric',
          month: 'short',
          day: 'numeric'
        });

        markdown += `**Source:** ${sourceName}\n`;
        markdown += `**URL:** ${clip.url}\n`;
        markdown += `**Saved:** ${savedDate}\n\n`;
        markdown += `${clip.text}\n\n`;

        // Separator between clips (not after last clip in category)
        if (clipIndex < categoryClips.length - 1) {
          markdown += `---\n\n`;
        }
      });

      // Separator between categories (not after last category)
      if (catIndex < sortedCategories.length - 1) {
        markdown += `\n---\n\n`;
      }
    });

    // Add branding footer
    markdown += this._getBrandingFooter();

    return markdown;
  }

  /**
   * Generate filename for export
   * @param {string} [categoryName='all-clips'] - Category name
   * @returns {string} Filename like "thinkly-work-notes-2026-01-17.md"
   * @example
   * exportManager.generateFilename('Work Notes') // "thinkly-work-notes-2026-01-17.md"
   */
  generateFilename(categoryName = 'all-clips') {
    const date = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    const safeName = (categoryName || 'all-clips')
      .toLowerCase()
      .trim()
      .replace(/\s+/g, '-')  // Replace spaces with dashes
      .replace(/[^a-z0-9-]/g, '-');  // Replace special chars with dashes

    return `thinkly-${safeName}-${date}.md`;
  }

  /**
   * Download markdown content as file
   * @param {string} content - Markdown content
   * @param {string} filename - Filename for download
   * @returns {Promise<void>}
   * @example
   * await exportManager.downloadFile(markdown, 'export.md');
   */
  async downloadFile(content, filename) {
    // Create blob
    const blob = new Blob([content], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);

    // Trigger download via chrome.downloads API
    await chrome.downloads.download({
      url,
      filename,
      saveAs: true
    });

    // Clean up object URL after a delay
    setTimeout(() => {
      URL.revokeObjectURL(url);
    }, 1000);
  }
}
