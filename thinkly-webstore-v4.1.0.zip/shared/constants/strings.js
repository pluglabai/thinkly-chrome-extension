'use strict';

/**
 * UI Strings
 * 모든 UI 텍스트를 한 곳에서 관리
 */

export const STRINGS = {
  // App
  appName: 'Thinkly',
  appLogo: '✨',
  
  // Search
  searchPlaceholder: '클립 검색...',
  
  // Empty State
  emptyTitle: '클립이 없습니다',
  emptyDesc: 'ChatGPT나 Claude에서 텍스트를 선택하고\nCmd+Shift+S를 눌러 저장하세요',
  emptyIcon: '📝',
  
  // Dashboard
  dashboardLink: '대시보드에서 전체 보기',
  dashboardIcon: '🖥️',
  
  // Panel Titles
  urlPanelTitle: '🔗 URL 추가',
  filePanelTitle: '📁 파일 업로드',
  textPanelTitle: '📝 텍스트 입력',
  
  // Panel Placeholders
  urlPlaceholder: 'URL을 입력하세요...',
  titlePlaceholder: '제목 (선택사항)',
  contentPlaceholder: '내용을 입력하세요...',
  dropzoneText: '파일을 드래그하거나 클릭',
  dropzoneIcon: '📁',
  
  // Buttons
  addBtn: '추가',
  uploadBtn: '업로드',
  saveBtn: '저장',
  copyBtn: '📋 복사',
  deleteBtn: '🗑️ 삭제',
  copiedBtn: '✓ 복사됨',
  
  // Category
  categorySelectDefault: '📂 카테고리 선택',
  
  // Time
  timeJustNow: '방금 전',
  timeMinutesAgo: '분 전',
  timeHoursAgo: '시간 전',
  timeYesterday: '어제',
  timeDaysAgo: '일 전',
  timeWeeksAgo: '주 전',
  
  // Errors
  errorUrlRequired: 'URL을 입력하세요',
  errorUrlInvalid: '유효한 URL을 입력하세요',
  errorContentRequired: '내용을 입력하세요',
  errorFileType: '지원 형식: .txt, .md, .json',
  errorAddFailed: '추가 실패',
  errorUploadFailed: '업로드 실패',
  errorSaveFailed: '저장 실패',
  
  // Confirmations
  confirmDelete: '이 클립을 삭제하시겠습니까?',
};

/**
 * Get localized string
 * @param {string} key
 * @param {Object} params - Optional parameters for interpolation
 * @returns {string}
 */
export function getString(key, params = {}) {
  let str = STRINGS[key] || key;
  
  // Simple interpolation: replace {param} with value
  Object.entries(params).forEach(([param, value]) => {
    str = str.replace(`{${param}}`, value);
  });
  
  return str;
}

export default {
  STRINGS,
  getString,
};
