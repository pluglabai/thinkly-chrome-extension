'use strict';

/**
 * Category Constants
 * 기본 카테고리 정의
 */

export const DEFAULT_CATEGORIES = {
  all: {
    id: '',
    name: '전체',
    icon: '📚',
    order: 0,
  },
  work: {
    id: 'cat_work',
    name: 'Work',
    icon: '💼',
    order: 1,
  },
  personal: {
    id: 'cat_personal',
    name: 'Personal',
    icon: '🧠',
    order: 2,
  },
  ideas: {
    id: 'cat_ideas',
    name: 'Ideas',
    icon: '💡',
    order: 3,
  },
};

/**
 * Get category by ID
 * @param {string} categoryId
 * @returns {Object|null}
 */
export function getCategoryById(categoryId) {
  return Object.values(DEFAULT_CATEGORIES).find(cat => cat.id === categoryId) || null;
}

/**
 * Get sorted categories for display
 * @returns {Array}
 */
export function getSortedCategories() {
  return Object.values(DEFAULT_CATEGORIES).sort((a, b) => a.order - b.order);
}

export default {
  DEFAULT_CATEGORIES,
  getCategoryById,
  getSortedCategories,
};
