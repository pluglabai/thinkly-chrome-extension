'use strict';

/**
 * Theme Constants
 * 프로토타입 기준 스타일 상수
 * Reference: prototypes/upload-ui-preview.html
 */

export const COLORS = {
  // Background
  bgPrimary: '#0f0f14',
  bgHeader: '#15151c',
  bgCard: '#1a1a24',
  bgCardHover: '#1f1f2c',
  bgInput: '#1f1f2c',
  bgPill: '#1f1f2c',
  bgPillHover: 'rgba(255, 255, 255, 0.08)',

  // Accent
  accentPrimary: '#818cf8',
  accentSecondary: '#6366f1',
  accentLight: '#818cf8',
  accentBg: 'rgba(129, 140, 248, 0.08)',
  accentBgActive: 'rgba(129, 140, 248, 0.12)',
  accentBorder: 'rgba(129, 140, 248, 0.15)',

  // Text
  textPrimary: '#e8e8f0',
  textSecondary: '#a0a0b0',
  textMuted: '#555566',
  textPlaceholder: '#3a3a48',

  // Border
  borderLight: 'rgba(255, 255, 255, 0.04)',
  borderMedium: 'rgba(255, 255, 255, 0.06)',
  borderInput: 'rgba(255, 255, 255, 0.08)',
};

export const SIZES = {
  // Popup
  popupWidth: 380,
  popupHeight: 520,

  // Logo
  logoSize: 32,
  logoRadius: 8,
  logoFontSize: 16,

  // Header
  headerPadding: '16px 20px',
  titleFontSize: 16,
  settingsSize: 28,
  settingsRadius: 6,

  // Pills
  pillFontSize: 12,
  pillPaddingV: 8,
  pillPaddingH: 14,
  pillRadius: 20,
  pillGap: 8,
  pillsContainerPadding: '12px 16px',

  // Search
  searchFontSize: 13,
  searchPaddingV: 10,
  searchPaddingH: 14,
  searchPaddingLeft: 36,
  searchRadius: 10,
  searchIconSize: 16,
  searchContainerPadding: '12px 16px',

  // Clip
  clipIconSize: 36,
  clipIconRadius: 10,
  clipIconFontSize: 16,
  clipTitleSize: 14,
  clipPreviewSize: 12,
  clipTagSize: 10,
  clipTimeSize: 10,
  clipPadding: 14,
  clipRadius: 12,
  clipGap: 12,
  clipMarginBottom: 10,
  clipsListPadding: '8px 16px 16px',
  clipsListMaxHeight: 320,

  // FAB
  fabSize: 56,
  fabRadius: 16,
  fabFontSize: 28,
  fabBottom: 20,
  fabRight: 20,

  // FAB Menu
  fabMenuGap: 12,
  fabOptionPadding: '12px 16px',
  fabOptionRadius: 12,
  fabOptionIconSize: 36,
  fabOptionIconRadius: 10,
  fabOptionFontSize: 14,

  // Dashboard Link
  dashboardLinkPadding: 12,
  dashboardLinkFontSize: 12,
  dashboardLinkGap: 6,
};

export const SHADOWS = {
  fab: '0 8px 24px rgba(129, 140, 248, 0.4)',
  fabHover: '0 12px 32px rgba(129, 140, 248, 0.5)',
  popup: '0 20px 60px rgba(0, 0, 0, 0.5)',
};

export const GRADIENTS = {
  accent: 'linear-gradient(135deg, #818cf8 0%, #6366f1 100%)',
};

export const TRANSITIONS = {
  fast: '0.2s ease',
  normal: '0.3s ease',
};

export const SEARCH_ICON_SVG = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='%23555566' viewBox='0 0 24 24'%3E%3Cpath d='M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' stroke='%23555566' stroke-width='2' fill='none'/%3E%3C/svg%3E")`;

export default {
  COLORS,
  SIZES,
  SHADOWS,
  GRADIENTS,
  TRANSITIONS,
  SEARCH_ICON_SVG,
};
