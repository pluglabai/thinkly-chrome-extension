# Thinkly Icons

This directory contains icon files for the Thinkly Chrome Extension.

## Required Sizes
- icon16.png (16×16px) - Extension toolbar
- icon48.png (48×48px) - Extension management page
- icon128.png (128×128px) - Chrome Web Store

## Temporary Placeholder
For development, you can use simple emoji-based icons or generate proper PNG files using:
1. Figma/Sketch
2. GIMP/Photoshop
3. Online icon generators

## Design Guidelines
- Primary color: #6366f1 (indigo)
- Background: Dark (#1a1a1a) or transparent
- Symbol: Light bulb (💡) or brain (🧠)
- Style: Modern, minimal, flat design

## TODO
- [ ] Create icon16.png
- [ ] Create icon48.png
- [ ] Create icon128.png
- [ ] Test icons in Chrome
