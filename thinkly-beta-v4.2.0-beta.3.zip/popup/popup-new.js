'use strict';

import ClipManager from '../shared/ClipManager.js';
import CategoryManager from '../shared/CategoryManager.js';
import ExportManager from '../shared/ExportManager.js';
import { getRelativeTime, escapeHTML } from '../shared/utils.js';
import { AuthManager, SyncManager, QuotaManager } from '../shared/sync/index.js';
import { getWebDashboardUrl, getApiBaseUrl } from '../shared/config.js';
import {
  getCaptureV2Settings,
  isCaptureV2Ready,
  markCaptureV2OnboardingCompleted,
  updateCaptureV2GlobalPreference,
  updateCaptureV2PlatformPreference
} from '../shared/capture-v2-settings.js';
import { serializeSyncClip } from '../shared/sync/sync-payload.js';

// MVP Feature Flags (can be overridden by build-time env)
const MVP_AUTO_SYNC_ENABLED = typeof THINKLY_AUTO_SYNC !== 'undefined' ? THINKLY_AUTO_SYNC : false;
const MVP_PULL_ENABLED = typeof THINKLY_PULL_ENABLED !== 'undefined' ? THINKLY_PULL_ENABLED : false;
import FAB from './components/FAB.js';
import { buildCategoryPillsHTML } from './components/CategoryPills.js';
import SelectionBar from './components/SelectionBar.js';
import { showPopupAlert, showPopupConfirm } from './popup-dialog.js';
import { applyPopupNewCopy, POPUP_NEW_COPY } from './popup-copy.js';
import {
  readPopupAutoSyncPreference,
  shouldRunPopupAutoSync,
  writePopupAutoSyncPreference
} from './popup-auto-sync.js';
import { moveClipToCategory } from './popup-clip-actions.js';
import {
  getCategoryDisplay,
  getRootCategoryOptions,
  toCategoryOptionValue,
  toStoredCategoryId
} from '../shared/category-display.js';
import {
  hidePopupMainContent,
  setSelectionModeAuxiliaryVisibility,
  showPopupMainContent
} from './popup-view-state.js';
import { subscribePopupStorageSync } from './popup-storage-sync.js';
import { performAuthenticatedSync } from './sync-actions.js';

// Initialize managers
const clipManager = new ClipManager();
const categoryManager = new CategoryManager();
const exportManager = new ExportManager();
const authManager = new AuthManager();
const syncManager = new SyncManager();
const quotaManager = new QuotaManager(syncManager.apiClient);

// State
let allClips = [];
let allCategories = {};
let currentCategoryId = null;
let currentSearchQuery = '';
let currentClip = null;
let fab = null;
let selectedFile = null;
let isAuthenticated = false;
let currentUser = null;
let captureV2Settings = null;
let currentPopupTab = 'feed';

// Selection Mode State (for export)
let isSelectionMode = false;
const selectedClipIds = new Set();
let selectionBar = null;
let unsubscribeStorageSync = null;

function updateVersionLabel() {
  const versionElement = document.getElementById('settings-version');
  if (!versionElement) return;

  const version = chrome?.runtime?.getManifest?.().version;
  versionElement.textContent = version ? `Thinkly v${version}` : 'Thinkly';
}

function openDashboard() {
  window.open(getWebDashboardUrl(), '_blank');
}

async function openSidePanel() {
  if (!chrome?.sidePanel?.open) {
    showToast('Side panel is available in recent Chrome versions.', 'info');
    return;
  }

  try {
    const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const windowId = activeTab?.windowId;

    if (typeof windowId === 'number') {
      await chrome.sidePanel.open({ windowId });
    } else {
      await chrome.sidePanel.open({});
    }

    showToast('Pinned in side panel');
  } catch (error) {
    console.error('[Thinkly] Side panel open failed:', error);
    showToast('Unable to open side panel', 'error');
  }
}

function ensureDashboardLink() {
  let container = document.querySelector('.dashboard-link-container');
  if (container) {
    return container;
  }

  const popupContainer = document.querySelector('.container');
  const fabContainer = document.getElementById('fab-container');
  if (!popupContainer || !fabContainer) {
    return null;
  }

  container = document.createElement('div');
  container.className = 'dashboard-link-container';
  container.innerHTML = `
    <button id="dashboard-link-btn" class="dashboard-link-btn" title="Open Dashboard">
      <span class="dashboard-link-text">Open Dashboard</span>
    </button>
  `;
  popupContainer.insertBefore(container, fabContainer);
  return container;
}


/**
 * Get unsent clips for sending
 */
async function getUnsentClips() {
  const clips = await clipManager.getAllClips();
  return clips.filter(clip => clip.syncStatus !== 'sent');
}

/**
 * Update Send bar visibility and count
 */
async function updateSendBar() {
  const bar = document.getElementById('send-bar');
  if (!bar) return;

  if (!isAuthenticated) {
    bar.style.display = 'none';
    return;
  }

  const unsent = await getUnsentClips();
  if (unsent.length === 0) {
    bar.style.display = 'none';
    return;
  }

  document.getElementById('unsent-count').textContent = unsent.length;
  const btn = document.getElementById('send-all-btn');
  btn.textContent = 'Send All';
  btn.disabled = false;
  bar.style.display = 'flex';
}

/**
 * Handle Send All button click
 */
async function handleSendAll() {
  await sendAllIfNeeded();
}

async function sendAllIfNeeded(options = {}) {
  const { silentIfEmpty = false, silentSuccess = false } = options;
  const sendAllBtn = document.getElementById('send-all-btn');
  
  // Check auth first - never silently skip
  if (!isAuthenticated) {
    showToast('Login required to send to Web', 'error');
    return { sent: 0, skipped: true, reason: 'not_authenticated' };
  }
  
  const unsentClips = await getUnsentClips();
  if (unsentClips.length === 0) {
    if (!silentIfEmpty) {
      showToast('No clips to send', 'info');
    }
    return { sent: 0, skipped: true, reason: 'no_unsent_clips' };
  }
  
  try {
    if (sendAllBtn) {
      sendAllBtn.disabled = true;
      sendAllBtn.textContent = 'Sending...';
    }
    
    // Get API URL
    const baseUrl = getApiBaseUrl();
    const endpoint = `${baseUrl}/api/sync/push`;
    
    // Prepare payload (clips only, no tags - server generates them)
    const payload = {
      clips: unsentClips.map(clip => ({
        operation: 'create',
        data: transformClipForSend(clip)
      })),
      categories: []
    };
    
    console.log(`[Thinkly] POST ${endpoint}`);
    console.log(`[Thinkly] Sending ${payload.clips.length} clips`);
    
    // Get auth token
    const token = await authManager.getAccessToken();
    if (!token) {
      showToast('Login required to send to Web', 'error');
      return;
    }
    
    // Make request
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
    
    const responseBody = await response.json().catch(() => ({}));
    console.log(`[Thinkly] Response: ${response.status}`, responseBody);
    
    // Handle auth errors explicitly
    if (response.status === 401 || response.status === 403) {
      showToast('Login required to send to Web', 'error');
      return;
    }
    
    if (!response.ok) {
      if (responseBody.details) {
        console.error('[Thinkly] Send All validation details:', responseBody.details);
      }

      const message = responseBody.error === 'Invalid sync data'
        ? 'Sync data format issue. Please refresh and try again.'
        : responseBody.error || `Server error: ${response.status}`;
      throw new Error(message);
    }
    
    // Success: log full server response for debugging
    console.log('[Thinkly] Send All success:', JSON.stringify(responseBody, null, 2));

    // Mark clips as sent
    for (const clip of unsentClips) {
      await clipManager.updateClip(
        clip.id,
        {
          syncStatus: 'sent',
          sentToWebAt: Date.now()
        },
        {
          validate: false,
          sync: false
        }
      );
    }
    
    if (!silentSuccess) {
      showToast(`Sent ${unsentClips.length} clips to Web`, 'success');
    }
    
    // Update UI
    await loadData();
    renderCategoryPills();
    updatePanelCategories();
    renderClips();
    return { sent: unsentClips.length, skipped: false };
    
  } catch (error) {
    console.error('[Thinkly] Send All error:', error);
    showToast(`Send failed: ${error.message}`, 'error');
    return { sent: 0, skipped: true, reason: 'send_failed', error };
  } finally {
    await updateSendBar();
  }
}

async function runFullSyncFlow(options = {}) {
  const { silentSendAll = true } = options;

  return performAuthenticatedSync({
    sendAll: () => sendAllIfNeeded({
      silentIfEmpty: true,
      silentSuccess: silentSendAll
    }),
    syncManager,
    loadData,
    renderCategoryPills,
    renderClips,
    updatePanelCategories,
    updateSendBar
  });
}

/**
 * Transform clip data for API (exclude tags - server generates them)
 */
function transformClipForSend(clip) {
  return {
    ...serializeSyncClip(clip, { includeDeletedAt: false }),
    tags: []
  };
}

/**
 * Initialize app
 */
async function init() {
  console.log('[Thinkly] Popup initialized (new UI)');
  applyPopupNewCopy(document);

  try {
    updateVersionLabel();
    ensureDashboardLink();
    await loadCaptureSettings();

    // Check auth state
    await checkAuthState();

    // Connect managers
    clipManager.setSyncManager(syncManager);
    clipManager.setQuotaManager(quotaManager);
    categoryManager.setSyncManager(syncManager);

    // Load data
    await loadData();

    // Render UI
    renderCategoryPills();
    renderClips();
    renderStats();
    renderCaptureSettings();
    updateCaptureBanner();

    // Initialize FAB
    initFAB();

    // Setup event listeners
    setupEventListeners();
    setupStorageSync();
    switchTab(currentPopupTab);

    // Send bar
    await updateSendBar();
    document.getElementById('send-all-btn')
      ?.addEventListener('click', handleSendAll);

    await maybeRunPopupAutoSync();

  } catch (error) {
    console.error('[Thinkly] Error initializing:', error);
  }
}

async function loadCaptureSettings() {
  captureV2Settings = await getCaptureV2Settings(chrome.storage.local);
  currentPopupTab = captureV2Settings.lastPopupTab || 'feed';
}

function setupStorageSync() {
  if (unsubscribeStorageSync) {
    unsubscribeStorageSync();
  }

  let refreshScheduled = false;
  unsubscribeStorageSync = subscribePopupStorageSync(chrome, async () => {
    if (refreshScheduled) {
      return;
    }

    refreshScheduled = true;

    queueMicrotask(async () => {
      try {
        await loadData();
        renderCategoryPills();
        renderClips();
        renderStats();
        renderCaptureSettings();
        updateCaptureBanner();
        updatePanelCategories();
        updateSelectionBar();
      } finally {
        refreshScheduled = false;
      }
    });
  });
}

async function maybeRunPopupAutoSync() {
  try {
    const autoSyncEnabled = await readPopupAutoSyncPreference(chrome.storage.local);

    if (!shouldRunPopupAutoSync({ isAuthenticated, autoSyncEnabled })) {
      return;
    }

    await runFullSyncFlow({ silentSendAll: true });
  } catch (error) {
    console.error('[Thinkly] Auto sync on popup open failed:', error);
  }
}

/**
 * Check auth state
 */
async function checkAuthState() {
  try {
    const authState = await authManager.getAuthState();
    isAuthenticated = authState?.isAuthenticated === true;
    currentUser = authState?.user || null;
    updateAuthUI();
  } catch (error) {
    console.error('[Thinkly] Auth error:', error);
    isAuthenticated = false;
    currentUser = null;
  }
}

/**
 * Update auth UI
 */
function updateAuthUI() {
  const loginBtn = document.getElementById('login-btn');
  const userInfo = document.getElementById('user-info');
  const userAvatar = document.getElementById('user-avatar');

  if (isAuthenticated && currentUser) {
    // 로그인 상태
    if (loginBtn) loginBtn.style.display = 'none';
    if (userInfo) userInfo.style.display = 'flex';

    // 아바타 설정
    if (userAvatar && currentUser.avatarUrl) {
      userAvatar.src = currentUser.avatarUrl;
      userAvatar.alt = currentUser.name || currentUser.email || 'User';
    } else if (userAvatar) {
      const initial = (currentUser.name || currentUser.email || '?')[0].toUpperCase();
      userAvatar.src = createAvatarDataUri(initial);
    }
  } else {
    // 로그아웃 상태
    if (loginBtn) loginBtn.style.display = 'flex';
    if (userInfo) userInfo.style.display = 'none';
  }
}

/**
 * 아바타 이니셜 이미지 생성
 */
function createAvatarDataUri(initial) {
  const canvas = document.createElement('canvas');
  canvas.width = 32;
  canvas.height = 32;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#4a4740';
  ctx.fillRect(0, 0, 32, 32);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 16px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(initial, 16, 16);
  return canvas.toDataURL();
}

/**
 * Load data
 */
async function loadData() {
  allClips = await clipManager.getAllClips();
  allCategories = await categoryManager.getAllCategories();

  // Sort clips by createdAt (newest first)
  allClips.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
}

function switchTab(tabName) {
  currentPopupTab = tabName;

  document.querySelectorAll('[data-popup-tab]').forEach((button) => {
    button.classList.toggle('active', button.dataset.popupTab === tabName);
  });

  document.querySelectorAll('[data-popup-panel]').forEach((panel) => {
    panel.hidden = panel.dataset.popupPanel !== tabName;
  });

  const feedAuxVisible = tabName === 'feed' && !isSelectionMode;
  const categoryPills = document.getElementById('category-pills');
  const searchContainer = document.querySelector('.search-container');
  const dashboardLink = document.querySelector('.dashboard-link-container');
  const fabContainer = document.getElementById('fab-container');

  if (categoryPills) categoryPills.style.display = feedAuxVisible ? 'flex' : 'none';
  if (searchContainer) searchContainer.style.display = tabName === 'feed' ? 'block' : 'none';
  if (dashboardLink) dashboardLink.style.display = feedAuxVisible ? 'flex' : 'none';
  if (fabContainer) fabContainer.style.display = feedAuxVisible ? 'block' : 'none';

  chrome.storage.local.get(['settings']).then((result) => {
    const settings = result?.settings || {};
    chrome.storage.local.set({
      settings: {
        ...settings,
        captureV2: {
          ...(captureV2Settings || {}),
          lastPopupTab: tabName
        }
      }
    });
  }).catch((error) => {
    console.error('[Thinkly] Failed to persist popup tab:', error);
  });
}

function renderStats() {
  const totalCaptured = document.getElementById('stats-total-captured');
  const localCaptured = document.getElementById('stats-local-captured');
  const syncedCaptured = document.getElementById('stats-synced-captured');
  const weeklyBars = document.getElementById('stats-weekly-bars');
  const breakdown = document.getElementById('stats-platform-breakdown');

  const localCount = allClips.filter((clip) => clip.syncStatus !== 'synced').length;
  const syncedCount = allClips.length - localCount;

  if (totalCaptured) totalCaptured.textContent = String(allClips.length);
  if (localCaptured) localCaptured.textContent = String(localCount);
  if (syncedCaptured) syncedCaptured.textContent = String(syncedCount);

  const last7Days = new Array(7).fill(0).map((_, index) => {
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    dayStart.setDate(dayStart.getDate() - (6 - index));
    const start = dayStart.getTime();
    const end = start + (24 * 60 * 60 * 1000);
    return {
      label: ['M', 'T', 'W', 'T', 'F', 'S', 'S'][index],
      count: allClips.filter((clip) => clip.createdAt >= start && clip.createdAt < end).length
    };
  });

  if (weeklyBars) {
    const maxCount = Math.max(...last7Days.map((entry) => entry.count), 1);
    weeklyBars.innerHTML = last7Days.map((entry) => {
      const height = Math.max(12, Math.round((entry.count / maxCount) * 100));
      return `
        <div class="bar-col">
          <div class="bar" style="height:${height}%"></div>
          <div class="bar-label">${entry.label}</div>
        </div>
      `;
    }).join('');
  }

  if (breakdown) {
    const platforms = ['chatgpt', 'claude', 'gemini', 'other'];
    const labels = {
      chatgpt: 'ChatGPT',
      claude: 'Claude',
      gemini: 'Gemini',
      other: 'Other'
    };
    breakdown.innerHTML = platforms.map((platform) => {
      const count = allClips.filter((clip) => clip.source?.platform === platform).length;
      return `
        <div class="seg-legend-item">
          <span class="seg-dot seg-dot-${platform}"></span>
          <span>${labels[platform]} · ${count}</span>
        </div>
      `;
    }).join('');
  }
}

function renderCaptureSettings() {
  const autoCaptureToggle = document.getElementById('settings-auto-capture');
  if (autoCaptureToggle) {
    autoCaptureToggle.checked = captureV2Settings?.globalEnabled !== false;
  }

  ['chatgpt', 'claude', 'gemini'].forEach((platform) => {
    const toggle = document.getElementById(`settings-platform-${platform}`);
    if (toggle) {
      toggle.checked = captureV2Settings?.platforms?.[platform] !== false;
    }
  });
}

function updateCaptureBanner() {
  const banner = document.getElementById('capture-ready-banner');
  if (!banner) return;

  const ready = isCaptureV2Ready(captureV2Settings);
  banner.hidden = ready;
}

/**
 * Render category pills
 */
function renderCategoryPills() {
  const container = document.getElementById('category-pills');
  if (!container) return;

  container.innerHTML = buildCategoryPillsHTML(allCategories, currentCategoryId);

  // Bind click events
  container.querySelectorAll('.category-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      currentCategoryId = pill.dataset.categoryId || null;
      renderCategoryPills();
      renderClips();
    });
  });
}

/**
 * Render clips list
 */
function renderClips() {
  const container = document.getElementById('clips-list');
  const emptyState = document.getElementById('empty-state');
  if (!container) return;

  // Filter clips
  const filteredClips = getFilteredClips();

  // Show/hide empty state
  if (filteredClips.length === 0) {
    container.style.display = 'none';
    emptyState.style.display = 'flex';
    return;
  }

  container.style.display = 'block';
  emptyState.style.display = 'none';

  // Build HTML
  let html = '';
  for (const clip of filteredClips) {
    const category = getCategoryDisplay(clip.categoryId, allCategories);
    const categoryTag = category
      ? `<span class="clip-category-tag">${escapeHTML(category.icon || '📁')} ${escapeHTML(category.name)}</span>`
      : '';

    const isSelected = selectedClipIds.has(clip.id);
    const selectionModeClass = isSelectionMode ? ' selection-mode' : '';
    const selectedClass = isSelected ? ' selected' : '';
    const checkboxHTML = isSelectionMode 
      ? `<div class="clip-checkbox${isSelected ? ' checked' : ''}">✓</div>` 
      : '';

    html += `
      <div class="clip-item${selectionModeClass}${selectedClass}" data-clip-id="${clip.id}">
        ${checkboxHTML}
        <div class="clip-icon">${escapeHTML(clip.icon || '💡')}</div>
        <div class="clip-content">
          <div class="clip-title">${escapeHTML(clip.title || 'Untitled')}</div>
          <div class="clip-preview">${escapeHTML((clip.text || '').substring(0, 100))}</div>
          <div class="clip-meta">
            ${categoryTag}
            <span class="clip-time">${getRelativeTime(clip.createdAt)}</span>
          </div>
        </div>
      </div>
    `;
  }

  container.innerHTML = html;

  // Refresh send bar count
  updateSendBar();
}

/**
 * Initialize FAB
 */
function initFAB() {
  fab = new FAB('#fab-container');
  fab.setOnOptionSelect(handleFABOption);
}

/**
 * Handle FAB option selection
 */
function handleFABOption(type) {
  openPanel(type);
}

/**
 * Open add panel
 */
function openPanel(type) {
  updatePanelCategories();

  document.getElementById('panel-overlay').classList.add('show');
  const panel = document.getElementById(`${type}-panel`);
  panel.classList.add('show');

  // Focus first input
  const input = panel.querySelector('input[type="text"], textarea');
  if (input && !panel.contains(document.activeElement)) {
    input.focus();
  }
}

/**
 * Close add panel
 */
function closePanel() {
  document.getElementById('panel-overlay').classList.remove('show');
  document.querySelectorAll('.add-panel').forEach(p => p.classList.remove('show'));

  // Reset inputs
  document.getElementById('url-input').value = '';
  document.getElementById('text-title').value = '';
  document.getElementById('text-content').value = '';
  document.getElementById('file-info').style.display = 'none';
  document.getElementById('file-add-btn').disabled = true;
  selectedFile = null;
}

/**
 * Update category options in panels
 */
function updatePanelCategories() {
  const options = getRootCategoryOptions(allCategories)
    .map(cat => {
      const optionValue = toCategoryOptionValue(cat.id);
      return `<option value="${optionValue}">${escapeHTML(cat.icon || '📁')} ${escapeHTML(cat.name)}</option>`;
    })
    .join('');

  document.getElementById('url-category').innerHTML = options;
  document.getElementById('file-category').innerHTML = options;
  document.getElementById('text-category').innerHTML = options;
}

/**
 * Handle login
 */
async function handleLogin() {
  const loginBtn = document.getElementById('login-btn');
  try {
    if (loginBtn) loginBtn.disabled = true;
    const response = await chrome.runtime.sendMessage({ type: 'SIGN_IN' });
    if (!response.success) throw new Error(response.error || 'Sign in failed');
    
    isAuthenticated = true;
    currentUser = response.result.user;
    updateAuthUI();
    await runFullSyncFlow({ silentSendAll: true });
    showToast('Signed in and synced!');
  } catch (error) {
    console.error('[Thinkly] Login error:', error);
    showToast('Sign in failed: ' + error.message, true);
  } finally {
    if (loginBtn) loginBtn.disabled = false;
  }
}

/**
 * Handle logout
 */
async function handleLogout() {
  try {
    const response = await chrome.runtime.sendMessage({ type: 'SIGN_OUT' });
    if (!response.success) throw new Error(response.error || 'Sign out failed');
    
    isAuthenticated = false;
    currentUser = null;
    updateAuthUI();
    await updateSendBar();
    showToast('Signed out');
  } catch (error) {
    console.error('[Thinkly] Logout error:', error);
    showToast('Sign out failed: ' + error.message, true);
  }
}

/**
 * Show toast notification
 */
function showToast(message, variant = 'success') {
  const existing = document.querySelector('.thinkly-popup-toast');
  if (existing) existing.remove();

  const normalizedVariant = typeof variant === 'string'
    ? variant
    : variant ? 'error' : 'success';

  const toastTheme = normalizedVariant === 'error'
    ? {
        background: '#fffafa',
        color: '#a63a3a',
        border: '1px solid rgba(224, 62, 62, 0.16)',
        shadow: '0 10px 28px rgba(166, 58, 58, 0.10)'
      }
    : {
        background: 'rgba(74, 71, 64, 0.10)',
        color: '#4a4740',
        border: '1px solid rgba(74, 71, 64, 0.20)',
        shadow: '0 10px 28px rgba(74, 71, 64, 0.16)'
      };

  const toast = document.createElement('div');
  toast.className = `thinkly-popup-toast ${normalizedVariant}`;
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed;
    bottom: 72px;
    left: 50%;
    transform: translateX(-50%);
    width: max-content;
    max-width: calc(100% - 32px);
    padding: 10px 14px;
    background: ${toastTheme.background};
    color: ${toastTheme.color};
    border: ${toastTheme.border};
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
    line-height: 1.5;
    box-shadow: ${toastTheme.shadow};
    z-index: 10000;
    animation: fadeIn 0.2s ease;
    text-align: center;
    backdrop-filter: saturate(120%);
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}

/**
 * Get filtered clips
 */
function getFilteredClips() {
  let filteredClips = allClips;
  if (currentCategoryId) {
    filteredClips = filteredClips.filter(clip => clip.categoryId === currentCategoryId);
  }
  if (currentSearchQuery) {
    const query = currentSearchQuery.toLowerCase();
    filteredClips = filteredClips.filter(clip =>
      (clip.title || '').toLowerCase().includes(query) ||
      (clip.text || '').toLowerCase().includes(query)
    );
  }
  return filteredClips;
}

/**
 * Open Settings panel
 */
async function openSettings() {
  if (isSelectionMode) {
    exitSelectionMode();
  }

  const autoSyncToggle = document.getElementById('settings-auto-sync');
  if (autoSyncToggle) {
    autoSyncToggle.checked = await readPopupAutoSyncPreference(chrome.storage.local);
  }

  switchTab('settings');
}

/**
 * Close Settings panel
 */
function closeSettings() {
  switchTab('feed');
}

/**
 * Handle export button click - Enter selection mode
 */
function handleExport() {
  enterSelectionMode();
}

/**
 * Enter selection mode
 */
function enterSelectionMode() {
  isSelectionMode = true;
  selectedClipIds.clear();
  setSelectionModeAuxiliaryVisibility(document, true);

  renderClips();
  showSelectionBar();
}

/**
 * Exit selection mode
 */
function exitSelectionMode() {
  isSelectionMode = false;
  selectedClipIds.clear();
  setSelectionModeAuxiliaryVisibility(document, false);

  hideSelectionBar();
  renderClips();
}

/**
 * Toggle clip selection
 */
function toggleClipSelection(clipId) {
  if (selectedClipIds.has(clipId)) {
    selectedClipIds.delete(clipId);
  } else {
    selectedClipIds.add(clipId);
  }
  renderClips();
  updateSelectionBar();
}

/**
 * Select all visible clips
 */
function selectAllClips() {
  const filteredClips = getFilteredClips();
  if (selectedClipIds.size === filteredClips.length) {
    selectedClipIds.clear();
  } else {
    filteredClips.forEach(clip => selectedClipIds.add(clip.id));
  }
  renderClips();
  updateSelectionBar();
}

/**
 * Show selection bar
 */
function showSelectionBar() {
  const filteredClips = getFilteredClips();
  selectionBar = new SelectionBar({
    containerId: 'selection-bar-container',
    selectedCount: selectedClipIds.size,
    totalCount: filteredClips.length,
    onClose: exitSelectionMode,
    onSelectAll: selectAllClips,
    onExport: exportSelectedClips
  });
  selectionBar.render();
}

/**
 * Hide selection bar
 */
function hideSelectionBar() {
  if (selectionBar) {
    selectionBar.destroy();
    selectionBar = null;
  }
}

/**
 * Update selection bar counts
 */
function updateSelectionBar() {
  if (selectionBar) {
    const filteredClips = getFilteredClips();
    selectionBar.update({
      selectedCount: selectedClipIds.size,
      totalCount: filteredClips.length
    });
  }
}

/**
 * Export selected clips
 */
async function exportSelectedClips() {
  try {
    if (selectedClipIds.size === 0) {
      showToast(POPUP_NEW_COPY.selectionPrompt, 'info');
      return;
    }
    
    const selectedClips = allClips.filter(clip => selectedClipIds.has(clip.id));
    const categoryName = currentCategoryId
      ? (allCategories[currentCategoryId]?.name || 'Selected Clips')
      : 'Selected Clips';
    
    await exportManager.exportToMarkdown(selectedClips, { categoryName });
    exitSelectionMode();
  } catch (error) {
    console.error('[Thinkly] Error exporting clips:', error);
    await showPopupAlert({
      title: 'Export failed',
      message: error.message
    });
  }
}

/**
 * Setup event listeners
 */
function setupEventListeners() {
  document.querySelectorAll('[data-popup-tab]').forEach((button) => {
    button.addEventListener('click', () => switchTab(button.dataset.popupTab));
  });

  // Search input
  const searchInput = document.getElementById('search-input');
  let searchTimeout;
  searchInput.addEventListener('input', (e) => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
      currentSearchQuery = e.target.value.trim();
      renderClips();
    }, 300);
  });

  // Settings button
  document.getElementById('settings-btn').addEventListener('click', openSettings);
  document.getElementById('settings-export').addEventListener('click', () => {
    switchTab('feed');
    handleExport();
  });
  document.getElementById('settings-auto-sync').addEventListener('change', async (e) => {
    const isEnabled = await writePopupAutoSyncPreference(chrome.storage.local, e.target.checked);
    showToast(isEnabled ? 'Auto sync enabled' : 'Auto sync disabled');

    if (isEnabled) {
      await maybeRunPopupAutoSync();
    }
  });
  document.getElementById('settings-dashboard').addEventListener('click', openDashboard);
  document.getElementById('settings-sync-now')?.addEventListener('click', async () => {
    try {
      await runFullSyncFlow({ silentSendAll: true });
      showToast('Sync complete');
    } catch (error) {
      console.error('Sync error:', error);
      showToast(`Sync failed: ${error.message}`, 'error');
    }
  });
  document.getElementById('stats-open-dashboard')?.addEventListener('click', openDashboard);
  ensureDashboardLink()
    ?.querySelector('#dashboard-link-btn')
    ?.addEventListener('click', openDashboard);

  document.getElementById('settings-auto-capture')?.addEventListener('change', async (e) => {
    captureV2Settings = await updateCaptureV2GlobalPreference(
      chrome.storage.local,
      e.target.checked
    );
    renderCaptureSettings();
    updateCaptureBanner();
    showToast(e.target.checked ? 'Auto capture enabled' : 'Auto capture paused');
  });

  ['chatgpt', 'claude', 'gemini'].forEach((platform) => {
    document.getElementById(`settings-platform-${platform}`)?.addEventListener('change', async (e) => {
      captureV2Settings = await updateCaptureV2PlatformPreference(
        chrome.storage.local,
        platform,
        e.target.checked
      );
      renderCaptureSettings();
      updateCaptureBanner();
      showToast(`${platform[0].toUpperCase()}${platform.slice(1)} capture ${e.target.checked ? 'enabled' : 'paused'}`);
    });
  });

  document.getElementById('capture-banner-setup-btn')?.addEventListener('click', async () => {
    const setupBtn = document.getElementById('capture-banner-setup-btn');
    if (setupBtn) {
      setupBtn.disabled = true;
      setupBtn.textContent = 'Enabling...';
    }

    captureV2Settings = await markCaptureV2OnboardingCompleted(chrome.storage.local, {
      completionSource: 'popup-banner'
    });
    renderCaptureSettings();
    updateCaptureBanner();
    showToast('Capture v2 enabled');

    if (setupBtn) {
      setupBtn.textContent = 'Enabled';
    }
  });

  // Login button
  const loginBtn = document.getElementById('login-btn');
  if (loginBtn) loginBtn.addEventListener('click', handleLogin);

  // Avatar click → profile dropdown toggle
  const userAvatar = document.getElementById('user-avatar');
  if (userAvatar) {
    userAvatar.addEventListener('click', (e) => {
      e.stopPropagation();
      const dropdown = document.getElementById('profile-dropdown');
      if (dropdown) {
        dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
      }
    });
  }

  // Dropdown sign out
  const dropdownSignout = document.getElementById('dropdown-signout');
  if (dropdownSignout) {
    dropdownSignout.addEventListener('click', handleLogout);
  }

  // Close dropdown on outside click
  document.addEventListener('click', () => {
    const dropdown = document.getElementById('profile-dropdown');
    if (dropdown) dropdown.style.display = 'none';
  });

  document.getElementById('side-panel-btn')?.addEventListener('click', openSidePanel);
  
  // Panel overlay
  document.getElementById('panel-overlay').addEventListener('click', closePanel);

  // Panel close buttons
  document.querySelectorAll('.panel-close').forEach(btn => {
    btn.addEventListener('click', closePanel);
  });

  // URL panel
  document.getElementById('url-add-btn').addEventListener('click', handleAddUrl);
  document.getElementById('url-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleAddUrl();
  });

  // File panel
  const dropzone = document.getElementById('file-dropzone');
  const fileInput = document.getElementById('file-input');

  dropzone.addEventListener('click', () => fileInput.click());
  dropzone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropzone.classList.add('drag-over');
  });
  dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag-over'));
  dropzone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropzone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) handleFileSelect(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length) handleFileSelect(e.target.files[0]);
  });
  document.getElementById('file-remove').addEventListener('click', () => {
    selectedFile = null;
    document.getElementById('file-info').style.display = 'none';
    document.getElementById('file-add-btn').disabled = true;
  });
  document.getElementById('file-add-btn').addEventListener('click', handleAddFile);

  // Text panel
  document.getElementById('text-add-btn').addEventListener('click', handleAddText);

  // Clip clicks
  document.getElementById('clips-list').addEventListener('click', (e) => {
    const clipItem = e.target.closest('.clip-item');
    if (clipItem) {
      const clipId = clipItem.dataset.clipId;
      if (isSelectionMode) {
        toggleClipSelection(clipId);
      } else {
        showClipDetail(clipId);
      }
    }
  });

  // Modal
  document.getElementById('modal-close').addEventListener('click', hideClipDetail);
  document.querySelector('.modal-overlay').addEventListener('click', hideClipDetail);
  document.getElementById('modal-copy').addEventListener('click', handleCopyClip);
  document.getElementById('modal-delete').addEventListener('click', handleDeleteClip);

  // ESC key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (currentPopupTab !== 'feed') {
        closeSettings();
        return;
      }
      closePanel();
      hideClipDetail();
    }
  });
}

/**
 * Handle file selection
 */
function handleFileSelect(file) {
  const validTypes = ['.txt', '.md', '.json'];
  const ext = '.' + file.name.split('.').pop().toLowerCase();

  if (!validTypes.includes(ext)) {
    showToast('Supported formats: .txt, .md, .json', 'info');
    return;
  }

  selectedFile = file;
  document.getElementById('file-name').textContent = file.name;
  document.getElementById('file-info').style.display = 'flex';
  document.getElementById('file-add-btn').disabled = false;
}

/**
 * Handle URL add
 */
async function handleAddUrl() {
  const input = document.getElementById('url-input');
  const categorySelect = document.getElementById('url-category');
  const url = input.value.trim();

  if (!url) {
    showToast('Please enter a URL', true);
    return;
  }

  try {
    new URL(url);
  } catch {
    showToast('Please enter a valid URL', true);
    return;
  }

  const btn = document.getElementById('url-add-btn');
  btn.disabled = true;
  btn.textContent = 'Adding...';

  try {
    const clip = {
      id: `clip_${Date.now()}`,
      title: url,
      text: `URL: ${url}`,
      icon: '🔗',
      source: {
        platform: 'other',
        siteName: new URL(url).hostname,
        url: url
      },
      categoryId: toStoredCategoryId(categorySelect.value),
      createdAt: Date.now()
    };

    await clipManager.saveClip(clip);
    await loadData();
    renderClips();
    closePanel();
  } catch (error) {
    console.error('Error adding URL:', error);
    await showPopupAlert({
      title: 'Add URL failed',
      message: 'Please try again.'
    });
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add';
  }
}

/**
 * Handle file add
 */
async function handleAddFile() {
  if (!selectedFile) return;

  const categorySelect = document.getElementById('file-category');
  const btn = document.getElementById('file-add-btn');
  btn.disabled = true;
  btn.textContent = 'Uploading...';

  try {
    const text = await selectedFile.text();
    const ext = selectedFile.name.split('.').pop().toLowerCase();

    let title = selectedFile.name.replace(/\.[^/.]+$/, '');
    let content = text;

    if (ext === 'json') {
      try {
        const json = JSON.parse(text);
        title = json.title || json.name || title;
        content = json.text || json.content || JSON.stringify(json, null, 2);
      } catch {
        content = text;
      }
    }

    const clip = {
      id: `clip_${Date.now()}`,
      title: title,
      text: content,
      icon: '📄',
      source: {
        platform: 'other',
        siteName: 'File Upload',
        fileName: selectedFile.name
      },
      categoryId: toStoredCategoryId(categorySelect.value),
      createdAt: Date.now()
    };

    await clipManager.saveClip(clip);
    await loadData();
    renderClips();
    closePanel();
  } catch (error) {
    console.error('Error adding file:', error);
    await showPopupAlert({
      title: 'Upload failed',
      message: 'Please try again.'
    });
  } finally {
    btn.disabled = false;
    btn.textContent = 'Upload';
  }
}

/**
 * Handle text add
 */
async function handleAddText() {
  const titleInput = document.getElementById('text-title');
  const contentInput = document.getElementById('text-content');
  const categorySelect = document.getElementById('text-category');

  const title = titleInput.value.trim();
  const content = contentInput.value.trim();

  if (!content) {
    showToast('Please enter some text', true);
    return;
  }

  const btn = document.getElementById('text-add-btn');
  btn.disabled = true;
  btn.textContent = 'Saving...';

  try {
    const clip = {
      id: `clip_${Date.now()}`,
      title: title || content.substring(0, 50) + (content.length > 50 ? '...' : ''),
      text: content,
      icon: '📝',
      source: {
        platform: 'other',
        siteName: 'Manual Entry'
      },
      categoryId: toStoredCategoryId(categorySelect.value),
      createdAt: Date.now()
    };

    await clipManager.saveClip(clip);
    await loadData();
    renderClips();
    closePanel();
  } catch (error) {
    console.error('Error adding text:', error);
    if (error.message && error.message.includes('not exceed')) {
      showToast('Text too long (max 100,000 characters)', true);
    } else {
      showToast('Save failed', true);
    }
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save';
  }
}

/**
 * Show clip detail modal
 */
function showClipDetail(clipId) {
  currentClip = allClips.find(c => c.id === clipId);
  if (!currentClip) return;

  const modal = document.getElementById('detail-modal');
  document.getElementById('modal-icon').textContent = currentClip.icon || '💡';
  document.getElementById('modal-title').textContent = currentClip.title || 'Untitled';
  document.getElementById('modal-text').textContent = currentClip.text || '';

  const source = currentClip.source;
  document.getElementById('modal-source').textContent = source?.siteName || source?.platform || 'Unknown';
  document.getElementById('modal-time').textContent = getRelativeTime(currentClip.createdAt);

  // Category select
  const categorySelect = document.getElementById('modal-category');
  const options = getRootCategoryOptions(allCategories)
    .map((cat) => {
      const optionValue = toCategoryOptionValue(cat.id);
      const isSelected = optionValue === toCategoryOptionValue(currentClip.categoryId);
      return `<option value="${optionValue}" ${isSelected ? 'selected' : ''}>${escapeHTML(cat.icon || '📁')} ${escapeHTML(cat.name)}</option>`;
    })
    .join('');
  categorySelect.innerHTML = options;
  categorySelect.onchange = async () => {
    try {
      currentClip = await moveClipToCategory({
        clipManager,
        clipId: currentClip.id,
        categoryId: categorySelect.value
      });
      await loadData();
      renderCategoryPills();
      renderClips();
    } catch (error) {
      console.error('Category update error:', error);
      showToast('Failed to update category', true);
    }
  };

  modal.style.display = 'block';
}

/**
 * Hide clip detail modal
 */
function hideClipDetail() {
  document.getElementById('detail-modal').style.display = 'none';
  currentClip = null;
}

/**
 * Handle copy clip
 */
async function handleCopyClip() {
  if (!currentClip) return;
  try {
    await navigator.clipboard.writeText(currentClip.text || '');
    const btn = document.getElementById('modal-copy');
    btn.textContent = '✓ Copied';
    setTimeout(() => btn.textContent = '📋 Copy', 1500);
  } catch (error) {
    console.error('Copy error:', error);
  }
}

/**
 * Handle delete clip
 */
async function handleDeleteClip() {
  if (!currentClip) return;
  const confirmed = await showPopupConfirm({
    title: POPUP_NEW_COPY.deleteDialog.title,
    message: POPUP_NEW_COPY.deleteDialog.message,
    confirmText: POPUP_NEW_COPY.deleteDialog.confirmText,
    cancelText: POPUP_NEW_COPY.deleteDialog.cancelText,
  });
  if (!confirmed) return;

  try {
    await clipManager.deleteClip(currentClip.id);
    await loadData();
    renderClips();
    hideClipDetail();
  } catch (error) {
    console.error('Delete error:', error);
  }
}

// Initialize on DOMContentLoaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
